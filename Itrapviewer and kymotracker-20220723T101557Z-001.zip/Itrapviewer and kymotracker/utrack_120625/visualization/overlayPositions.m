function overlayPositions(movieInfo,startend,dragtailLength,...
    saveMovie,movieName,filterSigma,classifyGaps,highlightES,showRaw,...
    imageRange,onlyTracks,classifyLft,diffAnalysisRes,intensityScale,...
    colorTracks)
%OVERLAYTRACKSMOVIENEW Overlays tracks obtained via trackCloseGapsKalman on movies with variable color-coding
%
%SYNPOSIS overlayTracksMovieNew(tracksFinal,startend,dragtailLength,...
%    saveMovie,movieName,filterSigma,classifyGaps,highlightES,showRaw,...
%    imageRange,onlyTracks,classifyLft,diffAnalysisRes,intensityScale,...
%    colorTracks)
%
%INPUT  tracksFinal   : Output of trackCloseGapsKalman.
%       startend      : Row vector indicating first and last frame to
%                       include in movie. Format: [startframe endframe].
%                       Optional. Default: [(first frame with tracks) (last frame with tracks)]
%       dragtailLength: Length of drag tail (in frames).
%                       Optional. Default: 10 frames.
%                       ** If dragtailLength = 0, then no dragtail.
%                       ** To show tracks from their beginning to their end,
%                       set dragtailLength to any value longer than the
%                       movie.
%                       ** To show tracks statically while features dance
%                       on them, use -1.
%                       ** To show tracks from their beginning to their
%                       end, and to retain tracks even after the particle
%                       disappears, use -2.
%       saveMovie     : 1 to save movie (as Quicktime), 0 otherwise.
%                       Optional. Default: 0.
%       movieName     : filename for saving movie.
%                       Optional. Default: TrackMovie (if saveMovie = 1).
%       filterSigma   : 0 to overlay on raw image, PSF sigma to overlay on
%                       image filtered with given filterSigma.
%                       Optional. Default: 0.
%       classifyGaps  : 1 to classify gaps as "good" and "bad", depending
%                       on their length relative to the legnths of the
%                       segments they connect, 0 otherwise.
%                       Optional. Default: 1.
%       highlightES   : 1 to highlight track ends and starts, 0 otherwise.
%                       Optional. Default: 1.
%       showRaw       : 1 to add raw movie to the left of the movie with
%                       tracks overlaid, 2 to add raw movie at the top of
%                       the movie with tracks overlaid, 0 otherwise.
%                       Optional. Default: 0.
%       imageRange    : Image region to make movie out of, in the form:
%                       [min pixel X, max pixel X; min pixel Y, max pixel Y].
%                       Optional. Default: Whole image.
%       onlyTracks    : 1 to show only tracks without any symbols showing
%                       detections, closed gaps, merges and splits; 0 to
%                       show symbols on top of tracks.
%                       Optional. Default: 0.
%       classifyLft   : 1 to classify objects based on (1) whether they
%                       exist throughout the whole movie, (2) whether they
%                       appear OR disappear, and (3) whether they appear
%                       AND disappear; 0 otherwise.
%                       Optional. Default: 1.
%       diffAnalysisRes: Diffusion analysis results (either output of
%                       trackDiffusionAnalysis1 or trackTransientDiffusionAnalysis2).
%                       Needed if tracks/track segments are to be
%                       colored based on their diffusion classification.
%                       With this option, classifyGaps, highlightES and
%                       classifyLft are force-set to zero, regardless of input.
%                       Optional. Default: None.
%       intensityScale: 0 to autoscale every image in the movie, 1
%                       to have a fixed scale using intensity mean and std,
%                       2 to have a fixed scale using minimum and maximum
%                       intensities.
%                       Optional. Default: 1.
%       colorTracks   : 1 to color tracks by rotating through 7 different
%                       colors, 0 otherwise. With this option,
%                       classifyGaps, highlightES and classifyLft are
%                       force-set to zero, regardless of input.
%                       Option ignored if diffAnalysisRes is supplied.
%                       Optional. Default: 0.
%
%OUTPUT If movie is to be saved, the QT movie is written into directory
%       where TIFFs are located
%
%REMARKS Color-coding:
%        ** Without diffusion classification, all tracks have a neutral
%        color, while objects are color coded in the following way:
%               * Detected object just after appearance: Green circle.
%               * Detected object just before disappearance: Yellow
%                 circle.
%               * Detected object in middle of trajectory that spans
%                 whole movie: White circle.
%               * Detected object in middle of trajectory that appears OR
%                 disappears within movie: Magenta circle.
%               * Detected object in middle of trajectory that appears AND
%                 disappears within movie: Red circle.
%               * Gap that is short than both segments it connects: Cyan
%                 star.
%               * Gap that is longer than at least one ofthe segments it
%                 connects: Blue star.
%               * Object before and after splitting: Green diamond.
%               * OBject before and after merging: Yellow diamond.
%           When classifyGaps = 0, all gaps are cyan.
%           When highlighES = 0, no green and yellow circles.
%           When classifyLft = 0, all objets in middle of trajectory are white.
%
%       ** With diffusion classification, all objects and gaps have neutral
%       color (merges and splits are diamonds), while tracks and track
%       segments are color-coded in the following way:
%               * Type 1: Linear + 1D confined diffusion: Orange.
%               * Type 2: Linear + 1D normal diffusion: Red.
%               * Type 3: Linear + 1D super diffusion: Green.
%               * Type 4: Linear + too short for 1D classification: Yellow.
%               * Type 5: Random/Unclassified + 2D confined diffusion: Blue.
%               * Type 6: Random/Unclassified + 2D normal diffusion: Cyan.
%               * Type 7: Random/Unclassified + 2D super diffusion: Magenta.
%               * Type 8: Random + too short for 2D classification: Purple.
%               * Type 0: Too short for any analysis: Light pink.
%
%This file is part of u-track.
%
%    u-track is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%    u-track is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with u-track.  If not, see <http://www.gnu.org/licenses/>.
%
%
%Copyright: Khuloud Jaqaman, August 2007

global expPath

%% input
%check whether correct number of input arguments was used
if nargin < 1
    disp('--overlayTracksMovieNew: Incorrect number of input arguments!');
    return
end

%get first and last frames where there are tracks



tracksFirstFrame = 1;
tracksLastFrame = 2;
imageArray=repmat(struct('imaq',[]),tracksLastFrame,1);
%record directory before start of function
% startDir = pwd;

if  exist('expPath')==0 || exist('expPath')==2 || isempty(expPath)
    imageDir='C:\Users\Fos\Documents\MATLAB\utrack\';
else
    imageDir=expPath;
end

%ask user for images
[fName,dirName] = uigetfile([imageDir '*.tif'],'specify first image in the stack - specify very first image, even if not to be plotted');



%create folder for single trajectory saving
mkdir(strcat(dirName,'full','\'));
folder=strcat(dirName,'full','\');


%if input is valid ...
if(isa(fName,'char') && isa(dirName,'char'))
    
    %get all file names in stack
    outFileList = getFileStackNames([dirName,fName]);
    numFiles = length(outFileList);
    
    %determine which frames the files correspond to, and generate the inverse map
    %indicate missing frames with a zero
    frame2fileMap = zeros(numFiles,1);
    for iFile = 1 : numFiles
        [~,~,frameNumStr] = getFilenameBody(outFileList{iFile});
        frameNum = str2double(frameNumStr);
        frame2fileMap(frameNum) = iFile;
    end
    
    %assign as number of frames the last frame number observed
    numFrames = frameNum;
    
    %read first image to get image size
    currentImage = imread(outFileList{1});
    [isx,isy] = size(currentImage);
    
else %else, exit
    
    disp('--overlayTracksMovieNew: Bad file selection');
    return
    
end

%check startend and assign default if necessary
if nargin < 2 || isempty(startend)
    startend = [tracksFirstFrame tracksLastFrame];
else
    tracksFirstFrame = min(tracksFirstFrame,startend(1));
    tracksLastFrame = max(tracksLastFrame,startend(2));
end

%keep only the frames of interest
outFileList = outFileList(frame2fileMap(startend(1)):frame2fileMap(startend(2)));
frame2fileMap = frame2fileMap(startend(1):startend(2));
indxNotZero = find(frame2fileMap~=0);
frame2fileMap(indxNotZero) = frame2fileMap(indxNotZero) - frame2fileMap(indxNotZero(1)) + 1;

%check dragtailLength and assign default if not necessary
if nargin < 3 || isempty(dragtailLength)
    dragtailLength = 10;
end

%check whether to save movie
if nargin < 4 || isempty(saveMovie)
    saveMovie = 0;
end

%check name for saving movie
if saveMovie && (nargin < 5 || isempty(movieName))
    movieName = 'trackMovie.mov';
end

%check whether to use filtered images
if nargin < 6 || isempty(filterSigma)
    filterSigma = 0;
end

%check whether to color-code gaps
if nargin < 7 || isempty(classifyGaps)
    classifyGaps = 1;
end

%check whether to highligh track starts and ends
if nargin < 8 || isempty(highlightES)
    highlightES = 1;
end

%check whether to put raw movie adjacent to movie with tracks overlaid
if nargin < 9 || isempty(showRaw)
    showRaw = 0;
end

%check whether an area of interest was input
if nargin < 10 || isempty(imageRange)
    imageRange = [1 isx; 1 isy];
end

%check whether to plot tracks only or also symbols
if nargin < 11 || isempty(onlyTracks)
    onlyTracks = 0;
end

%check whether to classify lifetime
if nargin < 12 || isempty(classifyLft)
    classifyLft = 1;
end

%check whether to color-code tracks based on diffusion classification
%checm whether diffusion classification is for overall tracks or transient
if nargin < 13 || isempty(diffAnalysisRes)
    diffAnalysisRes = [];
    transDiffClass = 0;
else
    classifyGaps = 0;
    highlightES = 0;
    classifyLft = 0;
    if isfield(diffAnalysisRes,'segmentClass')
        transDiffClass = 1;
    else
        transDiffClass = 0;
    end
end



%check how to scale image intensity
if nargin < 14 || isempty(intensityScale)
    intensityScale = 1;
end

%check whether to color individual tracks
if nargin < 15 || isempty(colorTracks)
    colorTracks = 0;
else
    if ~isempty(diffAnalysisRes)
        colorTracks = 0;
    end
    if colorTracks == 1
        classifyGaps = 0;
        highlightES = 0;
        classifyLft = 0;
    end
end
highlightES=1;
showRaw=3;
intensityScale=2;
%define region of interest
imageROI=imread([dirName fName]);
intMinMax=[min(min(imageROI)) max(max(imageROI))];
figure, imshow(imageROI,intMinMax),title('Draw ROI and double-click to continue.');
h = imrect;
position = wait(h);
close all;
imageRange(2,1)=position(1);
imageRange(2,2)=position(1)+position(3);
imageRange(1,1)=position(2);
imageRange(1,2)=position(2)+position(4);

%define colors to loop through
colorLoop = [1 0.7 0.7; 1 0 0; 0 1 0; 0 0 1; 1 1 0; 1 0 1; 0 1 1]; %colors: 'light pink',r,g,b,y,m,c

%initialize QT movie if it is to be saved
if saveMovie
    evalString = ['MakeQTMovie start ''' fullfile(dirName,movieName) ''''];
    eval(evalString);
end


%% make movie

% %go to directory where movie will be saved
% cd(dirName);

%go over all specified frames and find minimum and maximum intensity in all
%of them combined
switch intensityScale
    case 0
        intensityMinMax = [];
    case 1
        meanIntensity = zeros(tracksLastFrame,1);
        stdIntensity = meanIntensity;
        for iFrame = 1 : size(tracksLastFrame,2)
            if frame2fileMap(iFrame) ~= 0
                imageStack = double(imread(outFileList{frame2fileMap(iFrame)}));
                meanIntensity(iFrame) = mean(imageStack(:));
                stdIntensity(iFrame) = std(imageStack(:));
            end
        end
        meanIntensity = mean(meanIntensity);
        stdIntensity = mean(stdIntensity);
        intensityMinMax = [meanIntensity-2*stdIntensity meanIntensity+6*stdIntensity];
     case 2
        intensity = repmat(struct('mimMax',[]),tracksLastFrame,1);
        minIntensity = zeros(tracksLastFrame,1);
        maxIntensity = minIntensity;
        for iFrame = 1 : tracksLastFrame
            
            if frame2fileMap(iFrame) ~= 0
                imageStack = double(imread(outFileList{frame2fileMap(iFrame)}));
                %imageArray;imageStack( uint16(imageRange(2,1))
                %:uint16(imageRange(2,2)))
                minIntensity(iFrame) = min(min(imageStack(uint16(imageRange(1,1)) :uint16(imageRange(1,2)),uint16(imageRange(2,1)) :uint16(imageRange(2,2)))));
                maxIntensity(iFrame) = max(max(imageStack(uint16(imageRange(1,1)) :uint16(imageRange(1,2)),uint16(imageRange(2,1)) :uint16(imageRange(2,2)))));
                intensity(iFrame).minMax = [minIntensity(iFrame)  maxIntensity(iFrame)];
            end
        end
end

filenamecount=0;
%movie = zeros([ numFrames],class(imag));
%go over all specified frames
for iFrame = 1 : tracksLastFrame
    
    if frame2fileMap(iFrame) ~= 0 %if frame exists
        
        %read specified image
        imageStack = imread(outFileList{frame2fileMap(iFrame)});
        
        %filter images if requested
        if filterSigma
            imageStack = Gauss2D(imageStack,filterSigma);
        end
        
    else %otherwise
        
        %make empty frame
        imageStack = zeros(isx,isy);
        
    end
    
    %plot image in current frame and show frame number
    clf;
    
    switch showRaw
        case 1
            disp('raw');
            disp(intensityMinMax);
            axes('Position',[0 0 0.495 1]);
            h=imshow(imageStack,intensityMinMax,'XData',[1 10], 'YData', [1 10]);
            xlim(imageRange(2,:));
            ylim(imageRange(1,:));
            hold on;
            textDeltaCoord = min(diff(imageRange,[],2))/20;
            text(imageRange(1,1)+textDeltaCoord,imageRange(2,1)+...
                textDeltaCoord,num2str(iFrame+startend(1)-1),'Color','white');
            axes('Position',[0.505 0 0.495 1]);
            h=imshow(imageStack,intensityMinMax,'XData',[1 10], 'YData', [1 10]);
             
            xlim(imageRange(2,:));
            ylim(imageRange(1,:));
            hold on;
        case 2
            disp('2');
            disp(intensityMinMax);
            axes('Position',[0 0.505 1 0.495]);
            h=imshow(imageStack,intensityMinMax);
            xlim(imageRange(2,:));
            ylim(imageRange(1,:));
            hold on;
            textDeltaCoord = min(diff(imageRange,[],2))/20;12
            text(imageRange(1,1)+textDeltaCoord,imageRange(2,1)+...
                textDeltaCoord,num2str(iFrame+startend(1)-1),'Color','white');
            axes('Position',[0 0 1 0.495]);
            h=imshow(imageStack,intensityMinMax,'XData',[1 10], 'YData', [1 10]);
            xlim(imageRange(2,:));
            ylim(imageRange(1,:));
            hold on;
        otherwise
            %disp('otherwise');
            %disp(intensityMinMax);
            axes('Position',[0 0 1 1]);
            %imageStack=imcrop(imageStack,[75 68 130 112])
            if intensityScale==2
                h=imshow(imageStack,intensity(iFrame).minMax);%'DisplayRange',intensityMinMax,
            else
                h=imshow(imageStack,intensityMinMax);%'DisplayRange',intensityMinMax,
            end
            %set(gcf,'Position',[0 100 30 100]);
            xlim(imageRange(2,:));
            ylim(imageRange(1,:));
            hold on;
            textDeltaCoord = min(diff(imageRange,[],2))/20;
            text(imageRange(1,1)+textDeltaCoord,imageRange(2,1)+...
                textDeltaCoord,num2str(iFrame+startend(1)-1),'Color','white');
    end
    
    
    for i=1:length(movieInfo(iFrame).xCoord )   
        %red circles: detected feature in the middle of track with status 0
        
        plot(movieInfo(iFrame).xCoord(i),movieInfo(iFrame).yCoord(i),'ro','MarkerSize',5);
        text(double(movieInfo(iFrame).xCoord(i)+2),...
                double(movieInfo(iFrame).yCoord(i)),num2str(i),'Color','blue');
    end

    set(gcf, 'Position', [100 100 612 612]);
    %zoom(gcf,2);
    [imag,v]=getframe(gcf);
    imageArray(iFrame).imaq=imag;
    %imag=imag([1 256],[1 256]);
    
    
    
    filenamecount=filenamecount+1;
    filename=num2str(filenamecount);
    [imag,v]=getframe(gcf);
    
    if filenamecount==1
       movie = zeros([size(imag) numFrames],class(imag));
       
    end
    movie(:,:,:,filenamecount)=imag;
    
    %write single image in specified folder
    imwrite(imag,strcat(folder,filename,'.tif'),'tif');
    %add frame to movie if movie is saved
    if saveMovie
        MakeQTMovie addfigure
    end
    
    %pause for a moment to see frame
    pause(0.1);
    
end %(for iFrame = 1 : size(xCoordMatAll,2))
for i=1:length(imageArray)
    figure,imshow(rgb2gray(imageArray(i).imaq)),title(['image' num2str(i)])
    imcontrast;
end

    
%finish movie
if saveMovie==1
    MakeQTMovie finish
end

%implay(movie,2);

%% change directory back to original
% cd(startDir);

%% ~~~ end ~~~
