



    overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_1.mov',[],[],1,0,[1 200; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_2.mov',[],[],1,0,[1 200; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_3.mov',[],[],1,0,[1 200; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_4.mov',[],[],1,0,[156 356; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_5.mov',[],[],1,0,[156 356; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_6.mov',[],[],1,0,[156 356; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_7.mov',[],[],1,0,[312 512; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_8.mov',[],[],1,0,[312 512; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_9.mov',[],[],1,0,[312 512; 312 512],0,[],[],2,1);
    
