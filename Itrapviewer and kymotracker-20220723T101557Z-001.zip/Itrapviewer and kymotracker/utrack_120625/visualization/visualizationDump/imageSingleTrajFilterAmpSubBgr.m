function [intens,amp,psf,bgr]=imageSingleTrajFilterAmpSubBgr(tracks,traj,sub,full,extension)






%% Output


amp=[];
bgr=[];
psf=[];
intens=[];


%%


numTracks=size(tracks,1);
trajCoord = repmat(struct('xMax','yMax','xMin','yMin','start','end'),numTracks,1);
trajectories = repmat(struct('x',[],'y',[],'amp',[],'intens',[],'bgr',[],'psf',[]),numTracks,1);

%%


if nargin<2 || isempty(traj)
    numTracks=size(tracks,1);
    tracksFilter=tracks;
else
    numTracks=numel(traj);
    tracksFilter = repmat(struct('tracksFeatIndxCG',[],...
            'tracksCoordAmpCG',[],'seqOfEvents',[]),numTracks,1);  
    for i=1:numTracks
        tracksFilter(i)=tracks(traj(i));
    end
end

trackSel=getTrackSel(tracksFilter);

if nargin<3 || isempty(sub)
    sub=[];
end

if nargin<4 || isempty(full)
    full=0;
end

ampTraj=zeros(numTracks,100);

l=0;
for k=1:numTracks
    
    trajCoord(k).xMin=512;
    trajCoord(k).yMin=512;
    trajCoord(k).xMax=0;
    trajCoord(k).yMax=0;
    ll=0;
    for j=1:trackSel(k,3)
        ll=ll+1;
        if isnan(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1))
            trajectories(k).x(ll)=0;
            trajectories(k).y(ll)=0;
            trajectories(k).amp(ll)=0;
            trajectories(k).intens(ll)=0;
            trajectories(k).bgr(ll)=trajectories(k).bgr(ll-1);
            trajectories(k).psf(ll)=0;
        else
            %disp('   ');
            l=l+1;
            xCoord=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1);
            yCoord=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+2);
            ampTraj(k,j)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+4);
            amp(l)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+4);
            psf(l)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+9);
            bgr(l)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+11);
            intens(l)=amp(l)*psf(l);
            
            trajectories(k).x(ll)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1);
            trajectories(k).y(ll)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+2);
            trajectories(k).amp(ll)=round(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+4)*65536);
            trajectories(k).bgr(ll)=round(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+11)*65536);
            trajectories(k).psf(ll)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+9);
            trajectories(k).intens(ll)=round(trajectories(k).amp(ll)*trajectories(k).psf(ll));
            
            
            trajCoord(k).start=tracksFilter(k).seqOfEvents(1,1);
            trajCoord(k).end=tracksFilter(k).seqOfEvents(end,1);
            if xCoord<trajCoord(k).xMin
                trajCoord(k).xMin=xCoord;
                %disp('xMin');
                %disp(trajCoord(k).xMin);
                
                
            end
            if yCoord<trajCoord(k).yMin
                trajCoord(k).yMin=yCoord;
                 
                %disp('yMin');
                %disp(trajCoord(k).yMin);
            end
            if xCoord>trajCoord(k).xMax
                trajCoord(k).xMax=xCoord;
                 
                %disp('xMax');
                %disp(trajCoord(k).xMax);
            end
            if yCoord>trajCoord(k).yMax
                trajCoord(k).yMax=yCoord;
                 
                %disp('yMax');
                %disp(trajCoord(k).yMax);
            end
        end
    end
end


%ask user for images
[fName,dirName] = uigetfile('*.tif','specify first image in the stack - specify very first image, even if not to be plotted');
if nargin<5 || isempty(extension)
    extension=30;
end

for i=1:numTracks
    
   
   k=i;
   
   
   trajCoord(k).xMin=trajCoord(k).xMin-extension;
   trajCoord(k).yMin=trajCoord(k).yMin-extension;
   trajCoord(k).xMax=trajCoord(k).xMax+extension;
   trajCoord(k).yMax=trajCoord(k).yMax+extension;
   
  
   if trajCoord(k).xMin<1
       trajCoord(k).xMin=1;
   end
   if trajCoord(k).yMin<1
       trajCoord(k).yMin=1;
   end
   if trajCoord(k).xMax>512
       trajCoord(k).xMax=512;
   end
   if trajCoord(k).yMax>512
       trajCoord(k).yMax=512;
   end
   
   ext=3;
   startend=[max([trajCoord(k).start-ext 1]) min([trajCoord(k).end+ext 300])];
   bgr=zeros(length(trajectories(k).bgr)+min([trajCoord(k).start-1 ext])+ext);
   
   imageRange=[trajCoord(k).yMin, trajCoord(k).yMax; trajCoord(k).xMin, trajCoord(k).xMax ];
   
   
   bgr(1:1+min([trajCoord(k).start-1 ext]))=trajectories(k).bgr(1);
   if ext>0 
   bgr((min([trajCoord(k).start-1 ext])+length(trajectories(k).bgr)+1):(min([trajCoord(k).start-1 ext])+length(trajectories(k).bgr)+ext))=trajectories(k).bgr(end);
   end
   bgr(1+min([trajCoord(k).start-1 ext]):(min([trajCoord(k).start-1 ext])+length(trajectories(k).bgr)))=trajectories(k).bgr(1:end);
   
   
   if full==1
       imageRange=[];
   end
   if nargin<2 || isempty(traj)
        %disp('k');
        %disp(k);
        %disp('trajectories(k).bgr');
        %disp(trajectories(k).bgr);
        %disp('bgr');
        %disp(bgr);
        overlayTracksMovieNewPsfSubBgr(tracksFilter,imageRange,k,fName,dirName,startend,bgr,sub);
   else
        overlayTracksMovieNewPsfSubBgr(tracksFilter,imageRange,traj(k),fName,dirName,startend,bgr,sub);
   end
end







        
   
    

