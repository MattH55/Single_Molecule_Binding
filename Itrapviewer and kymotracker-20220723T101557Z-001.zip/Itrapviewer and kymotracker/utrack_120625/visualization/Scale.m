function sc=Scale(handle)
%SCALE create a scale in a image
%
% SYNOPSIS sc=Scale(handle)
%
% INPUT  handle: an image handle OR a figure handle
%
% constructor:
%                   Scale(handle)
%
% public methods:
%                   SetScale(scale)
%
% private methods:
%                   OptionWindow(scale)	
%
%This file is part of u-track.
%
%    u-track is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%    u-track is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with u-track.  If not, see <http://www.gnu.org/licenses/>.
%
%
%Copyright: D. Thomann 12/8/99

% Check whether we got an image or a figure and initialize scale
if (strcmp(get(handle,'Type'),'image'))
   imAxesH = get(handle,'Parent');
   sc.figure = get(imAxesH,'Parent');
else
   sc.figure = handle;
end;
%scale length in mu
sc.length = 100;
% origin of the scale in the figure
sc.origin=[];
% one pixel corresponds to ... mu
sc.pixelSize =2;
% line Handle
sc.lineH = [];
% text Handle
sc.textH = [];
% additional text
sc.text=[num2str(sc.length) ' \mum'];
% color (1 = white, 2 = black)
sc.color = 1;
sc = class(sc,'Scale');
