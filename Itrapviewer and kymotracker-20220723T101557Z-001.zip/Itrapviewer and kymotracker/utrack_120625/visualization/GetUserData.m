function obj = GetUserData (figHandle, oName, remove)
%GETUSERDATA gets any object connected to the figure 'figHandle'
%
% SYNOPSIS object = GetUserData(gHandle, oName, remove)
%
% INPUT  figHandle: a figure handle
%        oName    : the name string under which the object is stored
%        remove   : (optional) if remove = 1 then the connection of 'oName' 
%                   to the figure is removed
%
% OUTPUT object   : the object
%
%This file is part of u-track.
%
%    u-track is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%    u-track is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with u-track.  If not, see <http://www.gnu.org/licenses/>.
%
%
%Copyright: D. Thomann 12/8/99

uD = get(figHandle,'UserData');

% Check if name already exists in the list
if (~isempty(uD) & (any(strcmp(oName,fieldnames(uD)))))
   obj = getfield(uD,oName);
   % Remove the field?
   if ((nargin==3) & (remove==1))
      uD = rmfield(uD,oName);
      set(figHandle,'UserData',uD);
   end;
else
   obj = [];
end;
