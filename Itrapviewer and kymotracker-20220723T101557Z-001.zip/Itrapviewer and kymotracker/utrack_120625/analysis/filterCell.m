function [ cellsFiltered,cellsFilterWindow ] = filterCell( cells,trajectories,startWindow )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here




[nrCells,nrTraj]=size(cells);
cellsFilterWindow=startWindow;
for i=1:nrCells
    traj=cells(i,:);
    traj=traj(find(traj));
    trajFiltered=[];
    for j=1:length(traj);
        disp(trajectories(traj(j)).frames(1));
        if trajectories(traj(j)).frames(1)>(startWindow(1)-1) && trajectories(traj(j)).frames(1)<(startWindow(2)+1)
            trajFiltered=horzcat(trajFiltered,traj(j));
        end
    end
    cellsFiltered(i,1:length(trajFiltered))=trajFiltered;
end

end


