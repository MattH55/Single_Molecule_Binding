function [ trajectories_org,trajectories ] = rangeTraj( trajectories_org,traj )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

for i=1:length(traj)
    %%if ~isempty(trajectories_org(traj).range)
    rangeDim=size(trajectories_org(traj(i)).range);
    startFrame=trajectories_org(traj(i)).frames(1);
    template=zeros(1,length(trajectories_org(traj(i)).x));
    if ~isempty(trajectories_org(traj(i)).linkNext)
        trajectories_org(trajectories_org(traj(i)).linkNext).linkPrevious=traj(i);
    end
    for  j=1:rangeDim(1)
        
            startEntry=trajectories_org(traj(i)).range(j,1)-startFrame+1;
            endEntry=trajectories_org(traj(i)).range(j,2)-startFrame+1;
            entries=startEntry:endEntry;
            template(entries)=1;
    end
    trajectories_org(traj(i)).x=trajectories_org(traj(i)).x.*template;
end

k=0;
i=0;
trajNum=[];
while k==0
    i=i+1;
    
    trajNumTemp=traj(1);
    trajNumCurrentPrevious=traj(1);
    trajNumCurrentNext=traj(1);
    traj(traj==trajNumCurrentPrevious)=[];
    
    disp('i');
    disp(i);
    exit=0;
    while exit==0
        if ~isempty(trajectories_org(trajNumCurrentPrevious).linkPrevious)
            if trajectories_org(trajectories_org(trajNumCurrentPrevious).linkPrevious).linkNext==trajNumCurrentPrevious;
                disp('trajectories_org(trajNumCurrentPrevious).linkPrevious');
                disp(trajectories_org(trajNumCurrentPrevious).linkPrevious);
                disp('trajNum(i)first previous');
                disp(trajNumTemp);
                trajNumTemp(1:(length(trajNumTemp)+1))=horzcat(trajectories_org(trajNumCurrentPrevious).linkPrevious,trajNumTemp);
                trajNumCurrentPrevious=trajectories_org(trajNumCurrentPrevious).linkPrevious;
                traj(traj==trajNumCurrentPrevious)=[];
                disp('previous');
                disp('trajNum');
                disp(trajNumTemp);
            else
                disp('Mismatch');
                exit=1;
            end
        else
            disp('no previous');
            exit=1;
        end
    end
    exit=0;
    while exit==0
        if ~isempty(trajectories_org(trajNumCurrentNext).linkNext)
            if trajectories_org(trajectories_org(trajNumCurrentNext).linkNext).linkPrevious==trajNumCurrentNext;
                disp(trajectories_org(trajNumCurrentPrevious).linkPrevious);
                disp('trajNum(i)first');
                disp(trajNumTemp);
                trajNumTemp(1:(length(trajNumTemp)+1))=horzcat(trajNumTemp,trajectories_org(trajNumCurrentNext).linkNext);
                trajNumCurrentNext=trajectories_org(trajNumCurrentNext).linkNext;
                traj(traj==trajNumCurrentNext)=[];
                disp('next');
                disp('trajNum(i)second');
                disp(trajNumTemp);
            else
                disp('Mismatch');
                exit=1;
            end
        else
            disp('no next');
            exit=1;
        end
    end
    trajNum(i,1:length(trajNumTemp))=trajNumTemp;
    disp('traj');
    disp(traj);
    if isempty(traj)
        k=1;
    end
end
disp('trajNumFinal');
disp(trajNum);
[trajN,dummy]=size(trajNum);
for i=1:trajN
    indexNonZero=find(trajectories_org(trajNum(i,1)).x>0);
    trajectories(i).x=trajectories_org(trajNum(i,1)).x(indexNonZero(1):indexNonZero(end));
    trajectories(i).frames=trajectories_org(trajNum(i,1)).frames(indexNonZero(1):indexNonZero(end));
    concNum=find(trajNum(i,:));
    for j=2:length(concNum)
        disp('trajectories(i).x');
        disp(trajectories(i).x);
        disp('trajNum(i,j)');
        disp(trajNum(i,j));
        
        indexNonZero=find(trajectories_org(trajNum(i,j)).x>0);
        xDummy=trajectories_org(trajNum(i,j)).x(indexNonZero(1):indexNonZero(end));
        disp('xDummy');
        disp(xDummy);
        framesDummy=trajectories_org(trajNum(i,j)).frames(indexNonZero(1):indexNonZero(end));
        disp('framesDummy');
        disp(framesDummy);
        disp('trajectories_org(trajNum(i,j)).frames(indexNonZero(1))');
        disp(trajectories_org(trajNum(i,j)).frames(indexNonZero(1)));
        %if framesDummy(1)>trajectories(i).frames(end)
        %    lengthDiff=trajectories_org(trajNum(i,j)).frames(indexNonZero(1))-(trajectories(i).frames(1,end)+1);
        %    disp('trajectories(i).xbeforeZeros');
        %   disp(trajectories(i).x);
        %    trajectories(i).x(length(trajectories(i).x)+1:(length(trajectories(i).x)+lengthDiff))=0;
        %    trajectories(i).x(length(trajectories(i).x)+1:(length(trajectories(i).x)+length(xDummy)))=xDummy;
        %    disp('trajectories(i).xafterZeros');
        %    disp(trajectories(i).x);
        %    disp('trajectories(i).frames');
        %    disp(trajectories(i).frames);
        %    disp('trajectories(i).frames(1):(trajectories(i).frames(1)+length(trajectories(i).x))')
        %    disp(trajectories(i).frames(1):(trajectories(i).frames(1)+length(trajectories(i).x)-1))
        %    trajectories(i).frames(1:length(trajectories(i).x))=trajectories(i).frames(1):(trajectories(i).frames(1)+length(trajectories(i).x)-1);
        %    disp('hsahhshashash');
        %else
            disp('second else');
            disp('framesDummy(1,1)');
            disp(framesDummy(1,1));
            disp('trajectories(i).frames(1,end)');
            disp(trajectories(i).frames(1,end));
            lengthDiff=framesDummy(1,1)-trajectories(i).frames(1,end)-1;
            disp('length');
            disp(length(trajectories(i).x)+lengthDiff+1:length(trajectories(i).x)+lengthDiff+length(xDummy));
            disp('xDummy');
            disp(xDummy);
            disp('trajectories(i).x before dummy extension');
            disp(trajectories(i).x);
            trajectories(i).x(length(trajectories(i).x)+lengthDiff+1:length(trajectories(i).x)+lengthDiff+length(xDummy))=xDummy;
            disp('trajectories(i).x(length(trajectories(i).x)+lengthDiff+1:length(trajectories(i).x)+lengthDiff+length(xDummy))=xDummy;');
            disp(trajectories(i).x);
            trajectories(i).frames(1:length(trajectories(i).x))=trajectories(i).frames(1):(trajectories(i).frames(1)+length(trajectories(i).x)-1);
        %end
    end
end
    
    
end
