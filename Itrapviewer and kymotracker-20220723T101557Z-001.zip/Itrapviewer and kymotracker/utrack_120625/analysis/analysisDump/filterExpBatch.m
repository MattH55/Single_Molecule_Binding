[ trj_exp_111208_tatA25degYT_3__12 ] = filterTrajExpDec( trajectories_filtered_all_3__12 );
[ cummDistrCells_all_exp ,cpd_exp_all_3__12] = analyzeCells_1([] ,trj_exp_111208_tatA25degYT_3__12 );
plotCummLLs([  cpd_all_3__12 cpd_exp_all_3__12 cpd_conc_111208_tatA25degYT_3__12],'_3__12',0);

[ trj_exp_111208_tatA25degYT_25__35 ] = filterTrajExpDec( trajectories_filtered_all_25__35 );
[ cummDistrCells_all_exp ,cpd_exp_all_25__35] = analyzeCells_1([] ,trj_exp_111208_tatA25degYT_25__35 );
plotCummLLs([  cpd_all_25__35 cpd_exp_all_25__35 cpd_conc_111208_tatA25degYT_25__35],'_25__35',0);

[ trj_exp_111208_tatA25degYT_36__43 ] = filterTrajExpDec( trajectories_filtered_all_36__43 );
[ cummDistrCells_all_exp ,cpd_exp_all_36__43] = analyzeCells_1([] ,trj_exp_111208_tatA25degYT_36__43 );
plotCummLLs([  cpd_all_3__12 cpd_exp_all_36__43 cpd_conc_111208_tatA25degYT_36__43],'_36__43',0);

[ trj_exp_111208_tatA25degYT_45__48 ] = filterTrajExpDec( trajectories_filtered_all_45__48 );
[ cummDistrCells_all_exp ,cpd_exp_all_45__48] = analyzeCells_1([] ,trj_exp_111208_tatA25degYT_45__48);
plotCummLLs([  cpd_all_45__48 cpd_exp_all_45__48 cpd_conc_111208_tatA25degYT_45__48],'_45__48',0);
