function [cumIntens] = getCumIntens( movieInfo )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here



if ~isempty(movieInfo);
    [len,dummy]=size(movieInfo);
    for frame=1:len
        if ~isempty(movieInfo(frame).psf);
            [numSpots,dummy]=size(movieInfo(frame).psf);
            cumIntens(frame)=0;
            for spot=1:numSpots
                cumIntens(frame)=cumIntens(frame)+movieInfo(frame).psf(spot)*movieInfo(frame).amp(spot);
            end
        else
            cumIntens(frame)=0;
        end
    end
end

