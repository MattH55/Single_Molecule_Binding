function [ cummDistrCells,cummDistrMovie ] = analyzeCells( cells,trajectories )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here



[nrCells,nrTraj]=size(cells);
cummDistrCells=repmat(struct('cummDistr',[],'mean5IntDistr',[],'mean5MaxIntDistr',[],'meanFullIntDistr',[]),nrCells,1);
trajMovie=[];
mean5IntDistrMovie=[];
mean5MaxIntDistrMovie=[];
meanFullIntDistrMovie=[];
meanSqrdMovie=[];
trajNumMovie=[];

for i=1:nrCells
    traj=cells(i,:);
    traj=traj(find(traj));
    mean5IntDistr=[];
    mean5MaxIntDistr=[];
    meanFullIntDistr=[];
    meanSqrd=[];
    trajNum=[];
    for k=1:length(traj)
        if isempty(trajectories(traj(k)).x)
            traj(k)=0;
        end    
    end
    traj=traj(find(traj));
    if isempty(traj)
    else    
        cummDistrCells(i).cummDistr= getCummOutTraj( trajectories, traj);
        trajMovie=horzcat(trajMovie,traj);
        
        for j=1:length(traj)
            
            mean5IntDistr=vertcat(mean5IntDistr,round(trajectories(traj(j)).mean5Int));
            mean5MaxIntDistr=vertcat(mean5MaxIntDistr,round(trajectories(traj(j)).mean5MaxInt));
            meanFullIntDistr=vertcat(meanFullIntDistr,round(trajectories(traj(j)).meanFullInt));
            meanSqrd=vertcat(meanSqrd,trajectories(traj(j)).meanSqrd);
            trajNum=vertcat(trajNum,traj(j));
            
        end
    end
    disp(length(meanSqrd));
    disp(length(mean5IntDistr));
    
   
    
    mean5IntDistrMovie=vertcat(mean5IntDistrMovie,mean5IntDistr);
    [mean5IntDistr,IX]=sort(mean5IntDistr);
    mean5IntDistr=horzcat(mean5IntDistr,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    mean5MaxIntDistrMovie=vertcat(mean5MaxIntDistrMovie,mean5MaxIntDistr);
    [mean5MaxIntDistr,IX]=sort(mean5MaxIntDistr);
    mean5MaxIntDistr=horzcat(mean5MaxIntDistr,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    meanFullIntDistrMovie=vertcat(meanFullIntDistrMovie,meanFullIntDistr);
    [meanFullIntDistr,IX]=sort(meanFullIntDistr);
    meanFullIntDistr=horzcat( meanFullIntDistr,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    cummDistrCells(i).mean5IntDistr=mean5IntDistr;
    cummDistrCells(i).mean5MaxIntDistr=mean5MaxIntDistr;
    cummDistrCells(i).meanFullIntDistr=meanFullIntDistr;
   
     meanSqrdMovie=vertcat(meanSqrdMovie,meanSqrd);
     trajNumMovie=vertcat(trajNumMovie,trajNum);
   
end
%disp('ggggggggggggggg');
%disp(length(mean5IntDistrMovie));
%disp(mean5IntDistrMovie);
%disp(length(meanSqrdMovie));
%disp(length(mean5MaxIntDistrMovie));
%disp(length(meanFullIntDistrMovie));
%disp('gssssssssssssssssss');
cummDistrMovie=getCummOutTraj( trajectories, trajMovie);

[mean5IntDistrMovie,IX]=sort(mean5IntDistrMovie);
cummDistrMovie.mean5IntDistr=horzcat(mean5IntDistrMovie,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));


[meanFullIntDistrMovie,IX]=sort(meanFullIntDistrMovie);
%disp('length(meanSqrdMovie)');
%disp(length(meanSqrdMovie(IX)));
%disp(length(meanFullIntDistrMovie));
cummDistrMovie.meanFullIntDistr=horzcat(meanFullIntDistrMovie,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));
cummDistrMovie.allIntDistr=sort(getCumIntensitiesOutTraject( trajectories,trajMovie ));
[mean5MaxIntDistrMovie,IX]=sort(mean5MaxIntDistrMovie);
cummDistrMovie.mean5MaxIntDistr=horzcat(mean5MaxIntDistrMovie,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));


end

