function [MeanInt ] = getMeanFullIntOutTraj(trajectories)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
for i=1:length(trajectories);
MeanInt(i)= trajectories (i).meanFullInt;
end


end

