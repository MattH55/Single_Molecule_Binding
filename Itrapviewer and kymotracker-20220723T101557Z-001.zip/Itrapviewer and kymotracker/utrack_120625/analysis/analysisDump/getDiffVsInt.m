function [ Diff_Int,dConstant ] = getDiffVsInt( diffusionConstant )

dConstant=repmat(struct('D',[],'int',[]),100,1);
increment=40000;
[diffusionConstantInt,IX]=sort(diffusionConstant(:,1));
diffusionConstantD=diffusionConstant(IX,2);
for i=1:length(diffusionConstantInt)
    disp(round(diffusionConstant(i,1)));
    disp(round(diffusionConstant(i,1)/increment));
    
    disp(dConstant((round(diffusionConstant(i,1)/increment))).D);
    disp('www');
    dConstant((round(diffusionConstant(i,1)/increment))).D=horzcat(dConstant(round(diffusionConstant(i,1)/increment)).D,diffusionConstant(i,2));
    dConstant((round(diffusionConstant(i,1)/increment))).int=horzcat(dConstant(round(diffusionConstant(i,1)/increment)).int,diffusionConstant(i,1));
end
k=0;
for i=1:100
    if ~isempty(dConstant(i).D)
        k=k+1;
        Diff_Int(k,1)=i;
        Diff_Int(k,2)=mean(dConstant(i).D);
        Diff_Int(k,3)=std(dConstant(i).D);
    end

end

