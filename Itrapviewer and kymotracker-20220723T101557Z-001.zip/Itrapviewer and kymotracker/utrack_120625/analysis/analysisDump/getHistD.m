function [Dnm]=getHistD(cpds)
Dnm=[];
for i=1:length(cpds)
    Dnm(i)=cpds(i).diffConstNm;
    
end
x=0:25:500;
figure;
hist(Dnm,x)