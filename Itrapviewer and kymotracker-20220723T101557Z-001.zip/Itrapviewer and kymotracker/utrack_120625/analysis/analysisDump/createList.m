function [ list ] = createList( )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
for i=1:512
    
    list(i)=i;
end

end

