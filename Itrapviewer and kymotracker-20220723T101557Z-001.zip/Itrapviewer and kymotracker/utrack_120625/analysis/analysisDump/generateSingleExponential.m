function [ h ] = generateSingleExponential( )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

x=[0.005 0.001 0.002 0.003 0.007 0.009 0.013 0.01 0.015 0.017 0.02 0.022 0.026 0.029 0.03 0.033 0.038  0.04 0.042 0.045 0.049 0.05 0.055 0.057 0.06 0.064 0.68 0.07 0.076 0.78 0.08 0.081 0.083 0.085 0.088 0.092 ...
    0.095 0.103 0.107 0.11 0.116 0.119 0.125 0.128 0.133 0.138 0.142 0.149 0.155];
h=zeros(length(x),2);
for i=1:length(x)
    
h(i,1)=exp(-(x(i))/(4*0.13*0.06));
h(i,2)=x(i);
end
figure;
semilogy(h(:,2),h(:,1),'ro','MarkerSize',3);
axis([0 0.2 0.01 1])
%Handle=title (nameGraph);
%set(titHandle,'fontsize',16);
xlabel('r^2 (\mum^2/s)');
ylabel('1-P (r^2,60ms');
xlhand = get(gca,'xlabel');
ylhand = get(gca,'ylabel');
set(gca,'XTick',0:0.1:0.2)

set(xlhand,'fontsize',16);
set(ylhand,'fontsize',16);
end

