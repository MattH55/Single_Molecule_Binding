function [stdR]=stdRSquared(x,y)




xCenter=mean(x);
yCenter=mean(y);

for i=1:length(x)
    r(i)=sqrt((x(i)-xCenter)^2+(y(i)-yCenter)^2);
end

stdR=std(r);

        
   
    

