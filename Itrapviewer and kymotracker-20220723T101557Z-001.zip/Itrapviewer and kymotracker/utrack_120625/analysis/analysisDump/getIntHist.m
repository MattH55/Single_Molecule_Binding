function [cummDistr]=getIntHist(allMeanRDispl)
%OVERLAYTRACKSMOVIENEW Overlays tracks obtained via trackCloseGapsKalman on movies with variable color-coding
%
%SYNPOSIS overlayTracksMovieNew(tracksFinal,startend,dragtailLength,...
%    saveMovie,movieName,filterSigma,classifyGaps,highlightES,showRaw,...
%    imageRange,onlyTracks,classifyLft,diffAnalysisRes,intensityScale,...
%    colorTracks)
%
%INPUT  tracksFinal   : Output of trackCloseGapsKalman.

%OUTPUT If movie is to be saved, the QT movie is written into directory


%REMARKS Color-coding:








allMeanRDispl=sort(allMeanRDispl);
cummDistr=[];
disp(size(allMeanRDispl,1));
for i=1:size(allMeanRDispl,2)
    disp('jjj');
    cummDistr(i,2)=1-(i/(size(allMeanRDispl,2)+1));
    cummDistr(i,1)=allMeanRDispl(i);
end
    




        
   
    

