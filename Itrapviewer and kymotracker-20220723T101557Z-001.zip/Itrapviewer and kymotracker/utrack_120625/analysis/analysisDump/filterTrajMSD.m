function [ trajFilter,trajRest ] = filterTrajMSD( traj,range )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
j=0;
k=0;
for i=1:length(traj)
    if traj(i).diffConstUm>=range(1) && traj(i).diffConstUm<=range(2) 
        j=j+1;
        trajFilter(j,1)=traj(i);
    else
        k=k+1;
        trajRest(k,1)=traj(i);
    end
end

