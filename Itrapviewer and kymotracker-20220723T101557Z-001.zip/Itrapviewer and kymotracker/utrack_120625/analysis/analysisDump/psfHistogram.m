function [histData,hist]=ampHistogram(segments)
%OVERLAYTRACKSMOVIENEW Overlays tracks obtained via trackCloseGapsKalman on movies with variable color-coding
%
%SYNPOSIS overlayTracksMovieNew(tracksFinal,startend,dragtailLength,...
%    saveMovie,movieName,filterSigma,classifyGaps,highlightES,showRaw,...
%    imageRange,onlyTracks,classifyLft,diffAnalysisRes,intensityScale,...
%    colorTracks)
%
%INPUT  tracksFinal   : Output of trackCloseGapsKalman.

%OUTPUT If movie is to be saved, the QT movie is written into directory


%REMARKS Color-coding:


segments=segments';
sort(segments);
numTracks=size(segments,1);
interval=0.1;
maxSegmentsLength=4.0;
histLength=round(1/interval)*maxSegmentsLength+1;
hist = zeros(histLength,1);

for i=1:numTracks
    if isnan(segments(i))
        segments(i)=0;
    end    
      
    histData(i)=segments(i);
    disp(segments(i));
    hist(1+round(segments(i)/interval))=hist(1+round(segments(i)/interval))+1;
end

        
   
    

