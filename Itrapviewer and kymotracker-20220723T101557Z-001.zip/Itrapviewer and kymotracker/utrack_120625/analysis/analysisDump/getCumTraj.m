function [ traj ] = getCumTraj( traj )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
for i=1:length(traj)
    [ cummDistrCells,cummDistrMovie ] = analyzeCells_1( [1],traj(i) );
    traj(i).oneStep=cummDistrMovie.oneStep;
    traj(i).twoStep=cummDistrMovie.twoStep;
    traj(i).threeStep=cummDistrMovie.threeStep;
    traj(i).fourStep=cummDistrMovie.fourStep;
    traj(i).sixtStep=cummDistrMovie.sixStep;
    traj(i).eightStep=cummDistrMovie.eightStep;
end

