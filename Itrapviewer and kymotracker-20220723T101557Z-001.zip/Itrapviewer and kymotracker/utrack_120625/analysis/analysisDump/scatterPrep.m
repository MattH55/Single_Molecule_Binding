function [ intensities, diffusionConstant ] = scatterPrep( traj )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
for i=1:length(traj)

    intensities(i)=traj(i).mean5MaxInt_gauss_2pi;
    diffusionConstant(i)=traj(i).diffConstNm;
end
end

