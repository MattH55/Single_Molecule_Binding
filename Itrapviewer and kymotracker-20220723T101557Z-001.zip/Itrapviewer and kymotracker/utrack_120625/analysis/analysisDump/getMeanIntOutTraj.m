function [MeanInt ] = getMeanIntOutTraj(trajectories)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
for i=1:length(trajectories);
MeanInt(i)= trajectories (i).meanInt;
end


end

