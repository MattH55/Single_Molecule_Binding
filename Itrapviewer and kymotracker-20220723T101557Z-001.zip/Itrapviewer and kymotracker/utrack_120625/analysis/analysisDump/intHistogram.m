function [histData,hist]=intHistogram(segments,psf)
%OVERLAYTRACKSMOVIENEW Overlays tracks obtained via trackCloseGapsKalman on movies with variable color-coding
%
%SYNPOSIS overlayTracksMovieNew(tracksFinal,startend,dragtailLength,...
%    saveMovie,movieName,filterSigma,classifyGaps,highlightES,showRaw,...
%    imageRange,onlyTracks,classifyLft,diffAnalysisRes,intensityScale,...
%    colorTracks)
%
%INPUT  tracksFinal   : Output of trackCloseGapsKalman.

%OUTPUT If movie is to be saved, the QT movie is written into directory


%REMARKS Color-coding:

segments=segments';
numTracks=size(segments,1);
disp('numTracks');
disp(numTracks);
intens=[];
for i=1:numTracks
    if isnan(segments(i))
        intens(i)=0;
    else    
        intens(i)=segments(i)*psf(i);
        
    end
end
disp(intens);
sort(intens);

interval=0.00001;
maxSegmentsLength=0.005;
histLength=round(1/interval)*maxSegmentsLength+1;
hist = zeros(histLength,1);

for i=1:numTracks
    histData(i)=intens(i);
    disp('intens(i)');
    disp(intens(i));
    hist(1+round(intens(i)/interval))=hist(1+round(intens(i)/interval))+1;
end

        
   
    

