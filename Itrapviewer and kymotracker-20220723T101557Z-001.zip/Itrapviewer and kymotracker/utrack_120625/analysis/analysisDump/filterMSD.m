function [ cpds_conc_fast,cpds_fast ] = filterMSD( cpds,upper,downer )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

j=0;
for i=1:length(cpds)
    if cpds(i).diffConstNm>downer && cpds(i).diffConstNm<upper
    j=j+1;
    cpds_fast(j)=cpds(i);
    end
end
 plotCummLLs(cpds_fast,'fast');
 [ cummCells_dummy,cpds_conc_fast ] = analyzeCells_1( [],cpds_fast );
 plotCummLLs(cpds_conc_fast,'conc_fast');
end

