function [histData]=meanRHistogram(segments)
%OVERLAYTRACKSMOVIENEW Overlays tracks obtained via trackCloseGapsKalman on movies with variable color-coding
%
%SYNPOSIS overlayTracksMovieNew(tracksFinal,startend,dragtailLength,...
%    saveMovie,movieName,filterSigma,classifyGaps,highlightES,showRaw,...
%    imageRange,onlyTracks,classifyLft,diffAnalysisRes,intensityScale,...
%    colorTracks)
%
%INPUT  tracksFinal   : Output of trackCloseGapsKalman.

%OUTPUT If movie is to be saved, the QT movie is written into directory


%REMARKS Color-coding:




numTracks=size(segments,1);
interval=0.25;
maxSegmentsLength=25;
histLength=round(1/interval)*maxSegmentsLength+1;
hist = zeros(histLength,1);

for i=1:numTracks
    histData(i)=segments(i).meanRSqrd;
    disp(segments(i).meanRSqrd);
    hist(1+round(segments(i).meanRSqrd/interval))=hist(1+round(segments(i).meanRSqrd/interval))+1;
end

        
   
    

