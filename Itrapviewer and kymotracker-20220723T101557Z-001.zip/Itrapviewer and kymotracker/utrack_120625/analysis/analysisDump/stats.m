function [ stat] = stats(trajectories,meanR,dR)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


stat = repmat(struct('maxInt',[],'averInt',[],'meanInt',[],'meanAvInt',[],'maxAmp',[],'meanAmp',[],'averAmp',[],'meanAvAmp',[]),length(trajectories),1);

disp(length(trajectories));
for j=1:50
    k=0;
    meanR=(2*dR)*(j-1);
    disp(meanR);
    
    for i=1:length(trajectories)
    
        if trajectories(i).mean>meanR-dR && trajectories(i).mean<meanR+dR
            k=k+1;
            stat(j).maxInt(k)=trajectories(i).maxInt;
            stat(j).maxAmp(k)=trajectories(i).maxAmp;
            stat(j).averInt(k)=trajectories(i).meanInt;
            stat(j).averAmp(k)=trajectories(i).meanAmp;
            
            stat(j).traj(k)=j;
            if trajectories(i).maxInt==0
                disp('i');
                 disp(i);
            end
        end
    if isempty(stat(j).maxInt)
    else
        stat(j).meanInt=mean(stat(j).maxInt);
        stat(j).meanAmp=mean(stat(j).maxAmp);
        stat(j).meanAvInt=mean(stat(j).averInt);
        stat(j).meanAvAmp=mean(stat(j).averAmp);
    end
    end
end

