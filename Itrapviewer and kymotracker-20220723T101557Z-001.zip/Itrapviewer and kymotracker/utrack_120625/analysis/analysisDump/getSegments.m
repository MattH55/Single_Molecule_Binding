function [segmentsSqrd]=getSegments(tracksFinal)
%OVERLAYTRACKSMOVIENEW Overlays tracks obtained via trackCloseGapsKalman on movies with variable color-coding
%
%SYNPOSIS overlayTracksMovieNew(tracksFinal,startend,dragtailLength,...
%    saveMovie,movieName,filterSigma,classifyGaps,highlightES,showRaw,...
%    imageRange,onlyTracks,classifyLft,diffAnalysisRes,intensityScale,...
%    colorTracks)
%
%INPUT  tracksFinal   : Output of trackCloseGapsKalman.

%OUTPUT If movie is to be saved, the QT movie is written into directory


%REMARKS Color-coding:





%% Output

tracksFinalFiltered    = [];

%%
tracksFinalFiltered=tracksFinal;
numTracks=size(tracksFinal,1);
%length(tracksFinal);
trackSel=getTrackSel(tracksFinal);


segmentsSqrd = repmat(struct('xSqrd',[],...
    'ySqrd',[],'rSqrd',[],'meanRSqrd',[]),numTracks,1);
segmentFlag=[];
for i=1:numTracks
    index=0;
    segmentFlag(i)=0;
    for j=1:trackSel(i,3)-1
        if isnan(tracksFinalFiltered(i).tracksCoordAmpCG(1,j*8+1))...
                || isnan(tracksFinalFiltered(i).tracksCoordAmpCG(1,(j-1)*8+1))
        else
            
            index=index+1;
            xSqrd=(tracksFinalFiltered(i).tracksCoordAmpCG(1,j*8+1)...
                -tracksFinalFiltered(i).tracksCoordAmpCG(1,(j-1)*8+1))^2;
            
            ySqrd=(tracksFinalFiltered(i).tracksCoordAmpCG(1,j*8+2)...
                -tracksFinalFiltered(i).tracksCoordAmpCG(1,(j-1)*8+2))^2;
            rSqrd=xSqrd+ySqrd;
            
            xxx=rSqrd;
            
                       
            segmentsSqrd(i).xSqrd(index)=xSqrd;
            segmentsSqrd(i).ySqrd(index)=ySqrd;
            segmentsSqrd(i).rSqrd(index)=rSqrd;
        end
    end
end

for i=1:numTracks
    meanSqrd=0;
    for j=1:size(segmentsSqrd(i).xSqrd,2)
        meanSqrd=meanSqrd+segmentsSqrd(i).rSqrd(j);
    end
    segmentsSqrd(i).meanRSqrd=meanSqrd/size(segmentsSqrd(i).xSqrd,2);
end

    




        
   
    

