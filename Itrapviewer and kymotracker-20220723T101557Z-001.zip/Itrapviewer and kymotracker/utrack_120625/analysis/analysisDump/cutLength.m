function [newTracks]=cutLength(tracksFinal,startFrame,endFrame)
%OVERLAYTRACKSMOVIENEW Overlays tracks obtained via trackCloseGapsKalman on movies with variable color-coding
%
%SYNPOSIS overlayTracksMovieNew(tracksFinal,startend,dragtailLength,...
%    saveMovie,movieName,filterSigma,classifyGaps,highlightES,showRaw,...
%    imageRange,onlyTracks,classifyLft,diffAnalysisRes,intensityScale,...
%    colorTracks)
%
%INPUT  tracksFinal   : Output of trackCloseGapsKalman.

%OUTPUT If movie is to be saved, the QT movie is written into directory


%REMARKS Color-coding:







%%
tracksFinalFiltered=tracksFinal;
discard=0;
numTracks=size(tracksFinal,1);
%length(tracksFinal);
trackSel=getTrackSel(tracksFinal);

newTracks = repmat(struct('tracksFeatIndxCG',[],...
    'tracksCoordAmpCG',[],'seqOfEvents',[]),numTracks,1);

tempTracks = repmat(struct('tracksFeatIndxCG',[],...
    'tracksCoordAmpCG',[],'seqOfEvents',[]),numTracks,1);

for i=1:numTracks
    tempTracks(i).seqOfEvents=tracksFinalFiltered(i).seqOfEvents;
    newTracks(i).seqOfEvents=tracksFinalFiltered(i).seqOfEvents;
end


discardedTraj=[];
count=0;
for i=1:numTracks
    %if  trackSel(i,1)<startFrame && trackSel(i,2)>endFrame    
    %    discard=discard+1;
    %    discardedTraj(discard)=i;
    %else
        ind=[];
        temp=[];
        
        tempTracks(i).tracksFeatIndxCG=tracksFinalFiltered(i).tracksFeatIndxCG;
        tempTracks(i).seqOfEvents=tracksFinalFiltered(i).seqOfEvents;
        
        if trackSel(i,2)>(endFrame)
            diff=trackSel(i,2)-endFrame;
            cutEnd=trackSel(i,3)-diff;
            %disp('hhh');
            %disp(trackSel(i,3));
            %disp(diff);
            %disp(cutEnd*8+1);
            if cutEnd<0
                disp('diff<cutEnd');
                disp(cutEnd);
                disp(diff);
                disp(trackSel(i,2));
                disp(endFrame);
                
                disp('diff<cutEnd');
                tracksFinalFiltered(i).tracksCoordAmpCG(1,1:end)=530;
            else
                tracksFinalFiltered(i).tracksCoordAmpCG(1,cutEnd*8+1:end)=530;
            end
            tempTracks(i).seqOfEvents(end,1)=endFrame;
        end
        if trackSel(i,1)<(startFrame)
            diff=startFrame-trackSel(i,1);
            cutStart=diff;
            if diff>=trackSel(i,3)
                disp('diff>trackSel');
                tracksFinalFiltered(i).tracksCoordAmpCG(1,1:end)=530;
            else
                tracksFinalFiltered(i).tracksCoordAmpCG(1,1:cutStart*8)=530;
            end
            tempTracks(i).seqOfEvents(1,1)=startFrame;
        end
        %tracksFinalFiltered(i).tracksCoordAmpCG(1,:)
        ind=find(tracksFinalFiltered(i).tracksCoordAmpCG(1,:)~=530);
        temp=tracksFinalFiltered(i).tracksCoordAmpCG(1,ind);
        disp('ind');
        disp(ind);
        %tracksFinalFiltered(i).tracksCoordAmpCG(1,:)
        %tracksFinalFiltered(i).tracksCoordAmpCG(1,:)=[];
        %tracksFinalFiltered(i).tracksCoordAmpCG=reshape(tracksFinalFiltered(i).tracksCoordAmpCG,0,0);
        
        
        %disp('sizeind');
        %disp(size(ind,2));
        %disp(temp);
        tempTracks(i).tracksCoordAmpCG(1,1:size(ind,2))=temp;
       
        if size(ind,2)==0
            
        else
            if isnan(tempTracks(i).tracksCoordAmpCG(1,1))
                flag=1;
                c=1;
                trackSelTemp=getTrackSel(tempTracks);
                while flag==1
                    tempTracks(i).tracksCoordAmpCG(1,c)=530;
                    c=c+1;
                    if isnan(tempTracks(i).tracksCoordAmpCG(1,c))
                    else
                        flag=0;
                    end
                end
                tempTracks(i).seqOfEvents(1,1)=trackSelTemp(i,1)+round(c/8);
                disp(round(c/8));
            end
        end
        
        ind=find(tempTracks(i).tracksCoordAmpCG(1,:)~=530);
        temp=tempTracks(i).tracksCoordAmpCG(1,ind);
        newTracks(i).tracksCoordAmpCG(1,1:size(ind,2))=temp;
        newTracks(i).seqOfEvents=tempTracks(i).seqOfEvents;
        if size(ind,2)==0
            disp('ddiscard');
            count=count+1;
            discardedTraj(count)=i;
        end
                
        %disp('j');
    %end
end
newTracks(discardedTraj)=[];




        
   
    

