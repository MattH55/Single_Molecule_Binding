function [tracksFinalFiltered]=filterLength(tracksFinal,length)
%OVERLAYTRACKSMOVIENEW Overlays tracks obtained via trackCloseGapsKalman on movies with variable color-coding
%
%SYNPOSIS overlayTracksMovieNew(tracksFinal,startend,dragtailLength,...
%    saveMovie,movieName,filterSigma,classifyGaps,highlightES,showRaw,...
%    imageRange,onlyTracks,classifyLft,diffAnalysisRes,intensityScale,...
%    colorTracks)
%
%INPUT  tracksFinal   : Output of trackCloseGapsKalman.

%OUTPUT If movie is to be saved, the QT movie is written into directory


%REMARKS Color-coding:





%% Output

tracksFinalFiltered    = [];

%%
tracksFinalFiltered=tracksFinal;
discard=0;
numTracks=size(tracksFinal,1);
%length(tracksFinal);
trackSel=getTrackSel(tracksFinal);

discardedTraj=[];
for i=1:numTracks
    if trackSel(i,3)<length 
        discard=discard+1;
        discardedTraj(discard)=i;
    end
end

tracksFinalFiltered(discardedTraj)=[];




        
   
    

