function [ trajectories_org,trajectories,trajNum ] = rangeTraj_0( trajectories_org,traj )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

if nargin<2 || isempty(traj)
    traj=1:length(trajectories_org);
else
    traj=traj(find(traj));
end

for i=1:length(traj)
    %%if ~isempty(trajectories_org(traj).range)
    rangeDim=size(trajectories_org(traj(i)).range);
    startFrame=trajectories_org(traj(i)).frames(1);
    template=zeros(1,length(trajectories_org(traj(i)).x));
    if ~isempty(trajectories_org(traj(i)).linkNext)
        trajectories_org(trajectories_org(traj(i)).linkNext).linkPrevious=traj(i);
    end
    if isempty(trajectories_org(traj(i)).range)||numel(trajectories_org(traj(i)).range)<2||trajectories_org(traj(i)).range(1,2)==0 
        template(1,:)=1;
    else
        for  j=1:rangeDim(1)

                startEntry=trajectories_org(traj(i)).range(j,1)-startFrame+1;
                endEntry=trajectories_org(traj(i)).range(j,2)-startFrame+1;
                entries=startEntry:endEntry;
                template(entries)=1;
        end
    end
    trajectories_org(traj(i)).x=trajectories_org(traj(i)).x.*template;
    trajectories_org(traj(i)).y=trajectories_org(traj(i)).y.*template;
    
    trajectories_org(traj(i)).amp=trajectories_org(traj(i)).amp.*template;
    trajectories_org(traj(i)).bgr=trajectories_org(traj(i)).bgr.*template;
    trajectories_org(traj(i)).psf=trajectories_org(traj(i)).psf.*template;
    trajectories_org(traj(i)).intens=trajectories_org(traj(i)).intens.*template;
    
end
%disp('trajectories_org(8).x');
%disp(trajectories_org(8).x);
k=0;
i=0;
trajNum=[];
while k==0
    i=i+1;
    trajNumTemp=traj(1);
    trajNumCurrentPrevious=traj(1);
    trajNumCurrentNext=traj(1);
    traj(traj==trajNumCurrentPrevious)=[];
    
    %disp('i');
    %disp(i);
    exit=0;
    while exit==0
        if ~isempty(trajectories_org(trajNumCurrentPrevious).linkPrevious)
            if trajectories_org(trajectories_org(trajNumCurrentPrevious).linkPrevious).linkNext==trajNumCurrentPrevious;
                %disp('trajectories_org(trajNumCurrentPrevious).linkPrevious');
                %disp(trajectories_org(trajNumCurrentPrevious).linkPrevious);
                %disp('trajNum(i)first previous');
                %disp(trajNumTemp);
                trajNumTemp(1:(length(trajNumTemp)+1))=horzcat(trajectories_org(trajNumCurrentPrevious).linkPrevious,trajNumTemp);
                trajNumCurrentPrevious=trajectories_org(trajNumCurrentPrevious).linkPrevious;
                traj(traj==trajNumCurrentPrevious)=[];
                %disp('previous');
                %disp('trajNum');
                %disp(trajNumTemp);
            else
                %disp('Mismatch');
                exit=1;
            end
        else
            %disp('no previous');
            exit=1;
        end
    end
    exit=0;
    while exit==0
        if ~isempty(trajectories_org(trajNumCurrentNext).linkNext)
            if trajectories_org(trajectories_org(trajNumCurrentNext).linkNext).linkPrevious==trajNumCurrentNext;
                %disp(trajectories_org(trajNumCurrentPrevious).linkPrevious);
                %disp('trajNum(i)first');
                %disp(trajNumTemp);
                trajNumTemp(1:(length(trajNumTemp)+1))=horzcat(trajNumTemp,trajectories_org(trajNumCurrentNext).linkNext);
                trajNumCurrentNext=trajectories_org(trajNumCurrentNext).linkNext;
                traj(traj==trajNumCurrentNext)=[];
                %disp('next');
                %disp('trajNum(i)second');
                %disp(trajNumTemp);
            else
                disp('Mismatch');
                exit=1;
            end
        else
            disp('no next');
            exit=1;
        end
    end
    trajNum(i,1:length(trajNumTemp))=trajNumTemp;
    %disp('traj');
    %disp(traj);
    if isempty(traj)
        k=1;
    end
end

%disp('trajNumFinal');
%disp(trajNum);
[trajN,dummy]=size(trajNum);
for i=1:trajN
    %disp('i');
    %disp(i);
    %skip zero elements due to ranging in beginning and end of trajectories
    indexNonZero=find(trajectories_org(trajNum(i,1)).x>0);
    %disp('indexNonZero');
    %disp(indexNonZero);
    %disp('trajectories_org(trajNum(i,1)).x');
    %disp(trajectories_org(trajNum(i,1)).x);
    
    %for number of trajectories to be concatenated
    concNum=find(trajNum(i,:));
    
    trajectories(i).trajNum=trajNum(i,1:length(concNum));
    trajectories(i).frames=trajectories_org(trajNum(i,1)).frames(indexNonZero(1):indexNonZero(end));
    trajectories(i).x=trajectories_org(trajNum(i,1)).x(indexNonZero(1):indexNonZero(end));
    trajectories(i).y=trajectories_org(trajNum(i,1)).y(indexNonZero(1):indexNonZero(end));
    trajectories(i).rSqrd=[];
    trajectories(i).rSqrdUm=[];
    trajectories(i).amp=trajectories_org(trajNum(i,1)).amp(indexNonZero(1):indexNonZero(end));
    trajectories(i).psf=trajectories_org(trajNum(i,1)).psf(indexNonZero(1):indexNonZero(end));
    trajectories(i).bgr=trajectories_org(trajNum(i,1)).bgr(indexNonZero(1):indexNonZero(end));
    trajectories(i).intens=trajectories_org(trajNum(i,1)).intens(indexNonZero(1):indexNonZero(end));
    

    
    %for number of trajectories to be concatenated
    
    for j=2:length(concNum)
        %disp('trajNum(i,j)');
        %disp(trajNum(i,j));
        
        %skip zero elements due to ranging in beginning and end of
        %trajectorY
        indexNonZero=find(trajectories_org(trajNum(i,j)).x>0);
        
        %store information in dummies
        xDummy=trajectories_org(trajNum(i,j)).x(indexNonZero(1):indexNonZero(end));
        yDummy=trajectories_org(trajNum(i,j)).y(indexNonZero(1):indexNonZero(end));
        ampDummy=trajectories_org(trajNum(i,j)).amp(indexNonZero(1):indexNonZero(end));
        bgrDummy=trajectories_org(trajNum(i,j)).bgr(indexNonZero(1):indexNonZero(end));
        psfDummy=trajectories_org(trajNum(i,j)).psf(indexNonZero(1):indexNonZero(end));
        intensDummy=trajectories_org(trajNum(i,j)).intens(indexNonZero(1):indexNonZero(end));
        framesDummy=trajectories_org(trajNum(i,j)).frames(indexNonZero(1):indexNonZero(end));
        
        %disp('xDummy');
        %disp(xDummy);
        %disp('framesDummy');
        %disp(framesDummy);
        %disp('trajectories_org(trajNum(i,j)).frames(indexNonZero(1))');
        %disp(trajectories_org(trajNum(i,j)).frames(indexNonZero(1)));
        %if framesDummy(1)>trajectories(i).frames(end)
        %    lengthDiff=trajectories_org(trajNum(i,j)).frames(indexNonZero(1))-(trajectories(i).frames(1,end)+1);
        %    disp('trajectories(i).xbeforeZeros');
        %   disp(trajectories(i).x);
        %    trajectories(i).x(length(trajectories(i).x)+1:(length(trajectories(i).x)+lengthDiff))=0;
        %    trajectories(i).x(length(trajectories(i).x)+1:(length(trajectories(i).x)+length(xDummy)))=xDummy;
        %    disp('trajectories(i).xafterZeros');
        %    disp(trajectories(i).x);
        %    disp('trajectories(i).frames');
        %    disp(trajectories(i).frames);
        %    disp('trajectories(i).frames(1):(trajectories(i).frames(1)+length(trajectories(i).x))')
        %    disp(trajectories(i).frames(1):(trajectories(i).frames(1)+length(trajectories(i).x)-1))
        %    trajectories(i).frames(1:length(trajectories(i).x))=trajectories(i).frames(1):(trajectories(i).frames(1)+length(trajectories(i).x)-1);
        %    disp('hsahhshashash');
        %else
            %disp('second else');
            %disp('framesDummy(1,1)');
            %disp(framesDummy(1,1));
            %disp('trajectories(i).frames(1,end)');
            %disp(trajectories(i).frames(1,end));
            lengthDiff=framesDummy(1,1)-trajectories(i).frames(1,end)-1;
            %disp('lengthDiff');
            %disp(lengthDiff);
            %disp('length');
            %disp(length(trajectories(i).x)+lengthDiff+1:length(trajectories(i).x)+lengthDiff+length(xDummy));
            %disp('xDummy');
            %disp(xDummy);
            %disp('trajectories(i).x before dummy extension');
            %disp(trajectories(i).x);
            trajectories(i).x(length(trajectories(i).x)+lengthDiff+1:length(trajectories(i).x)+lengthDiff+length(xDummy))=xDummy;
            trajectories(i).y(length(trajectories(i).y)+lengthDiff+1:length(trajectories(i).y)+lengthDiff+length(yDummy))=yDummy;
            trajectories(i).amp(length(trajectories(i).amp)+lengthDiff+1:length(trajectories(i).amp)+lengthDiff+length(ampDummy))=ampDummy;
            trajectories(i).bgr(length(trajectories(i).bgr)+lengthDiff+1:length(trajectories(i).bgr)+lengthDiff+length(bgrDummy))=bgrDummy;
            trajectories(i).intens(length(trajectories(i).intens)+lengthDiff+1:length(trajectories(i).intens)+lengthDiff+length(intensDummy))=intensDummy;
            trajectories(i).psf(length(trajectories(i).psf)+lengthDiff+1:length(trajectories(i).psf)+lengthDiff+length(psfDummy))=psfDummy;
            
            %disp('trajectories(i).x(length(trajectories(i).x)+lengthDiff+1:length(trajectories(i).x)+lengthDiff+length(xDummy))=xDummy;');
            %disp(trajectories(i).x);
            trajectories(i).frames(1:length(trajectories(i).x))=trajectories(i).frames(1):(trajectories(i).frames(1)+length(trajectories(i).x)-1);
            
        %end
    end
end


traj=1:length(trajectories);

for i=1:length(trajectories)
        for j=1:length(trajectories(traj(i)).x)-1
            if trajectories(traj(i)).x(1,j)>0 && trajectories(traj(i)).x(1,j+1)>0
               trajectories(traj(i)).rSqrd(1,j)=(trajectories(traj(i)).x(1,j)-trajectories(traj(i)).x(1,j+1))^2+(trajectories(traj(i)).y(1,j)-trajectories(traj(i)).y(1,j+1))^2; 
            else
                trajectories(traj(i)).rSqrd(1,j)=0;
            end
        end
        trajectories(traj(i)).rSqrdUm=trajectories(traj(i)).rSqrd*0.08*0.08;

        if ~isempty(trajectories(traj(i)).rSqrd)
            rSqrd = trajectories(traj(i)).rSqrd(trajectories(traj(i)).rSqrd~=0);

            trajectories(traj(i)).meanSqrd=mean(rSqrd);
            trajectories(traj(i)).diffConstUm=(trajectories(traj(i)).meanSqrd*0.08*0.08/(4*0.032));
            trajectories(traj(i)).diffConstNm=(trajectories(traj(i)).meanSqrd*80*80/(4*32));
        else
            trajectories(traj(i)).meanSqrd=[];
            trajectories(traj(i)).diffConstUm=[];
            trajectories(traj(i)).diffConstNm=[];
        end
        if ~isempty(trajectories(i).rSqrd)
            trajectories(traj(i)).maxInt=max(trajectories(traj(i)).intens(:));
            trajectories(traj(i)).maxAmp=max(trajectories(traj(i)).amp(:));
            trajectories(traj(i)).maxPsf=max(trajectories(traj(i)).psf(:));
            trajectories(traj(i)).mean5Int=0;
            trajectories(traj(i)).mean5Amp=0;
            trajectories(traj(i)).meanFullInt=0;
            %lenTraj=length(trajectories(traj(i)).intens);
            ll=0;
            nonZeroEntries=trajectories(traj(i)).intens>0;
            nonZeroInt=trajectories(traj(i)).intens(nonZeroEntries);
            nonZeroAmp=trajectories(traj(i)).amp(nonZeroEntries);
            nonZeroPsf=trajectories(traj(i)).psf(nonZeroEntries);
            lenTraj=length(nonZeroInt);
            %for k=1:lenTraj
            %    if trajectories(traj(i)).intens(k)>0
            %        ll=ll+1;
            %        trajectories(traj(i)).meanFullInt=trajectories(traj(i)).meanFullInt+mean(trajectories(traj(i)).intens(k));
            %    end
            %end
            %trajectories(traj(i)).meanFullInt=trajectories(traj(i)).meanFullInt/ll;
            trajectories(traj(i)).meanFullInt=mean(nonZeroInt);
            trajectories(traj(i)).meanFullAmp=mean(nonZeroAmp);
            if lenTraj>4
                %ll=0;
                %for k=1:5
                %    if trajectories(traj(i)).intens(k)>0
                %    ll=ll+1;
                %    trajectories(traj(i)).mean5Int=trajectories(traj(i)).mean5Int+mean(trajectories(traj(i)).intens(k));
                %    trajectories(traj(i)).mean5Amp=trajectories(traj(i)).mean5Amp+mean(trajectories(traj(i)).amp(k));
                %    end
                %end
                %trajectories(traj(i)).mean5Int=trajectories(traj(i)).mean5Int/ll;
                %trajectories(traj(i)).mean5Amp=trajectories(traj(i)).mean5Amp/ll;
                trajectories(traj(i)).mean5Int=mean(nonZeroInt(1:5));
                trajectories(traj(i)).mean5Amp=mean(nonZeroAmp(1:5));
                nonZeroIntSort=sort(nonZeroInt,'descend');
                trajectories(traj(i)).mean5MaxInt=mean(nonZeroIntSort(1:5));
            else
                %ll=0;

                %for k=1:lenTraj

                 %  if trajectories(traj(i)).intens(k)>0
                 %   ll=ll+1;
                %    trajectories(traj(i)).mean5Int=trajectories(traj(i)).mean5Int+mean(trajectories(traj(i)).intens(k));
                 %   trajectories(traj(i)).mean5Amp=trajectories(traj(i)).mean5Amp+mean(trajectories(traj(i)).amp(k));
                %    end
                %end
                trajectories(traj(i)).mean5Int=trajectories(traj(i)).meanFullInt;
                trajectories(traj(i)).mean5Amp=trajectories(traj(i)).meanFullAmp;
                trajectories(traj(i)).mean5MaxInt=trajectories(traj(i)).meanFullInt;
            end
        end
   
 
    
end
