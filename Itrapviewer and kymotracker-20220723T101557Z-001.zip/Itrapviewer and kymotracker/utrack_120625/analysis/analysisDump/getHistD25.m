Dnm=[];
for i=1:length(cpds1)
    Dnm25(i)=cpds1(i).diffConstNm;
    
end
x=0:25:500;
figure;
hist(Dnm25,x)