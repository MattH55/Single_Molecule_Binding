function [ trajectories ] = makeGaussInt( trajectories )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


numTraj=length(trajectories);

for i=1:numTraj
    numFrames=length(trajectories(i).psf);
    for k=1:numFrames
        trajectories(i).intens(k)=trajectories(i).intens(k)*trajectories(i).psf(k)*2*pi;
    end    
end

