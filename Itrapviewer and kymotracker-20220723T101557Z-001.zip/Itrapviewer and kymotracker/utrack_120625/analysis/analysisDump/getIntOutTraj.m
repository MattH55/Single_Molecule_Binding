function [ int5Max,intAll,int5Mean ] = getIntOutTraj( trajectories )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

int5Max=[];
intAll=[];
int5Mean=[];
for i=1:length(trajectories)
    intAll=horzcat(intAll,trajectories(i).int_gauss_2pi);
    int5Max=horzcat(int5Max,trajectories(i).mean5MaxInt_gauss_2pi);
    int5Mean=horzcat(int5Mean,trajectories(i).mean5Int_gauss_2pi);
end
end
