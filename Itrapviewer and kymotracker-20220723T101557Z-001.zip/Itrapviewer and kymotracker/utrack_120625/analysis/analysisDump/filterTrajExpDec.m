function [ trajFiltered ] = filterTrajExpDec( trajectories )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
numTracks=1;
trajFiltered = repmat(struct('x',[],'y',[],'rSqrd',[],'rSqrdUm',[],...
    'amp',[],'bgr',[],'psf',[],'intens',[],'int_gauss',[],'int_loc',[],...
    'int_gauss_2pi',[],'int_loc_2pi',[],'meanSqrd',[],...
    'maxInt',[],'maxInt_gauss',[],'maxInt_loc',[],'maxInt_gauss_2pi',[],'maxInt_loc_2pi',[],'maxAmp',[],'maxPsf',[],...
    'mean5Int',[],'mean5Int_gauss',[],'mean5Int_loc',[],'mean5Int_gauss_2pi',[],'mean5Int_loc_2pi',[],'mean5Amp',[],...
    'meanFullInt',[],'meanFullInt_gauss',[],'meanFullInt_loc',[],'meanFullInt_gauss_2pi',[],'meanFullInt_loc_2pi',[],...
    'mean5MaxInt',[],'mean5MaxInt_gauss',[],'mean5MaxInt_loc',[],'mean5MaxInt_gauss_2pi',[],'mean5MaxInt_loc_2pi',[],...
    'frames',[],'trajNum',[],...
    'range',[],'linkNext',[],'linkPrevious',[]),numTracks,1);

j=0;
numOfTraj=length(trajectories);
for i=1:numOfTraj
    
    intMaxGauss=trajectories(i).mean5MaxInt_gauss_2pi;
    frameStart=trajectories(i).frames(1);
    intExpected=45000*exp(-(frameStart-1)/300)+8000;
    %intExpected=0;
    %disp('trajectories(i).frames');
    %disp('frameStart');
    %disp('intExpected');
    %disp('intMaxGauss');
    %disp(trajectories(i).frames);
    %disp(frameStart);
    %disp(intExpected);
    %disp(intMaxGauss);
    if intExpected<intMaxGauss 
        j=j+1;
        
       trajFiltered(j).x=trajectories(i).x;
       trajFiltered(j).y=trajectories(i).y;
       trajFiltered(j).rSqrd=trajectories(i).rSqrd;
       trajFiltered(j).rSqrdUm=trajectories(i).rSqrdUm;
       trajFiltered(j).amp=trajectories(i).amp;
       trajFiltered(j).psf=trajectories(i).psf;
       trajFiltered(j).bgr=trajectories(i).bgr;
       trajFiltered(j).intens=trajectories(i).intens;
       trajFiltered(j).int_gauss=trajectories(i).int_gauss;
       trajFiltered(j).int_loc=trajectories(i).int_loc;
       trajFiltered(j).int_gauss_2pi=trajectories(i).int_gauss_2pi;
       trajFiltered(j).int_loc_2pi=trajectories(i).int_loc_2pi;
       trajFiltered(j).meanSqrd=trajectories(i).meanSqrd;
       trajFiltered(j).maxInt=trajectories(i).maxInt;
       trajFiltered(j).maxInt_gauss=trajectories(i).maxInt_gauss;
       trajFiltered(j).maxInt_loc=trajectories(i).maxInt_loc;
       trajFiltered(j).maxInt_gauss_2pi=trajectories(i).maxInt_gauss_2pi;
       trajFiltered(j).mean5Int_loc_2pi=trajectories(i).mean5Int_loc_2pi;
       trajFiltered(j).mean5Amp=trajectories(i).mean5Amp;
       trajFiltered(j).meanFullInt=trajectories(i).meanFullInt;
       trajFiltered(j).meanFullInt_gauss=trajectories(i).meanFullInt_gauss;
       trajFiltered(j).meanFullInt_gauss_2pi=trajectories(i).meanFullInt_gauss_2pi;
       trajFiltered(j).meanFullInt_loc_2pi=trajectories(i).meanFullInt_loc_2pi;
       trajFiltered(j).meanFullInt_loc=trajectories(i).meanFullInt_loc;
       trajFiltered(j).mean5MaxInt=trajectories(i).mean5MaxInt;
       trajFiltered(j).mean5MaxInt_gauss=trajectories(i).mean5MaxInt_gauss;
       trajFiltered(j).mean5MaxInt_loc=trajectories(i).mean5MaxInt_loc;
       trajFiltered(j).mean5MaxInt_gauss_2pi=trajectories(i).mean5MaxInt_gauss_2pi;
       trajFiltered(j).mean5MaxInt_loc_2pi=trajectories(i).mean5MaxInt_loc_2pi;
       trajFiltered(j).maxInt_loc_2pi=trajectories(i).maxInt_loc_2pi;
       trajFiltered(j).frames=trajectories(i).frames;
       trajFiltered(j).trajNum=trajectories(i).trajNum;
       trajFiltered(j).frames=trajectories(i).frames;
       trajFiltered(j).range=trajectories(i).range;
       trajFiltered(j).linkNext=trajectories(i).linkNext;
       trajFiltered(j).linkPrevious=trajectories(i).linkPrevious;
       trajFiltered(j).maxAmp=trajectories(i).maxAmp;
       trajFiltered(j).maxPsf=trajectories(i).maxPsf;
       trajFiltered(j).mean5Int=trajectories(i).mean5Int;
       trajFiltered(j).mean5Int_gauss=trajectories(i).mean5Int_gauss;
       trajFiltered(j).mean5Int_loc=trajectories(i).mean5Int_loc;
       trajFiltered(j).mean5Int_gauss_2pi=trajectories(i).mean5Int_gauss_2pi;
       
      
    end
    
end
trajFiltered=trajFiltered';
%[ cummDistrCells_all_exp ,cpd_exp120117_tatA_S_P13_10_ ] = analyzeCells_1([] ,trajFiltered );


