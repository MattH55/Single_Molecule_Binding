function [hist]=ampHistogram(segments,interval,maxSegmentsLength)



segments=segments';
sort(segments);
numTracks=size(segments,1);
if nargin<2 || isempty(interval)
    interval=0.001;
end

if nargin<3 || isempty(maxSegmentsLength)
    maxSegmentsLength=0.1;
end

histLength=round(1/interval)*maxSegmentsLength+1;
hist = zeros(histLength,1);

for i=1:numTracks
    if isnan(segments(i))
        segments(i)=0;
    end    
      
    %histData(i)=segments(i);
    %disp(segments(i));
    hist(1+round(segments(i)/interval))=hist(1+round(segments(i)/interval))+1;
end
disp(hist);
        
   
    

