function [tracksFinalFiltered]=filterStart(tracks,startCoord,startCoordY)





%% Output

tracksFinalFiltered    = [];

%%
tracksFinalFiltered=tracks;
discard=0;
numTracks=size(tracks,1);
%length(tracksFinal);
trackSel=getTrackSel(tracks);

discardedTraj=[];
for i=1:numTracks
    if tracksFinalFiltered(i).tracksCoordAmpCG(1,1)>(startCoord(1)+startCoord(2)) ||tracksFinalFiltered(i).tracksCoordAmpCG(1,1)<(startCoord(1)-startCoord(2))...
       || tracksFinalFiltered(i).tracksCoordAmpCG(1,2)>(startCoordY(1)+startCoordY(2)) ||tracksFinalFiltered(i).tracksCoordAmpCG(1,2)<(startCoordY(1)-startCoordY(2))
        discard=discard+1;
        discardedTraj(discard)=i;
    else
        disp('trajNumber');
        disp(i);
    end
end

tracksFinalFiltered(discardedTraj)=[];
    




        
   
    

