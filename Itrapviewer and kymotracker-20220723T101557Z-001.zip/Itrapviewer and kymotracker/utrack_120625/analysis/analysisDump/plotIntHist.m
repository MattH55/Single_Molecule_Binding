function [ cummD] = plotIntHist( input )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


x=[];
for i=1:length(input)
    
    x=vertcat(x,input(i).meanFullIntDistr(:,1));
end

s=0:100:4000;


hist(x,s)

end
