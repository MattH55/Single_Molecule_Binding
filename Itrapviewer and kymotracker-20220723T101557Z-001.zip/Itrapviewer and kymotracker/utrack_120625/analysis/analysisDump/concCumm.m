function [ cummD] = concCumm( input )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

cummD.allIntDistr=input(1).allIntDistr;
cummD.mean5MaxIntDistr=input(1).mean5MaxIntDistr;
cummD.mean5IntDistr=input(1).mean5IntDistr;
cummD.meanFullIntDistr=input(1).meanFullIntDistr;
x=[];
for i=2:length(input)
    x=vertcat(x,input(i).twoStep(:,1));
    cummD.allIntDistr=vertcat(cummD.allIntDistr,input(i).allIntDistr);
    
    disp('cummD.mean5MaxIntDistr');
    disp(cummD.mean5MaxIntDistr);
    disp('input(i).mean5MaxIntDistr');
    
   disp(input(i).mean5MaxIntDistr);
   disp('i'); 
   disp(i);
    
   cummD.mean5MaxIntDistr=vertcat(cummD.mean5MaxIntDistr,input(i).mean5MaxIntDistr);
   cummD.mean5IntDistr=vertcat(cummD.mean5IntDistr,input(i).mean5IntDistr);
   cummD.meanFullIntDistr=vertcat(cummD.meanFullIntDistr,input(i).meanFullIntDistr);
end
cumm=[];
len=length(x);
for i=1:len
    cumm(i,2)=1-(i/len);
end
cumm(:,1)=sort(x);
cummD.twoStep=cumm;
cummD.allIntDistr=sort(cummD.allIntDistr);
[dummy,IX]=sort(cummD.mean5MaxIntDistr);
cummD.mean5MaxIntDistr=cummD.mean5MaxIntDistr(IX,:);
[dummy,IX]=sort(cummD.mean5IntDistr);
cummD.mean5IntDistr=cummD.mean5IntDistr(IX,:);
[dummy,IX]=sort(cummD.meanFullIntDistr);
cummD.meanFullIntDistr=cummD.meanFullIntDistr(IX,:);

end
