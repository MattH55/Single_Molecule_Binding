function varargout = filterGUI(varargin)
% FILTERGUI M-file for filterGUI.fig
%      FILTERGUI, by itself, creates a new FILTERGUI or raises the existing
%      singleton*.
%
%      H = FILTERGUI returns the handle to a new FILTERGUI or the handle to
%      the existing singleton*.
%
%      FILTERGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FILTERGUI.M with the given input arguments.
%
%      FILTERGUI('Property','Value',...) creates a new FILTERGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before filterGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to filterGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help filterGUI

% Last Modified by GUIDE v2.5 11-May-2011 10:54:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @filterGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @filterGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before filterGUI is made visible.
function filterGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to filterGUI (see VARARGIN)

% Choose default command line output for filterGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes filterGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = filterGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function lengthText_Callback(hObject, eventdata, handles)
% hObject    handle to lengthText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lengthText as text
%        str2double(get(hObject,'String')) returns contents of lengthText as a double
input=str2num(get(hObject,'String'));
if (isempty(input))
    set(hObject,'String','0')
end
%update handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function lengthText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lengthText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function minStartFrameBoxText_Callback(hObject, eventdata, handles)
% hObject    handle to minStartFrameBoxText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of minStartFrameBoxText as text
%        str2double(get(hObject,'String')) returns contents of minStartFrameBoxText as a double
input=str2num(get(hObject,'String'));
if (isempty(input))
    set(hObject,'String','0')
end
%update handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function minStartFrameBoxText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minStartFrameBoxText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function minEndFrameBoxText_Callback(hObject, eventdata, handles)
% hObject    handle to minEndFrameBoxText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of minEndFrameBoxText as text
%        str2double(get(hObject,'String')) returns contents of minEndFrameBoxText as a double
input=str2num(get(hObject,'String'));
if (isempty(input))
    set(hObject,'String','500')
end
%update handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function minEndFrameBoxText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minEndFrameBoxText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function minMsqrdText_Callback(hObject, eventdata, handles)
% hObject    handle to minMsqrdText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of minMsqrdText as text
%        str2double(get(hObject,'String')) returns contents of minMsqrdText as a double
input=str2num(get(hObject,'String'));
if (isempty(input))
    set(hObject,'String','0')
end
%update handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function minMsqrdText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to minMsqrdText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function maxSegmentLengthText_Callback(hObject, eventdata, handles)
% hObject    handle to maxSegmentLengthText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of maxSegmentLengthText as text
%        str2double(get(hObject,'String')) returns contents of maxSegmentLengthText as a double
input=str2num(get(hObject,'String'));
if (isempty(input))
    set(hObject,'String','100')
end
%update handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function maxSegmentLengthText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxSegmentLengthText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function startXText_Callback(hObject, eventdata, handles)
% hObject    handle to startXText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startXText as text
%        str2double(get(hObject,'String')) returns contents of startXText as a double
input=str2num(get(hObject,'String'));
if (isempty(input))
    set(hObject,'String','256')
end
%update handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function startXText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startXText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function startXBoxText_Callback(hObject, eventdata, handles)
% hObject    handle to startXBoxText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startXBoxText as text
%        str2double(get(hObject,'String')) returns contents of startXBoxText as a double
input=str2num(get(hObject,'String'));
if (isempty(input))
    set(hObject,'String','500')
end
%update handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function startXBoxText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startXBoxText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function startYText_Callback(hObject, eventdata, handles)
% hObject    handle to startYText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startYText as text
%        str2double(get(hObject,'String')) returns contents of startYText as a double
input=str2num(get(hObject,'String'));
if (isempty(input))
    set(hObject,'String','256')
end
%update handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function startYText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startYText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function startYBoxText_Callback(hObject, eventdata, handles)
% hObject    handle to startYBoxText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startYBoxText as text
%        str2double(get(hObject,'String')) returns contents of startYBoxText as a double
input=str2num(get(hObject,'String'));
if (isempty(input))
    set(hObject,'String','500')
end
%update handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function startYBoxText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startYBoxText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function originalTrajName_Callback(hObject, eventdata, handles)
% hObject    handle to originalTrajName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of originalTrajName as text
%        str2double(get(hObject,'String')) returns contents of originalTrajName as a double
input=get(hObject,'String');
try
    dummy=evalin('base', input);
    set(handles.numTrajOriginal,'String',num2str(length(dummy)));
    clear dummy
    
catch
    disp(['Variable ' input ' doesnt exist in workspace']);
    set(hObject,'String','tracksFinal')

end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function originalTrajName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to originalTrajName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function filteredTrajName_Callback(hObject, eventdata, handles)
% hObject    handle to filteredTrajName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filteredTrajName as text
%        str2double(get(hObject,'String')) returns contents of filteredTrajName as a double
input=get(hObject,'String');
try
    dummy=evalin('base', input);
    clear dummy
    set(hObject,'String',[input '0']);
    disp(['Variable ' input ' already exists in workspace']);
catch
    
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function filteredTrajName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filteredTrajName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
filteredTrajName=get(handles.filteredTrajName,'String');
try
    
    dummy=evalin('base', filteredTrajName);
    clear dummy
    disp(['Variable ' filteredTrajName ' already exists in workspace']);
    filteredTrajName=[filteredTrajName '0'];
    set(handles.filteredTrajName,'String',filteredTrajName);
    
    
catch
    
end


length = str2num(get(handles.lengthText,'String'));
startFrame=[str2num(get(handles.minStartFrameBoxText,'String')) str2num(get(handles.maxStartFrameBoxText,'String'))];
endFrame=[str2num(get(handles.minEndFrameBoxText,'String')) str2num(get(handles.maxEndFrameBoxText,'String'))];
meanRSqrd=str2num(get(handles.minMsqrdText,'String'));
maxSegmLength=str2num(get(handles.maxSegmentLengthText,'String'));
startCoord=[str2num(get(handles.startXText,'String')) str2num(get(handles.startXBoxText,'String'))];
tracksFinal = evalin('base', get(handles.originalTrajName,'String'));
[tracksFinalFiltered]=filterTrajLengthPsfBgr(tracksFinal,length,startFrame,endFrame,meanRSqrd,maxSegmLength,startCoord);

dim=size(tracksFinal);
dim2=size(tracksFinalFiltered);
set(handles.numTrajOriginal,'String',num2str(dim(1)));
set(handles.numTrajFiltered,'String',num2str(dim2(1)));
parameterList = repmat(struct('length',[],...
    'startFrame',[],'endFrame',[],'meanRSqrd',[],'maxSegmLength',[],'startCoord',[]),1);

parameterList.length=length;
parameterList.startFrame(1)=startFrame(1);
parameterList.startFrame(2)=startFrame(2);
parameterList.endFrame(1)=endFrame(1);
parameterList.endFrame(2)=endFrame(2);
parameterList.meanRSqrd=meanRSqrd;
parameterList.maxSegmLength=maxSegmLength;
parameterList.startCoord=startCoord;

assignin('base',[get(handles.filteredTrajName,'String') '_param'], parameterList);
assignin('base',get(handles.filteredTrajName,'String'), tracksFinalFiltered);



function maxStartFrameBoxText_Callback(hObject, eventdata, handles)
% hObject    handle to maxStartFrameBoxText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of maxStartFrameBoxText as text
%        str2double(get(hObject,'String')) returns contents of maxStartFrameBoxText as a double
input=str2num(get(hObject,'String'));
if (isempty(input))
    set(hObject,'String','500')
end
%update handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function maxStartFrameBoxText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxStartFrameBoxText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function maxEndFrameBoxText_Callback(hObject, eventdata, handles)
% hObject    handle to maxEndFrameBoxText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of maxEndFrameBoxText as text
%        str2double(get(hObject,'String')) returns contents of maxEndFrameBoxText as a double
input=str2num(get(hObject,'String'));
if (isempty(input))
    set(hObject,'String','500')
end
%update handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function maxEndFrameBoxText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxEndFrameBoxText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
