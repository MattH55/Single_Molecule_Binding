function [ ] = plotCummLLs( input,nameGraph,saveGraph )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


f={'ko','ro','bo','go','yo','mo','co','ks','rs','bs','gs','ys','ms','cs','k*','r*','b*','g*','y*','m*','c*'};

m=size(f);
j=0;
figure

for i=1:length(input)
    j=j+1;
    if j==22
        j=1;
    end
    %disp(f);
    semilogy(input(i).twoStep(:,1),input(i).twoStep(:,2),char(f(j)),'MarkerSize',3);
    hold on
    
end
axis([0 0.2 0.01 1])
titHandle=title (nameGraph);
set(titHandle,'fontsize',16);
xlabel('r^2 (\mum^2/s)');
ylabel('1-P (r^2,60ms)');
xlhand = get(gca,'xlabel');
ylhand = get(gca,'ylabel');
set(gca,'XTick',0:0.1:0.2)

set(xlhand,'fontsize',16);
set(ylhand,'fontsize',16);
if saveGraph==1
saveas(gcf,nameGraph);
end
end
