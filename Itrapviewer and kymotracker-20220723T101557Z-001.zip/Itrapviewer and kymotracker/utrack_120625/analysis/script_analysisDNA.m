
%Before running this script fill in 'link' array and specify analysis
%parameter below



%%
analysisPara=repmat(struct('timelapse',[],'pixelSize',[],'diffDim',[],'numTimeLags',[],'msdDispFlag',[]),1);

%specify imaging parameters
%Time lapse in s
analysisPara.timeLapse=0.032;

%Pixel size in um
analysisPara.pixelSize=0.08;

%Diffusion dimension
analysisPara.diffDim=1;

%Number of timelags taken into account for MSD analysis
analysisPara.numTimeLags=6;

%Show msd analysis fit if 1
analysisPara.msdDispFlag=0;



%%


[ traj_linked ] = linkTrajDNA(trajectories_filtered,links );

if isempty(links)
    [ traj_filtered,traj_ranged,trajNum ] = rangeTraj_2_int( traj_linked,links);
else
    [ traj_filtered,traj_ranged,trajNum ] = rangeTraj_2_int( traj_linked,links(:,1));
end


%overlayTrajMovie_auto_110522(traj_ranged,imageNumStartEnd,[],1,'test3.avi',[],[],1,0,[roiRange(1,1) roiRange(1,2); roiRange(2,1) roiRange(2,2)],0,[],[],2,1)
[ analysisOfIndividualTraj , analysisOfCombinedTraj ] = analyzeTrajDNA([]',traj_ranged,analysisPara );

plotCummMSDsDNA(  analysisOfIndividualTraj,analysisPara);
plotCummMSDsDNA(  analysisOfCombinedTraj,analysisPara);

plotCummLLsDNA(analysisOfIndividualTraj,'analysisOfIndividualTraj',0)
plotCummLLsDNA(analysisOfCombinedTraj,'analysisOfCombinedTraj',0)

if ~isempty(links)
overlayTrajMovie_auto_110522(traj_ranged,imageNumStartEnd,[],1,'test3.avi',[],[],1,0,[roiRange(1,1) roiRange(1,2); roiRange(2,1) roiRange(2,2)],0,[],[],2,1)
end