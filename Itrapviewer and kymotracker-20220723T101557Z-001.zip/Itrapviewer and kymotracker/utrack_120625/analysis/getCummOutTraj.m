function [ cummDistr] = getCummOutTraj( trajectories,traj )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

cummDistr = repmat(struct('meanRsqrdSteps',[],'meanXsqrdSteps',[],'meanYsqrdSteps',[],'oneStep',[],'twoStep',[],'threeStep',[],'fourStep',[],'sixStep',[],'eightStep',[],...
    'meanOneStep',[],'meanTwoStep',[],'meanThreeStep',[],'meanFourStep',[],'meanSixStep',[],'meanEightStep',[]),1);


numOfSteps=8;
pixelSize=0.08;
timeLapse=0.032;
dim=2;
    
    
    
    
    
else
    if 
        
sqrdDispl=repmat(struct('RsqrdDispl',[],'XsqrdDispl',[],'YsqrdDispl',[]),numOfSteps);

if nargin<2||isempty(traj)
    numTracks=length(trajectories);
    for i=1:numTracks
        traj(i)=i;
    end
else
    %%%disp('hashshah');
    numTracks=numel(traj);
end

meanSqrdDispl=[];
meanSqrdDispl2=[];
meanSqrdDispl3=[];
meanSqrdDispl4=[];
meanSqrdDispl6=[];
meanSqrdDispl8=[];
meanRsqrdDispl=[];
meanYsqrdDispl=[];
meanXsqrdDispl=[];

for i=1:numTracks
    
    meanSqrdDispl=horzcat(meanSqrdDispl,trajectories(traj(i)).rSqrd(find(trajectories(traj(i)).rSqrd)));
end
test=meanSqrdDispl;

for k=1:numOfSteps
    for i=1:numTracks
        for j=1:numel(trajectories(traj(i)).x)-k
            if  trajectories(traj(i)).x(j)>0 && trajectories(traj(i)).x(j+k)>0
               %disp(trajectories(traj(i)).x(j));
               %disp(trajectories(traj(i)).x(j+2));
               xSqrd=(trajectories(traj(i)).x(j)-trajectories(traj(i)).x(j+k))^2;
               ySqrd=(trajectories(traj(i)).y(j)-trajectories(traj(i)).y(j+k))^2;
               rSqrd=xSqrd+ySqrd;
               
               sqrdDispl(k).RsqrdDispl=vertcat(sqrdDispl(k).RsqrdDispl,rSqrd);
               sqrdDispl(k).XsqrdDispl=vertcat(sqrdDispl(k).XsqrdDispl,xSqrd);
               sqrdDispl(k).YsqrdDispl=vertcat(sqrdDispl(k).YsqrdDispl,ySqrd);
            end
        end
        
    end
    
   cummDistr.meanRsqrdSteps(k,1)=mean(sqrdDispl(k).RsqrdDispl)*pixelSize*pixelSize;
   cummDistr.meanYsqrdSteps(k,1)=mean(sqrdDispl(k).YsqrdDispl)*pixelSize*pixelSize;
   cummDistr.meanXsqrdSteps(k,1)=mean(sqrdDispl(k).XsqrdDispl)*pixelSize*pixelSize; 
end
       
        
        
        
        
        
for i=1:numTracks
    for j=1:numel(trajectories(traj(i)).x)-2
        if  trajectories(traj(i)).x(j)>0 && trajectories(traj(i)).x(j+2)>0
            %disp(trajectories(traj(i)).x(j));
            %disp(trajectories(traj(i)).x(j+2));
            xSqrd=(trajectories(traj(i)).x(j)-trajectories(traj(i)).x(j+2))^2;
            ySqrd=(trajectories(traj(i)).y(j)-trajectories(traj(i)).y(j+2))^2;
            rSqrd=xSqrd+ySqrd;
            meanSqrdDispl2=horzcat(meanSqrdDispl2,rSqrd);
        
        end
    end
end
for i=1:numTracks
    for j=1:numel(trajectories(traj(i)).x)-3
        if trajectories(traj(i)).x(j)>0 && trajectories(traj(i)).x(j+3)>0
            %disp(trajectories(traj(i)).x(j));
            %disp(trajectories(traj(i)).x(j+3));
            xSqrd=(trajectories(traj(i)).x(j)-trajectories(traj(i)).x(j+3))^2;
            ySqrd=(trajectories(traj(i)).y(j)-trajectories(traj(i)).y(j+3))^2;
            rSqrd=xSqrd+ySqrd;
            meanSqrdDispl3=horzcat(meanSqrdDispl3,rSqrd);
        
        end
    end
end
for i=1:numTracks
    for j=1:numel(trajectories(traj(i)).x)-4
        if trajectories(traj(i)).x(j)>0 && trajectories(traj(i)).x(j+4)>0
            %disp(trajectories(traj(i)).x(j));
            %disp(trajectories(traj(i)).x(j+4));
            xSqrd=(trajectories(traj(i)).x(j)-trajectories(traj(i)).x(j+4))^2;
            ySqrd=(trajectories(traj(i)).y(j)-trajectories(traj(i)).y(j+4))^2;
            rSqrd=xSqrd+ySqrd;
            meanSqrdDispl4=horzcat(meanSqrdDispl4,rSqrd);
        
        end
    end
end
for i=1:numTracks
    for j=1:numel(trajectories(traj(i)).x)-6
        if trajectories(traj(i)).x(j)>0 && trajectories(traj(i)).x(j+6)>0
            %disp(trajectories(traj(i)).x(j));
            %disp(trajectories(traj(i)).x(j+6));
            xSqrd=(trajectories(traj(i)).x(j)-trajectories(traj(i)).x(j+6))^2;
            ySqrd=(trajectories(traj(i)).y(j)-trajectories(traj(i)).y(j+6))^2;
            rSqrd=xSqrd+ySqrd;
            meanSqrdDispl6=horzcat(meanSqrdDispl6,rSqrd);
        
        end
    end
end
for i=1:numTracks
    for j=1:numel(trajectories(traj(i)).x)-8
        if trajectories(traj(i)).x(j)>0 && trajectories(traj(i)).x(j+8)>0
            %disp(trajectories(traj(i)).x(j));
            %disp(trajectories(traj(i)).x(j+8));
            xSqrd=(trajectories(traj(i)).x(j)-trajectories(traj(i)).x(j+8))^2;
            ySqrd=(trajectories(traj(i)).y(j)-trajectories(traj(i)).y(j+8))^2;
            rSqrd=xSqrd+ySqrd;
            meanSqrdDispl8=horzcat(meanSqrdDispl8,rSqrd);
        
        end
    end
end
cummDistr.meanOneStep=mean(meanSqrdDispl)*pixelSize*pixelSize;
cummDistr.meanDiffOneStep=cummDistr.meanOneStep/(2*dim*timeLapse);
meanSqrdDispl=sort(meanSqrdDispl);
numDispl=numel(meanSqrdDispl);
for i=1:numDispl
    cummDistr.oneStep(i,2)=1-(i/numDispl);
    cummDistr.oneStep(i,1)=meanSqrdDispl(i)*pixelSize*pixelSize;
end


%cummDistr.meanTwoStep=mean(meanSqrdDispl2)*pixelSize*pixelSize;
%cummDistr.meanDiffTwoStep=cummDistr.meanTwoStep/(2*dim*2*timeLapse);
%meanSqrdDispl2=sort(meanSqrdDispl2);
%numDispl2=numel(meanSqrdDispl2);

sqrdDispl(2).RsqrdDispl=sort(sqrdDispl(2).RsqrdDispl);
numDispl2=numel(sqrdDispl(2).RsqrdDispl);
for i=1:numDispl2
    cummDistr.twoStep(i,2)=1-(i/numDispl2);
    cummDistr.twoStep(i,1)=sqrdDispl(2).RsqrdDispl(i)*pixelSize*pixelSize;
    %disp('fdfdf');
end

cummDistr.meanThreeStep=mean(meanSqrdDispl3)*pixelSize*pixelSize;
cummDistr.meanDiffThreeStep=cummDistr.meanThreeStep/(2*dim*3*timeLapse);
meanSqrdDispl3=sort(meanSqrdDispl3);
numDispl3=numel(meanSqrdDispl3);
for i=1:numDispl3
    cummDistr.threeStep(i,2)=1-(i/numDispl3);
    cummDistr.threeStep(i,1)=meanSqrdDispl3(i)*pixelSize*pixelSize;
end

cummDistr.meanFourStep=mean(meanSqrdDispl4)*pixelSize*pixelSize;
cummDistr.meanDiffFourStep=cummDistr.meanFourStep/(2*dim*4*timeLapse);
meanSqrdDispl4=sort(meanSqrdDispl4);
numDispl4=numel(meanSqrdDispl4);
for i=1:numDispl4
    cummDistr.fourStep(i,2)=1-(i/numDispl4);
    cummDistr.fourStep(i,1)=meanSqrdDispl4(i)*pixelSize*pixelSize;
end

cummDistr.meanSixStep=mean(meanSqrdDispl6)*pixelSize*pixelSize;
cummDistr.meanDiffSixStep=cummDistr.meanSixStep/(2*dim*6*timeLapse);
meanSqrdDispl6=sort(meanSqrdDispl6);
numDispl6=numel(meanSqrdDispl6);
for i=1:numDispl6
    cummDistr.sixStep(i,2)=1-(i/numDispl6);
    cummDistr.sixStep(i,1)=meanSqrdDispl6(i)*pixelSize*pixelSize;
end
cummDistr.meanEightStep=mean(meanSqrdDispl8)*pixelSize*pixelSize;
cummDistr.meanDiffEightStep=cummDistr.meanEightStep/(2*dim*8*timeLapse);
meanSqrdDispl8=sort(meanSqrdDispl8);
numDispl8=numel(meanSqrdDispl8);
for i=1:numDispl8
    %%disp('jjsjjs');
    cummDistr.eightStep(i,2)=1-(i/numDispl8);
    cummDistr.eightStep(i,1)=meanSqrdDispl8(i)*pixelSize*pixelSize;
end

end

