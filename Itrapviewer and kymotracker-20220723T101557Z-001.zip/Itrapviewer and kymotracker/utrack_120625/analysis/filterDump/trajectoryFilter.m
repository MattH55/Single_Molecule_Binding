function [trajIndex]=trajectoryFilter(tracksFinal,length,startFrame,endFrame,meanRSqrd,maxSegmLength,startCoordX,startCoordY)
%OVERLAYTRACKSMOVIENEW Overlays tracks obtained via trackCloseGapsKalman on movies with variable color-coding
%
%SYNPOSIS overlayTracksMovieNew(tracksFinal,startend,dragtailLength,...
%    saveMovie,movieName,filterSigma,classifyGaps,highlightES,showRaw,...
%    imageRange,onlyTracks,classifyLft,diffAnalysisRes,intensityScale,...
%    colorTracks)
%
%INPUT  tracksFinal   : Output of trackCloseGapsKalman.

%OUTPUT If movie is to be saved, the QT movie is written into directory


%REMARKS Color-coding:





%% Output

trajIndex=[];

%%


j=0;

for i=1:numTracks
    if trackSel(i,3)<length || trackSel(i,1)>startFrame(2) || trackSel(i,1)<startFrame(1)...
            || trackSel(i,2)>endFrame(2) || trackSel(i,2)<endFrame(1)...
            ||tracksFinalFiltered(i).tracksCoordAmpCG(1,1)>startCoord(2) ||tracksFinalFiltered(i).tracksCoordAmpCG(1,1)<startCoord(1)
    else
       j=j+1;
       trajIndex(j)=i; 
    end    
end



