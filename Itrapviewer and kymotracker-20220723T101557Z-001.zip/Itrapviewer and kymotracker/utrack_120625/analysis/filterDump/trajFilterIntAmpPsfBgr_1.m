function [intens,amp,psf,bgr]=trajFilterIntAmpPsfBgr(tracks,traj,full,extension)






%% Output

tracksFinalFiltered    = [];
amp=[];
bgr=[];
psf=[];
intens=[];

%%


numTracks=size(tracks,1);


trajCoord = repmat(struct('xMax','yMax','xMin','yMin'),numTracks,1);


if nargin<2 || isempty(traj)
    numTracks=size(tracks,1);
    tracksFilter=tracks;
else
    disp('hhahahhahaha');
    numTracks=numel(traj);
    tracksFilter = repmat(struct('tracksFeatIndxCG',[],...
            'tracksCoordAmpCG',[],'seqOfEvents',[]),numTracks,1);
  
    for i=1:numTracks
        tracksFilter(i)=tracks(traj(i));
    end
end
trackSel=getTrackSel(tracksFilter);

disp(numTracks);
disp('numtracks');
if nargin<3 || isempty(full)
    full=0;
end
ampTraj=zeros(numTracks,100);
l=0
for k=1:numTracks
    
    trajCoord(k).xMin=512;
    trajCoord(k).yMin=512;
    trajCoord(k).xMax=0;
    trajCoord(k).yMax=0;
    for j=1:trackSel(k,3)-1
        l=l+1;
        if isnan(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1))
            amp(l)=0;
            psf(l)=0;
            bgr(l)=0;
            intens(l)=0;
        else
            %disp('   ');
            
            xCoord=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1);
            yCoord=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+2);
            ampTraj(k,j)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+4);
            amp(l)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+4);
            psf(l)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+9);
            bgr(l)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+11);
            intens(l)=amp(l)*psf(l);
            
            %disp('x');
            %disp(xCoord);
            %disp('y');
            %disp(yCoord);
            if xCoord<trajCoord(k).xMin
                trajCoord(k).xMin=xCoord;
                %disp('xMin');
                %disp(trajCoord(k).xMin);
                
                
            end
            if yCoord<trajCoord(k).yMin
                trajCoord(k).yMin=yCoord;
                 
                %disp('yMin');
                %disp(trajCoord(k).yMin);
            end
            if xCoord>trajCoord(k).xMax
                trajCoord(k).xMax=xCoord;
                 
                %disp('xMax');
                %disp(trajCoord(k).xMax);
            end
            if yCoord>trajCoord(k).yMax
                trajCoord(k).yMax=yCoord;
                 
                %disp('yMax');
                %disp(trajCoord(k).yMax);
            end
        end
    end
end

%ask user for images
%%%[fName,dirName] = uigetfile('*.tif','specify first image in the stack - specify very first image, even if not to be plotted');
if nargin<4 || isempty(extension)
    extension=30;
end
for i=1:numTracks
    
   if nargin<2 || isempty(traj)
        k=i;
   else
        k=traj(i);
   end
   %disp('minMaxPre');
   %disp(trajCoord(k).xMin);
   %disp(trajCoord(k).xMax);
   %disp(trajCoord(k).yMin);
   %disp(trajCoord(k).yMax);
   trajCoord(k).xMin=trajCoord(k).xMin-extension;
   trajCoord(k).yMin=trajCoord(k).yMin-extension;
   trajCoord(k).xMax=trajCoord(k).xMax+extension;
   trajCoord(k).yMax=trajCoord(k).yMax+extension;
   %disp('minMaxPre+extension');
   %disp(trajCoord(k).xMin);
   %disp(trajCoord(k).xMax);
   %disp(trajCoord(k).yMin);
   %disp(trajCoord(k).yMax);
   if trajCoord(k).xMin<1
       trajCoord(k).xMin=1;
   end
   if trajCoord(k).yMin<1
       trajCoord(k).yMin=1;
   end
   if trajCoord(k).xMax>512
       trajCoord(k).xMax=512;
   end
   if trajCoord(k).yMax>512
       trajCoord(k).yMax=512;
   end
   %disp('minMaxPost');
   %disp(trajCoord(k).xMin);
    %disp(trajCoord(k).xMax);
    %disp(trajCoord(k).yMin);
    %disp(trajCoord(k).yMax);
   imageRange=[trajCoord(k).yMin, trajCoord(k).yMax; trajCoord(k).xMin, trajCoord(k).xMax ];
   %disp(imageRange);
   %disp(traj);
   %disp(k);
   %disp(traj(k));
   if full==1
       imageRange=[];
   end
   %%%if nargin<2 || isempty(traj)
   %%%     overlayTracksMovieNewMod(tracksFilter,imageRange,k,fName,dirName);
   %%%else
   %%%    overlayTracksMovieNewMod(tracksFilter,imageRange,k,fName,dirName);
       %overlayTracksMovieNewMod(tracksFilter,imageRange,traj(k),fName,dirName);
   %%%end
end







        
   
    

