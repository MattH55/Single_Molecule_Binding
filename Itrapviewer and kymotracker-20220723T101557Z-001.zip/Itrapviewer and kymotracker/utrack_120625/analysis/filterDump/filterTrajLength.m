function [tracksFinalFiltered,segmentsSqrd,cummDistr]=filterTrajLength(tracksFinal,length,startFrame,endFrame,meanRSqrd,maxSegmLength,startCoord)
%OVERLAYTRACKSMOVIENEW Overlays tracks obtained via trackCloseGapsKalman on movies with variable color-coding
%
%SYNPOSIS overlayTracksMovieNew(tracksFinal,startend,dragtailLength,...
%    saveMovie,movieName,filterSigma,classifyGaps,highlightES,showRaw,...
%    imageRange,onlyTracks,classifyLft,diffAnalysisRes,intensityScale,...
%    colorTracks)
%
%INPUT  tracksFinal   : Output of trackCloseGapsKalman.

%OUTPUT If movie is to be saved, the QT movie is written into directory


%REMARKS Color-coding:





%% Output

tracksFinalFiltered    = [];

%%
tracksFinalFiltered=tracksFinal;
discard=0;
numTracks=size(tracksFinal,1);
%length(tracksFinal);
trackSel=getTrackSel(tracksFinal);

discardedTraj=[];
for i=1:numTracks
    if trackSel(i,3)<length || trackSel(i,1)>(startFrame(1)+startFrame(2)) || trackSel(i,1)<(startFrame(1)-startFrame(2))...
            || trackSel(i,2)>(endFrame(1)+endFrame(2)) || trackSel(i,1)<(startFrame(1)-endFrame(2))...
            ||tracksFinalFiltered(i).tracksCoordAmpCG(1,1)>(startCoord(1)+startCoord(2)) ||tracksFinalFiltered(i).tracksCoordAmpCG(1,1)<(startCoord(1)-startCoord(2))
        discard=discard+1;
        discardedTraj(discard)=i;
        
        %disp(startCoord(1)+startCoord(2));
        %disp(startCoord(1)-startCoord(2));
        %disp(tracksFinalFiltered(i).tracksCoordAmpCG(1,1))
        %disp('hhh');
        %disp(trackSel(i,3));
        %disp(trackSel(i,1));
    end
end
tracksFinalFiltered(discardedTraj)=[];
numTracks=size(tracksFinalFiltered,1);
trackSel=getTrackSel(tracksFinalFiltered);

segmentsSqrd = repmat(struct('xSqrd',[],...
    'ySqrd',[],'rSqrd',[],'meanRSqrd',[]),numTracks,1);
segmentFlag=[];
for i=1:numTracks
    index=0;
    segmentFlag(i)=0;
    for j=1:trackSel(i,3)-1
        if isnan(tracksFinalFiltered(i).tracksCoordAmpCG(1,j*8+1))...
                || isnan(tracksFinalFiltered(i).tracksCoordAmpCG(1,(j-1)*8+1))
        else
            
            index=index+1;
            xSqrd=(tracksFinalFiltered(i).tracksCoordAmpCG(1,j*8+1)...
                -tracksFinalFiltered(i).tracksCoordAmpCG(1,(j-1)*8+1))^2;
            
            ySqrd=(tracksFinalFiltered(i).tracksCoordAmpCG(1,j*8+2)...
                -tracksFinalFiltered(i).tracksCoordAmpCG(1,(j-1)*8+2))^2;
            rSqrd=xSqrd+ySqrd;
            
            xxx=rSqrd;
            
                       
            segmentsSqrd(i).xSqrd(index)=xSqrd;
            segmentsSqrd(i).ySqrd(index)=ySqrd;
            segmentsSqrd(i).rSqrd(index)=rSqrd;
            
            if rSqrd>maxSegmLength^2
                segmentFlag(i)=1;
                disp('  ');
                disp(['trackIndex','  ',num2str(i)]);
                disp(['postIndex','  ',num2str(j*8+1)]);
                j*8+1
                disp(['postx','  ',num2str(tracksFinalFiltered(i).tracksCoordAmpCG(1,j*8+1))]);              
                disp(['prex','  ',num2str(tracksFinalFiltered(i).tracksCoordAmpCG(1,(j-1)*8+1))]);
                disp(['prey','  ',num2str(tracksFinalFiltered(i).tracksCoordAmpCG(1,(j-1)*8+2))]);                
                disp(['posty','  ',num2str(tracksFinalFiltered(i).tracksCoordAmpCG(1,j*8+2))]);
                disp(['linkDist','  ',num2str(sqrt(rSqrd))]);  
                disp('   ');
            end
        end
    end
end

for i=1:numTracks
    meanSqrd=0;
    for j=1:size(segmentsSqrd(i).xSqrd,2)
        meanSqrd=meanSqrd+segmentsSqrd(i).rSqrd(j);
    end
    segmentsSqrd(i).meanRSqrd=meanSqrd/size(segmentsSqrd(i).xSqrd,2);
end

discard=0;
discardedTraj=[];
count=0;

for i=1:numTracks
    if segmentsSqrd(i).meanRSqrd<meanRSqrd || segmentFlag(i)==1
        if segmentFlag(i)==1
            count=count+1;
        end
        discard=discard+1;
        discardedTraj(discard)=i;
    end
end

tracksFinalFiltered(discardedTraj)=[];
segmentsSqrd(discardedTraj)=[];

allMeanRDispl=horzcat(segmentsSqrd.rSqrd);
allMeanRDispl=sort(allMeanRDispl);
cummDistr=[];
for i=1:size(allMeanRDispl,2)
    cummDistr(i,2)=1-(i/size(allMeanRDispl,2));
    cummDistr(i,1)=allMeanRDispl(i);
end

disp(['counts',num2str(count)]);
    




        
   
    

