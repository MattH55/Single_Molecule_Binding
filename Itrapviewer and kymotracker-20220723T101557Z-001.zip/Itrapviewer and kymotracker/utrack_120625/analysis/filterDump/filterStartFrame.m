function [tracksFinalFiltered]=filterStartFrame(tracks,startFrame,endFrame,len)





%% Output

tracksFinalFiltered    = [];

%%
tracksFinalFiltered=tracks;
discard=0;
numTracks=size(tracks,1);
%length(tracksFinal);
trackSel=getTrackSELPsfBgr(tracks);

discardedTraj=[];
for i=1:numTracks
    if tracksFinalFiltered(i).seqOfEvents(1,1)>=startFrame && tracksFinalFiltered(i).seqOfEvents(1,1)>=endFrame 
       
       
        discard=discard+1;
        discardedTraj(discard)=i;
    else
        if trackSel(i,3)<len
            
            discard=discard+1;
        discardedTraj(discard)=i;
        
        else
        disp('trajNumber');
        disp(i);
        end
    end
end

tracksFinalFiltered(discardedTraj)=[];
    




        
   
    

