


[ traj_linked ] = linkTrajDNA(trajectories_filtered_all,links );

[ trajectories_org,trajectories,trajNum ] = rangeTraj_1_int( traj_linked,links(:,1));

[ cummDistrCells_all ,cummDistrAnal ] = analyzeTrajDNA(links(:,1),trajectories_filtered_all );