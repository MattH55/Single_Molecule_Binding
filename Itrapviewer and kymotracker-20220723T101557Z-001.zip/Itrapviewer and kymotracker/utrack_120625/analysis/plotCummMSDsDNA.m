function [ ] = plotCummMSDsDNA(  analysisData,analysisPara)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

if nargin<2 || ~isfield(analysisPara, 'numTimeLags') || isempty(analysisPara.numTimeLags) 

    numOfSteps=8;
    disp('errorNumOfSteps');
else
    numOfSteps=int8(analysisPara.numTimeLags);
end

if nargin<2 || ~isfield(analysisPara, 'pixelSize') || isempty(analysisPara.pixelSize) 
    disp('pixelSize');
    pixelSize=0.08;
else
    pixelSize=analysisPara.pixelSize;
end

if nargin<2 || ~isfield(analysisPara, 'timeLapse') || isempty(analysisPara.timeLapse) 
       disp('errorTimelapse');
    timeLapse=0.032;
else
    timeLapse=analysisPara.timeLapse;
end

if nargin<2 || ~isfield(analysisPara, 'diffDim') || isempty(analysisPara.diffDim) 
    disp('erroDiffDimr');
    %disp(~isfield(analysisPara, 'diffDim'));
    dim=2;
else
    dim=analysisPara.diffDim;
end

if nargin<2 || ~isfield(analysisPara, 'msdDispFlag') || isempty(analysisPara.msdDispFlag) 
    disp('msdDispFlag');
   msdDispFlag=0;
else
    msdDispFlag=analysisPara.msdDispFlag;
end




for i=1:length(analysisData)
    
traj=analysisData(i).traj;
    
yR=analysisData(i).meanRsqrdSteps(~isnan(analysisData(i).meanRsqrdSteps));
yX=analysisData(i).meanXsqrdSteps(~isnan(analysisData(i).meanXsqrdSteps));
yY=analysisData(i).meanYsqrdSteps(~isnan(analysisData(i).meanYsqrdSteps));

num=length(yR);
%numX=length(yX);
%numY=length(yY);

x=timeLapse:timeLapse:num*timeLapse;
%xX=timeLapse:timeLapse:numX*timeLapse;
%xY=timeLapse:timeLapse:numY*timeLapse;

x=x';
xp=0:0.01:num*timeLapse;
%disp('x');
%disp(x);
%disp('y');
%disp(yR);

%[pcoeffR,sR]=polyfit(x,yR,1);
%[pcoeffX,sX]=polyfit(x,yX,1);
%[pcoeffY,sY]=polyfit(x,yY,1);


[brobR,statsR] = robustfit(x,yR,'ols');
[brobX,statsX] = robustfit(x,yX,'ols');
[brobY,statsY] = robustfit(x,yY,'ols');


pcoeffR=fliplr(brobR');
pcoeffX=fliplr(brobX');
pcoeffY=fliplr(brobY');

[ypR]=polyval(pcoeffR,xp);
[ypY]=polyval(pcoeffY,xp);
[ypX]=polyval(pcoeffX,xp);

analysisData(i).RdiffConst=pcoeffR(1)/(2*dim);
analysisData(i).XdiffConst=pcoeffX(1)/(2*dim);
analysisData(i).YdiffConst=pcoeffY(1)/(2*dim);

analysisData(i).sigmaR=pcoeffR(2);
analysisData(i).sigmaX=pcoeffX(2);
analysisData(i).sigmaY=pcoeffY(2);

analysisData(i).deltaRdiffConst=statsR.se(2);
analysisData(i).deltaXdiffConst=statsX.se(2);
analysisData(i).deltaYdiffConst=statsY.se(2);

analysisData(i).deltaSigmaR=statsR.se(1);
analysisData(i).deltaSigmaX=statsX.se(1);
analysisData(i).deltaSigmaY=statsY.se(1);




%if msdDispFlag==1
    

    

    figure, plot(x,yR,'*',xp,ypR,'b',x,yX,'O',xp,ypX,'g',x,yY,'d',xp,ypY,'r')
     titHandle=title (['MSD curve combined of trajectories ' num2str(min(traj)) ' - ' num2str(max(traj))]);
    set(titHandle,'fontsize',16);
    xlabel('timeLapse (s)');
    ylabel(' MSD (um)');
    xlhand = get(gca,'xlabel');
    ylhand = get(gca,'ylabel');
    set(xlhand,'fontsize',16);
    set(ylhand,'fontsize',16);
%end

end
%figure, plot(x,yX,'O',xp,ypX,'m')
%titHandle=title ('MSD curve X');
%set(titHandle,'fontsize',16);
%xlabel('timeLapse (s)');
%ylabel(' r^2(um)');
%xlhand = get(gca,'xlabel');
%ylhand = get(gca,'ylabel');
%set(gca,'XTick',0:0.1:0.2)
%set(xlhand,'fontsize',16);
%set(ylhand,'fontsize',16);

%figure, plot(x,yR,'O',xp,ypR,'m')
%axis([0 0.2 0.01 1])
%titHandle=title ('MSD curve R');
%set(titHandle,'fontsize',16);
%xlabel('timeLapse (s)');
%ylabel(' r^2(um)');
%xlhand = get(gca,'xlabel');
%ylhand = get(gca,'ylabel');
%%set(gca,'XTick',0:0.1:0.2)
%set(xlhand,'fontsize',16);
%set(ylhand,'fontsize',16);






 

