function [trajectories]=getTrajIntAmpPsfBgr_2(tracks,traj)






%% Output

tracksFinalFiltered    = [];
amp=[];
bgr=[];
psf=[];
intens=[];
xC=[];
yC=[];

%%


numTracks=size(tracks,1);


trajCoord = repmat(struct('xMax','yMax','xMin','yMin'),numTracks,1);

trajectories = repmat(struct('x',[],'y',[],'rSqrd',[],'rSqrdUm',[],'amp',[],'bgr',[],'psf',[],'intens',[],'meanSqrd',[],...
    'maxInt',[],'maxAmp',[],'maxPsf',[],'mean5Int',[],'mean5Amp',[],'meanFullInt',[],'mean5MaxInt',[],'frames',[],'trajNum',[],...
    'range',[],'link',[]),numTracks,1);

segmentsSqrd = repmat(struct('xSqrd',[],...
    'ySqrd',[],'rSqrd',[],'meanRSqrd',[]),numTracks,1);

if nargin<2 || isempty(traj)
    numTracks=size(tracks,1);
    tracksFilter=tracks;
    traj=1:1:numTracks;
else
    disp('hhahahhahaha');
    numTracks=numel(traj);
    tracksFilter = repmat(struct('tracksFeatIndxCG',[],...
            'tracksCoordAmpCG',[],'seqOfEvents',[]),numTracks,1);
  
    for i=1:numTracks
        tracksFilter(i)=tracks(traj(i));
    end
end
trackSel=getTrackSELPsfBgr(tracks);



ampTraj=zeros(numTracks,100);
l=0;

for k=1:numTracks
    ll=0;
    trajectories(k).trajNum=traj(k);
    trajCoord(k).xMin=512;
    trajCoord(k).yMin=512;
    trajCoord(k).xMax=0;
    trajCoord(k).yMax=0;
    index=0;
    for j=1:trackSel(k,3)-1
               
        if isnan(tracksFilter(k).tracksCoordAmpCG(1,j*12+1)) || isnan(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1))
            
        else
            
            index=index+1;
            xSqrd=(tracksFilter(k).tracksCoordAmpCG(1,j*12+1)...
                -tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1))^2;
            
            ySqrd=(tracksFilter(k).tracksCoordAmpCG(1,j*12+2)...
                -tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+2))^2;
            rSqrd=xSqrd+ySqrd;
            
            xxx=rSqrd;
                      
            segmentsSqrd(k).xSqrd(index)=xSqrd;
            segmentsSqrd(k).ySqrd(index)=ySqrd;
            segmentsSqrd(k).rSqrd(index)=rSqrd;
            trajectories(k).rSqrd(index)=rSqrd;
            trajectories(k).rSqrdUm(index)=rSqrd*0.08*0.08;
        end
    end
    for j=1:trackSel(k,3)
        
        ll=ll+1; 
        trajectories(k).frames(ll)=trackSel(k,1)-1+ll;
        if isnan(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1))
            
            trajectories(k).x(ll)=0;
            trajectories(k).y(ll)=0;
            trajectories(k).amp(ll)=0;
            trajectories(k).intens(ll)=0;
            trajectories(k).bgr(ll)=0;
            trajectories(k).psf(ll)=0;
            
            
            
        else
            l=l+1;
            
            %disp('   ');
            xC(ll)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1);
            yC(ll)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+2);
            xCoord=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1);
            yCoord=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+2);
            ampTraj(k,j)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+4);
            
            
            
            trajectories(k).x(ll)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1);
            trajectories(k).y(ll)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+2);
            trajectories(k).amp(ll)=round(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+4)*65536);
            trajectories(k).bgr(ll)=round(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+11)*65536);
            trajectories(k).psf(ll)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+9);
            trajectories(k).intens(ll)=round(trajectories(k).amp(ll)*trajectories(k).psf(ll));
            
            %disp('x');
            %disp(xCoord);
            %disp('y');
            %disp(yCoord);
            if xCoord<trajCoord(k).xMin
                trajCoord(k).xMin=xCoord;
                %disp('xMin');
                %disp(trajCoord(k).xMin);
                
                
            end
            if yCoord<trajCoord(k).yMin
                trajCoord(k).yMin=yCoord;
                 
                %disp('yMin');
                %disp(trajCoord(k).yMin);
            end
            if xCoord>trajCoord(k).xMax
                trajCoord(k).xMax=xCoord;
                 
                %disp('xMax');
                %disp(trajCoord(k).xMax);
            end
            if yCoord>trajCoord(k).yMax
                trajCoord(k).yMax=yCoord;
                 
                %disp('yMax');
                %disp(trajCoord(k).yMax);
            end
        end
    end
end


for i=1:numTracks
    meanSqrd=0;
    for j=1:size(segmentsSqrd(i).xSqrd,2)
        meanSqrd=meanSqrd+segmentsSqrd(i).rSqrd(j);
    end
    segmentsSqrd(i).meanRSqrd=meanSqrd/size(segmentsSqrd(i).xSqrd,2);
    trajectories(i).meanSqrd=segmentsSqrd(i).meanRSqrd;
    trajectories(i).diffConstUm=(segmentsSqrd(i).meanRSqrd*0.08*0.08/(4*0.032));
    trajectories(i).diffConstNm=(segmentsSqrd(i).meanRSqrd*80*80/(4*32));
end

for i=1:numTracks
    trajectories(i).maxInt=max(trajectories(i).intens(:));
    trajectories(i).maxAmp=max(trajectories(i).amp(:));
    trajectories(i).maxPsf=max(trajectories(i).psf(:));
    trajectories(i).mean5Int=0;
    trajectories(i).mean5Amp=0;
    trajectories(i).meanFullInt=0;
    %lenTraj=length(trajectories(i).intens);
    ll=0;
    nonZeroEntries=trajectories(i).intens>0;
    nonZeroInt=trajectories(i).intens(nonZeroEntries);
    nonZeroAmp=trajectories(i).amp(nonZeroEntries);
    nonZeroPsf=trajectories(i).psf(nonZeroEntries);
    lenTraj=length(nonZeroInt);
    %for k=1:lenTraj
    %    if trajectories(i).intens(k)>0
    %        ll=ll+1;
    %        trajectories(i).meanFullInt=trajectories(i).meanFullInt+mean(trajectories(i).intens(k));
    %    end
    %end
    %trajectories(i).meanFullInt=trajectories(i).meanFullInt/ll;
    trajectories(i).meanFullInt=mean(nonZeroInt);
    trajectories(i).meanFullAmp=mean(nonZeroAmp);
    if lenTraj>4
        %ll=0;
        %for k=1:5
        %    if trajectories(i).intens(k)>0
        %    ll=ll+1;
        %    trajectories(i).mean5Int=trajectories(i).mean5Int+mean(trajectories(i).intens(k));
        %    trajectories(i).mean5Amp=trajectories(i).mean5Amp+mean(trajectories(i).amp(k));
        %    end
        %end
        %trajectories(i).mean5Int=trajectories(i).mean5Int/ll;
        %trajectories(i).mean5Amp=trajectories(i).mean5Amp/ll;
        trajectories(i).mean5Int=mean(nonZeroInt(1:5));
        trajectories(i).mean5Amp=mean(nonZeroAmp(1:5));
        nonZeroIntSort=sort(nonZeroInt,'descend');
        trajectories(i).mean5MaxInt=mean(nonZeroIntSort(1:5));
    else
        %ll=0;
       
        %for k=1:lenTraj
             
         %  if trajectories(i).intens(k)>0
         %   ll=ll+1;
        %    trajectories(i).mean5Int=trajectories(i).mean5Int+mean(trajectories(i).intens(k));
         %   trajectories(i).mean5Amp=trajectories(i).mean5Amp+mean(trajectories(i).amp(k));
        %    end
        %end
        trajectories(i).mean5Int=trajectories(i).meanFullInt;
        trajectories(i).mean5Amp=trajectories(i).meanFullAmp;
        trajectories(i).mean5MaxInt=trajectories(i).meanFullInt;
    end
end

%ask user for images
%%%[fName,dirName] = uigetfile('*.tif','specify first image in the stack - specify very first image, even if not to be plotted');
if nargin<4 || isempty(extension)
    extension=30;
end
for i=1:numTracks
    
   if nargin<2 || isempty(traj)
        k=i;
   else
        k=traj(i);
   end
   %disp('minMaxPre');
   %disp(trajCoord(k).xMin);
   %disp(trajCoord(k).xMax);
   %disp(trajCoord(k).yMin);
   %disp(trajCoord(k).yMax);
   trajCoord(k).xMin=trajCoord(k).xMin-extension;
   trajCoord(k).yMin=trajCoord(k).yMin-extension;
   trajCoord(k).xMax=trajCoord(k).xMax+extension;
   trajCoord(k).yMax=trajCoord(k).yMax+extension;
   %disp('minMaxPre+extension');
   %disp(trajCoord(k).xMin);
   %disp(trajCoord(k).xMax);
   %disp(trajCoord(k).yMin);
   %disp(trajCoord(k).yMax);
   if trajCoord(k).xMin<1
       trajCoord(k).xMin=1;
   end
   if trajCoord(k).yMin<1
       trajCoord(k).yMin=1;
   end
   if trajCoord(k).xMax>512
       trajCoord(k).xMax=512;
   end
   if trajCoord(k).yMax>512
       trajCoord(k).yMax=512;
   end
   %disp('minMaxPost');
   %disp(trajCoord(k).xMin);
    %disp(trajCoord(k).xMax);
    %disp(trajCoord(k).yMin);
    %disp(trajCoord(k).yMax);
  
   %disp(imageRange);
   %disp(traj);
   %disp(k);
   %disp(traj(k));
   
   %sumY=0
   %for i=1:length(yC)
   %    if yC>0
   %        sumY=sumY+yC(i);
   %        sumX=sumX+xC(i);
   %    end
   %end
   
   %disp('stdXY');
   %disp(xStd);
   %disp(yStd);
   
       
           
   %%%if nargin<2 || isempty(traj)
   %%%     overlayTracksMovieNewMod(tracksFilter,imageRange,k,fName,dirName);
   %%%else
   %%%    overlayTracksMovieNewMod(tracksFilter,imageRange,k,fName,dirName);
       %overlayTracksMovieNewMod(tracksFilter,imageRange,traj(k),fName,dirName);
   %%%end
end
