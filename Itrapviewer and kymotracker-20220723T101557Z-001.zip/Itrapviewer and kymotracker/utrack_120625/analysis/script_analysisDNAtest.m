
%Before running this script fill in 'link' array and specify analysis
%parameter below



%%
analysisPara=repmat(struct('timelapse',[],'pixelSize',[],'diffDim',[],'numTimeLags',[],'msdDispFlag',[]),1);

%specify imaging parameters
%Time lapse in s
analysisPara.timeLapse=0.032;

%Pixel size in um
analysisPara.pixelSize=0.08;

%Diffusion dimension
analysisPara.diffDim=2;

%Number of timelags taken into account for MSD analysis
analysisPara.numTimeLags=8;

%Show msd analysis fit if 1
analysisPara.msdDispFlag=1;



%%


%[ traj_linked ] = linkTrajDNA(trajectories_filtered,links );


%[ traj_filtered,traj_ranged,trajNum ] = rangeTraj_2_int( traj_linked,links(:,1));

%overlayTrajMovie_auto_110522(traj_ranged,imageNumStartEnd,[],1,'test3.avi',[],[],1,0,[roiRange(1,1) roiRange(1,2); roiRange(2,1) roiRange(2,2)],0,[],[],2,1)

[ analysisOfIndividualTraj , analysisOfCombinedTraj ] = analyzeTrajDNA([]',trajectories_filtered,analysisPara );