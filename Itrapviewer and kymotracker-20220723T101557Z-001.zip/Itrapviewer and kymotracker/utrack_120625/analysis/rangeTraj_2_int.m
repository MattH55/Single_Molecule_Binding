function [ trajectories_org,trajectories,trajNum ] = rangeTraj_1_int( trajectories_org,traj )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

if nargin<2 || isempty(traj)
    traj=1:length(trajectories_org);
else
    traj=traj(find(traj));
end

for i=1:length(traj)
    %%if ~isempty(trajectories_org(traj).range)
    %disp(traj(i));
    rangeDim=size(trajectories_org(traj(i)).range);
    startFrame=trajectories_org(traj(i)).frames(1);
    while trajectories_org(traj(i)).x(end)==0
        trajectories_org(traj(i)).x=trajectories_org(traj(i)).x(1:length(trajectories_org(traj(i)).x)-1);
        trajectories_org(traj(i)).y=trajectories_org(traj(i)).y(1:length(trajectories_org(traj(i)).y)-1);
        trajectories_org(traj(i)).psf=trajectories_org(traj(i)).psf(1:length(trajectories_org(traj(i)).psf)-1);
        trajectories_org(traj(i)).amp=trajectories_org(traj(i)).amp(1:length(trajectories_org(traj(i)).amp)-1);
        trajectories_org(traj(i)).bgr=trajectories_org(traj(i)).bgr(1:length(trajectories_org(traj(i)).bgr)-1);
        trajectories_org(traj(i)).intens=trajectories_org(traj(i)).intens(1:length(trajectories_org(traj(i)).intens)-1);
        trajectories_org(traj(i)).int_gauss=trajectories_org(traj(i)).int_gauss(1:length(trajectories_org(traj(i)).int_gauss)-1);
        trajectories_org(traj(i)).int_corr=trajectories_org(traj(i)).int_corr(1:length(trajectories_org(traj(i)).int_corr)-1);
        trajectories_org(traj(i)).int_gauss_pi=trajectories_org(traj(i)).int_gauss_pi(1:length(trajectories_org(traj(i)).int_gauss_pi)-1);
        
        trajectories_org(traj(i)).rSqrd=trajectories_org(traj(i)).rSqrd(1:length(trajectories_org(traj(i)).rSqrd)-1);
        trajectories_org(traj(i)).rSqrdUm=trajectories_org(traj(i)).rSqrdUm(1:length(trajectories_org(traj(i)).rSqrdUm)-1);
        
    end
    template=zeros(1,length(trajectories_org(traj(i)).x));
    if ~isempty(trajectories_org(traj(i)).linkNext)
        trajectories_org(trajectories_org(traj(i)).linkNext).linkPrevious=traj(i);
    end
    if isempty(trajectories_org(traj(i)).range)||numel(trajectories_org(traj(i)).range)<2||trajectories_org(traj(i)).range(1,2)==0 
        template(1,:)=1;
        %disp('empty');
    else
        rangeDim(1)
        for  j=1:rangeDim(1)
            
                if trajectories_org(traj(i)).range(j,1)<trajectories_org(traj(i)).frames(1,1)
                    startEntry=trajectories_org(traj(i)).frames(1,1)-startFrame+1;
                    disp('rangeStartMistake');
                    disp('traj(i)');    
                    disp(traj(i));
                    disp('rangeStart');    
                    disp(trajectories_org(traj(i)).range(j,1));
                    disp('frameStart');    
                    disp(trajectories_org(traj(i)).frames(1,1));
                else
                    startEntry=trajectories_org(traj(i)).range(j,1)-startFrame+1;
                    
                end
                if trajectories_org(traj(i)).range(j,2)>trajectories_org(traj(i)).frames(1,end)
                    endEntry=trajectories_org(traj(i)).frames(1,end)-startFrame+1;
                    disp('rangeEndMistake');
                    disp('traj(i)');    
                    disp(traj(i));
                    disp('rangeEnd');    
                    disp(trajectories_org(traj(i)).range(j,1));
                    disp('frameEnd');    
                    disp(trajectories_org(traj(i)).frames(1,1));
                else
                    endEntry=trajectories_org(traj(i)).range(j,2)-startFrame+1;
                end
                    
                
                entries=startEntry:endEntry;
                template(entries)=1;
        end
    end
    trajectories_org(traj(i)).x=trajectories_org(traj(i)).x.*template;
    trajectories_org(traj(i)).y=trajectories_org(traj(i)).y.*template;
    %template
    trajectories_org(traj(i)).amp=trajectories_org(traj(i)).amp.*template;
    trajectories_org(traj(i)).bgr=trajectories_org(traj(i)).bgr.*template;
    trajectories_org(traj(i)).psf=trajectories_org(traj(i)).psf.*template;
    trajectories_org(traj(i)).intens=trajectories_org(traj(i)).intens.*template;
    %traj(i)
    
    %trajectories_org(traj(i)).int_gauss_2pi
    %template
    
    trajectories_org(traj(i)).int_gauss=trajectories_org(traj(i)).int_gauss.*template;
    trajectories_org(traj(i)).int_gauss_2pi=trajectories_org(traj(i)).int_gauss_2pi.*template;
    trajectories_org(traj(i)).int_loc=trajectories_org(traj(i)).int_loc.*template;
    trajectories_org(traj(i)).int_loc_2pi=trajectories_org(traj(i)).int_loc_2pi.*template;
    
    
end
%disp('trajectories_org(8).x');
%disp(trajectories_org(8).x);
k=0;
i=0;
trajNum=[];
while k==0
    i=i+1;
    trajNumTemp=traj(1);
    trajNumCurrentPrevious=traj(1);
    trajNumCurrentNext=traj(1);
    traj(traj==trajNumCurrentPrevious)=[];
    
    %disp('i');
    %disp(i);
    exit=0;
    while exit==0
        if ~isempty(trajectories_org(trajNumCurrentPrevious).linkPrevious)
            if trajectories_org(trajectories_org(trajNumCurrentPrevious).linkPrevious).linkNext==trajNumCurrentPrevious;
                %disp('trajectories_org(trajNumCurrentPrevious).linkPrevious');
                %disp(trajectories_org(trajNumCurrentPrevious).linkPrevious);
                %disp('trajNum(i)first previous');
                %disp(trajNumTemp);
                trajNumTemp(1:(length(trajNumTemp)+1))=horzcat(trajectories_org(trajNumCurrentPrevious).linkPrevious,trajNumTemp);
                trajNumCurrentPrevious=trajectories_org(trajNumCurrentPrevious).linkPrevious;
                traj(traj==trajNumCurrentPrevious)=[];
                %disp('previous');
                %disp('trajNum');
                %disp(trajNumTemp);
            else
                %disp('Mismatch');
                exit=1;
            end
        else
            %disp('no previous');
            exit=1;
        end
    end
    exit=0;
    while exit==0
        if ~isempty(trajectories_org(trajNumCurrentNext).linkNext)
            if trajectories_org(trajectories_org(trajNumCurrentNext).linkNext).linkPrevious==trajNumCurrentNext;
                %disp(trajectories_org(trajNumCurrentPrevious).linkPrevious);
                %disp('trajNum(i)first');
                %disp(trajNumTemp);
                trajNumTemp(1:(length(trajNumTemp)+1))=horzcat(trajNumTemp,trajectories_org(trajNumCurrentNext).linkNext);
                trajNumCurrentNext=trajectories_org(trajNumCurrentNext).linkNext;
                traj(traj==trajNumCurrentNext)=[];
                %disp('next');
                %disp('trajNum(i)second');
                %disp(trajNumTemp);
            else
                disp('Mismatch');
                exit=1;
            end
        else
            %disp('no next');
            exit=1;
        end
    end
    trajNum(i,1:length(trajNumTemp))=trajNumTemp;
    %disp('traj');
    %disp(traj);
    if isempty(traj)
        k=1;
    end
end

%disp('trajNumFinal');
%disp(trajNum);
[trajN,dummy]=size(trajNum);
for i=1:trajN
    %disp('i');
    %disp(i);
    %skip zero elements due to ranging in beginning and end of trajectories
    indexNonZero=find(trajectories_org(trajNum(i,1)).x>0);
    %disp('indexNonZero');
    %disp(indexNonZero);
    %disp('trajectories_org(trajNum(i,1)).x');
    %disp(trajectories_org(trajNum(i,1)).x);
    
    %for number of trajectories to be concatenated
    concNum=find(trajNum(i,:));
    
    trajectories(i,1).trajNum=trajNum(i,1:length(concNum));
    trajectories(i,1).frames=trajectories_org(trajNum(i,1)).frames(indexNonZero(1):indexNonZero(end));
    trajectories(i,1).x=trajectories_org(trajNum(i,1)).x(indexNonZero(1):indexNonZero(end));
    trajectories(i,1).y=trajectories_org(trajNum(i,1)).y(indexNonZero(1):indexNonZero(end));
    trajectories(i,1).rSqrd=[];
    trajectories(i,1).rSqrdUm=[];
    trajectories(i,1).amp=trajectories_org(trajNum(i,1)).amp(indexNonZero(1):indexNonZero(end));
    trajectories(i,1).psf=trajectories_org(trajNum(i,1)).psf(indexNonZero(1):indexNonZero(end));
    trajectories(i,1).bgr=trajectories_org(trajNum(i,1)).bgr(indexNonZero(1):indexNonZero(end));
    trajectories(i,1).intens=trajectories_org(trajNum(i,1)).intens(indexNonZero(1):indexNonZero(end));
    
    trajectories(i,1).int_gauss=trajectories_org(trajNum(i,1)).int_gauss(indexNonZero(1):indexNonZero(end));
    trajectories(i,1).int_gauss_2pi=trajectories_org(trajNum(i,1)).int_gauss_2pi(indexNonZero(1):indexNonZero(end));
    trajectories(i,1).int_loc=trajectories_org(trajNum(i,1)).int_loc(indexNonZero(1):indexNonZero(end));
    trajectories(i,1).int_loc_2pi=trajectories_org(trajNum(i,1)).int_loc_2pi(indexNonZero(1):indexNonZero(end));
    

    
    %for number of trajectories to be concatenated
    
    for j=2:length(concNum)
        %disp('trajNum(i,j)');
        %disp(trajNum(i,j));
        %disp('trajectories_org(trajNum(i,j)).x');
        %disp(trajectories_org(trajNum(i,j)).x);
        
        %skip zero elements due to ranging in beginning and end of
        %trajectorY
        indexNonZero=find(trajectories_org(trajNum(i,j)).x>0);
        
        %store information in dummies
        xDummy=trajectories_org(trajNum(i,j)).x(indexNonZero(1):indexNonZero(end));
        yDummy=trajectories_org(trajNum(i,j)).y(indexNonZero(1):indexNonZero(end));
        ampDummy=trajectories_org(trajNum(i,j)).amp(indexNonZero(1):indexNonZero(end));
        bgrDummy=trajectories_org(trajNum(i,j)).bgr(indexNonZero(1):indexNonZero(end));
        psfDummy=trajectories_org(trajNum(i,j)).psf(indexNonZero(1):indexNonZero(end));
        intensDummy=trajectories_org(trajNum(i,j)).intens(indexNonZero(1):indexNonZero(end));
        framesDummy=trajectories_org(trajNum(i,j)).frames(indexNonZero(1):indexNonZero(end));
        
        int_gauss_dummy=trajectories_org(trajNum(i,j)).int_gauss(indexNonZero(1):indexNonZero(end));
        int_gauss_2pi_dummy=trajectories_org(trajNum(i,j)).int_gauss_2pi(indexNonZero(1):indexNonZero(end));
        int_loc_dummy=trajectories_org(trajNum(i,j)).int_loc(indexNonZero(1):indexNonZero(end));
        int_loc_2pi_dummy=trajectories_org(trajNum(i,j)).int_loc_2pi(indexNonZero(1):indexNonZero(end));
        
        %disp('xDummy');
        %disp(xDummy);
        %disp('framesDummy');
        %disp(framesDummy);
        %disp('trajectories_org(trajNum(i,j)).frames(indexNonZero(1))');
        %disp(trajectories_org(trajNum(i,j)).frames(indexNonZero(1)));
        %if framesDummy(1)>trajectories(i).frames(end)
        %    lengthDiff=trajectories_org(trajNum(i,j)).frames(indexNonZero(1))-(trajectories(i).frames(1,end)+1);
        %    disp('trajectories(i).xbeforeZeros');
        %   disp(trajectories(i).x);
        %    trajectories(i).x(length(trajectories(i).x)+1:(length(trajectories(i).x)+lengthDiff))=0;
        %    trajectories(i).x(length(trajectories(i).x)+1:(length(trajectories(i).x)+length(xDummy)))=xDummy;
        %    disp('trajectories(i).xafterZeros');
        %    disp(trajectories(i).x);
        %    disp('trajectories(i).frames');
        %    disp(trajectories(i).frames);
        %    disp('trajectories(i).frames(1):(trajectories(i).frames(1)+length(trajectories(i).x))')
        %    disp(trajectories(i).frames(1):(trajectories(i).frames(1)+length(trajectories(i).x)-1))
        %    trajectories(i).frames(1:length(trajectories(i).x))=trajectories(i).frames(1):(trajectories(i).frames(1)+length(trajectories(i).x)-1);
        %    disp('hsahhshashash');
        %else
            %disp('second else');
            %disp('framesDummy(1,1)');
            %disp(framesDummy(1,1));
            %disp('trajectories(i).frames(1,end)');
            %disp(trajectories(i).frames(1,end));
            lengthDiff=framesDummy(1,1)-trajectories(i,1).frames(1,end)-1;
            %disp('lengthDiff');
            %disp(lengthDiff);
            %disp('length');
            %disp(length(trajectories(i).x)+lengthDiff+1:length(trajectories(i).x)+lengthDiff+length(xDummy));
            %disp('xDummy');
            %disp(xDummy);
            %disp('trajectories(i).x before dummy extension');
            %disp(trajectories(i).x);
            trajectories(i,1).x(length(trajectories(i,1).x)+lengthDiff+1:length(trajectories(i,1).x)+lengthDiff+length(xDummy))=xDummy;
            trajectories(i,1).y(length(trajectories(i,1).y)+lengthDiff+1:length(trajectories(i,1).y)+lengthDiff+length(yDummy))=yDummy;
            trajectories(i,1).amp(length(trajectories(i,1).amp)+lengthDiff+1:length(trajectories(i,1).amp)+lengthDiff+length(ampDummy))=ampDummy;
            trajectories(i,1).bgr(length(trajectories(i,1).bgr)+lengthDiff+1:length(trajectories(i,1).bgr)+lengthDiff+length(bgrDummy))=bgrDummy;
            trajectories(i,1).intens(length(trajectories(i,1).intens)+lengthDiff+1:length(trajectories(i,1).intens)+lengthDiff+length(intensDummy))=intensDummy;
            trajectories(i,1).psf(length(trajectories(i,1).psf)+lengthDiff+1:length(trajectories(i,1).psf)+lengthDiff+length(psfDummy))=psfDummy;
            
            trajectories(i,1).int_gauss(length(trajectories(i,1).int_gauss)+lengthDiff+1:length(trajectories(i,1).int_gauss)+lengthDiff+length(int_gauss_dummy))=int_gauss_dummy;
            trajectories(i,1).int_gauss_2pi(length(trajectories(i,1).int_gauss_2pi)+lengthDiff+1:length(trajectories(i,1).int_gauss_2pi)+lengthDiff+length(int_gauss_2pi_dummy))=int_gauss_2pi_dummy;
            trajectories(i,1).int_loc(length(trajectories(i,1).int_loc)+lengthDiff+1:length(trajectories(i,1).int_loc)+lengthDiff+length(int_loc_dummy))=int_loc_dummy;
            trajectories(i,1).int_loc_2pi(length(trajectories(i,1).int_loc_2pi)+lengthDiff+1:length(trajectories(i,1).int_loc_2pi)+lengthDiff+length(int_loc_2pi_dummy))=int_loc_2pi_dummy;
            
            %disp('trajectories(i).x(length(trajectories(i).x)+lengthDiff+1:length(trajectories(i).x)+lengthDiff+length(xDummy))=xDummy;');
            %disp(trajectories(i).x);
            trajectories(i,1).frames(1:length(trajectories(i,1).x))=trajectories(i,1).frames(1):(trajectories(i,1).frames(1)+length(trajectories(i,1).x)-1);
            
        %end
    end
end


traj=1:length(trajectories);

for i=1:length(trajectories)
        for j=1:length(trajectories(traj(i),1).x)-1
            if trajectories(traj(i),1).x(1,j)>0 && trajectories(traj(i),1).x(1,j+1)>0
               trajectories(traj(i),1).rSqrd(1,j)=(trajectories(traj(i),1).x(1,j)-trajectories(traj(i),1).x(1,j+1))^2+(trajectories(traj(i),1).y(1,j)-trajectories(traj(i),1).y(1,j+1))^2; 
            else
                trajectories(traj(i),1).rSqrd(1,j)=0;
            end
        end
        trajectories(traj(i),1).rSqrdUm=trajectories(traj(i),1).rSqrd*0.08*0.08;

        if ~isempty(trajectories(traj(i),1).rSqrd)
            rSqrd = trajectories(traj(i),1).rSqrd(trajectories(traj(i),1).rSqrd~=0);

            trajectories(traj(i),1).meanSqrd=mean(rSqrd);
            trajectories(traj(i),1).diffConstUm=(trajectories(traj(i),1).meanSqrd*0.08*0.08/(4*0.032));
            trajectories(traj(i),1).diffConstNm=(trajectories(traj(i),1).meanSqrd*80*80/(4*32));
        else
            trajectories(traj(i),1).meanSqrd=[];
            trajectories(traj(i),1).diffConstUm=[];
            trajectories(traj(i),1).diffConstNm=[];
        end
        if ~isempty(trajectories(i,1).rSqrd)
            trajectories(traj(i),1).maxInt=max(trajectories(traj(i),1).intens(:));
            
            trajectories(traj(i),1).maxInt_gauss=max(trajectories(traj(i),1).int_gauss(:));
            trajectories(traj(i),1).maxInt_gauss_2pi=max(trajectories(traj(i),1).int_gauss_2pi(:));
            trajectories(traj(i),1).maxInt_loc=max(trajectories(traj(i),1).int_loc(:));
            trajectories(traj(i),1).maxInt_loc_2pi=max(trajectories(traj(i),1).int_loc_2pi(:));
            
            trajectories(traj(i),1).maxAmp=max(trajectories(traj(i),1).amp(:));
            trajectories(traj(i),1).maxPsf=max(trajectories(traj(i),1).psf(:));
            trajectories(traj(i),1).mean5Int=0;
            
            trajectories(traj(i),1).mean5Int_gauss=0;
            trajectories(traj(i),1).mean5Int_gauss_2pi=0;
            trajectories(traj(i),1).mean5Int_loc=0;
            trajectories(traj(i),1).mean5Int_loc_2pi=0;
            
            trajectories(traj(i),1).mean5Amp=0;
            trajectories(traj(i),1).meanFullInt=0;
            
            trajectories(traj(i),1).meanFullInt_gauss=0;
            trajectories(traj(i),1).meanFullInt_gauss_2pi=0;
            trajectories(traj(i),1).meanFullInt_loc=0;
            trajectories(traj(i),1).meanFullInt_loc_2pi=0;
            
            %lenTraj=length(trajectories(traj(i),1).intens);
            ll=0;
            nonZeroEntries=trajectories(traj(i),1).intens>0;
            nonZeroInt=trajectories(traj(i),1).intens(nonZeroEntries);
            nonZeroAmp=trajectories(traj(i),1).amp(nonZeroEntries);
            nonZeroPsf=trajectories(traj(i),1).psf(nonZeroEntries);
            
            nonZeroInt_gauss=trajectories(traj(i),1).int_gauss(nonZeroEntries);
            nonZeroInt_gauss_2pi=trajectories(traj(i),1).int_gauss_2pi(nonZeroEntries);
            nonZeroInt_loc=trajectories(traj(i),1).int_loc(nonZeroEntries);
            nonZeroInt_loc_2pi=trajectories(traj(i),1).int_loc_2pi(nonZeroEntries);
            
            lenTraj=length(nonZeroInt);
            %for k=1:lenTraj
            %    if trajectories(traj(i),1).intens(k)>0
            %        ll=ll+1;
            %        trajectories(traj(i),1).meanFullInt=trajectories(traj(i),1).meanFullInt+mean(trajectories(traj(i),1).intens(k));
            %    end
            %end
            %trajectories(traj(i),1).meanFullInt=trajectories(traj(i),1).meanFullInt/ll;
            trajectories(traj(i),1).meanFullInt=mean(nonZeroInt);
            trajectories(traj(i),1).meanFullAmp=mean(nonZeroAmp);
            
            trajectories(traj(i),1).meanFullInt_gauss=mean(nonZeroInt_gauss);
            trajectories(traj(i),1).meanFullInt_gauss_2pi=mean(nonZeroInt_gauss_2pi);
            trajectories(traj(i),1).meanFullInt_loc=mean(nonZeroInt_loc);
            trajectories(traj(i),1).meanFullInt_loc_2pi=mean(nonZeroInt_loc_2pi);
            
            if lenTraj>4
                %ll=0;
                %for k=1:5
                %    if trajectories(traj(i),1).intens(k)>0
                %    ll=ll+1;
                %    trajectories(traj(i),1).mean5Int=trajectories(traj(i),1).mean5Int+mean(trajectories(traj(i),1).intens(k));
                %    trajectories(traj(i),1).mean5Amp=trajectories(traj(i),1).mean5Amp+mean(trajectories(traj(i),1).amp(k));
                %    end
                %end
                %trajectories(traj(i),1).mean5Int=trajectories(traj(i),1).mean5Int/ll;
                %trajectories(traj(i),1).mean5Amp=trajectories(traj(i),1).mean5Amp/ll;
                trajectories(traj(i),1).mean5Int=mean(nonZeroInt(1:5));
                
                trajectories(traj(i),1).mean5Int_gauss=mean(nonZeroInt_gauss(1:5));
                trajectories(traj(i),1).mean5Int_gauss_2pi=mean(nonZeroInt_gauss_2pi(1:5));
                trajectories(traj(i),1).mean5Int_loc=mean(nonZeroInt_loc(1:5));
                trajectories(traj(i),1).mean5Int_loc_2pi=mean(nonZeroInt_loc_2pi(1:5));
                
                trajectories(traj(i),1).mean5Amp=mean(nonZeroAmp(1:5));
                
                nonZeroIntSort=sort(nonZeroInt,'descend');
                
                nonZeroIntSort_gauss=sort(nonZeroInt_gauss,'descend');
                nonZeroIntSort_gauss_2pi=sort(nonZeroInt_gauss_2pi,'descend');
                nonZeroIntSort_loc=sort(nonZeroInt_loc,'descend');
                nonZeroIntSort_loc_2pi=sort(nonZeroInt_loc_2pi,'descend');
                
                trajectories(traj(i),1).mean5MaxInt=mean(nonZeroIntSort(1:5));
                
                trajectories(traj(i),1).mean5MaxInt_gauss=mean(nonZeroIntSort_gauss(1:5));
                trajectories(traj(i),1).mean5MaxInt_gauss_2pi=mean(nonZeroIntSort_gauss_2pi(1:5));
                trajectories(traj(i),1).mean5MaxInt_loc=mean(nonZeroIntSort_loc(1:5));
                trajectories(traj(i),1).mean5MaxInt_loc_2pi=mean(nonZeroIntSort_loc_2pi(1:5));
                
            else
                %ll=0;

                %for k=1:lenTraj

                 %  if trajectories(traj(i),1).intens(k)>0
                 %   ll=ll+1;
                %    trajectories(traj(i),1).mean5Int=trajectories(traj(i),1).mean5Int+mean(trajectories(traj(i),1).intens(k));
                 %   trajectories(traj(i),1).mean5Amp=trajectories(traj(i),1).mean5Amp+mean(trajectories(traj(i),1).amp(k));
                %    end
                %end
                trajectories(traj(i),1).mean5Int=trajectories(traj(i),1).meanFullInt;
                
                trajectories(traj(i),1).mean5Int_gauss=trajectories(i).meanFullInt_gauss;
                trajectories(traj(i),1).mean5Int_gauss_2pi=trajectories(i).meanFullInt_gauss_2pi;
                trajectories(traj(i),1).mean5Int_loc=trajectories(i).meanFullInt_loc;
                trajectories(traj(i),1).mean5Int_loc_2pi=trajectories(i).meanFullInt_loc_2pi;
                
                trajectories(traj(i),1).mean5Amp=trajectories(traj(i),1).meanFullAmp;
                trajectories(traj(i),1).mean5MaxInt=trajectories(traj(i),1).meanFullInt;
                
                trajectories(traj(i),1).mean5MaxInt_gauss=trajectories(i).meanFullInt_gauss;
                trajectories(traj(i),1).mean5MaxInt_gauss_2pi=trajectories(i).meanFullInt_gauss_2pi;
                trajectories(traj(i),1).mean5MaxInt_loc=trajectories(i).meanFullInt_loc;
                trajectories(traj(i),1).mean5MaxInt_loc_2pi=trajectories(i).meanFullInt_loc_2pi;
                
            end
        end
        
        trajectories(traj(i),1).seqOfEvents(1,1)=trajectories(traj(i),1).frames(1);
        trajectories(traj(i),1).seqOfEvents(2,1)=trajectories(traj(i),1).frames(end);
        trajectories(traj(i),1).seqOfEvents(1:2,3)=1;
        trajectories(traj(i),1).seqOfEvents(1:2,4)=NaN;
        trajectories(traj(i),1).seqOfEvents(1,2)=1;
        trajectories(traj(i),1).seqOfEvents(1,2)=2;
 
    
end
