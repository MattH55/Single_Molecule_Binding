function [ image ] = normalizeGaussian( FOV )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

image=FOV;
image=double(image);
maxInt=double(max(FOV(:)));
norm=256/maxInt;
for x=1:512
    for y=1:512
        a=exp(-((x-256)^2+(y-256)^2)/500^2);
        f=1/a;
        
        image(x,y)=FOV(x,y)*f;
    end
end

end

