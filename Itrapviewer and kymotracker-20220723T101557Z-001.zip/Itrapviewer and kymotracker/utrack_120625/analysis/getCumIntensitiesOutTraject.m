function [ intensities ] = getCumIntensitiesOutTraject( trajectories,traj )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

intensities=[];
k=0;
if nargin<2 || isempty(traj)
    traj=1:1:length(trajectories);
end

for i=1:length(traj)
    for j=1:length(trajectories(traj(i)).intens)
        if trajectories(traj(i)).intens(j)==0
        else
        k=k+1;    
        intensities(k)=trajectories(traj(i)).intens(j);
        
        end
    end
end
intensities=intensities';
end

