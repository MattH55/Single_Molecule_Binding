function [ ] = plotCummArjan( input )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


f={'mo','ro','bo','ms','rs','bs','m*','r*','b*','rs','bs','m*','r*','b*'};
disp(input);
figure
for i=1:length(input)
    disp(f);
    semilogy(input(i).oneStep(:,1),input(i).oneStep(:,2),char(f(i)));
    hold on
    
end
axis([0 0.2 0.01 1])
end
