function [ trajectories ] = linkTrajDNA(trajectories,links )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

[len,dummy]=size(links);



for i=1:len
    
        
    if links(i,1)>0 && i+1<=len && links(i+1,1)>0
        %disp(links(i,1));
        trajectories(links(i,1)).linkNext(1,1)=links(i+1,1);
    end
    
     %disp('links(i,1)');
    %disp(links(i,1));
    %disp('dummy');
    %disp(dummy);
    if  dummy>2 && links(i,1)>0 %&& links(i,3)>0
        if links(i,2)> links(i,3)
           disp(' ' ); 
           disp(['Warning: In trajectory nr. ' num2str(links(i,1)) '!!!']);
           disp('!!!Last frame < first frame!!!');
           
        end
        if links(i,2)<trajectories(links(i,1)).frames(1)
           disp(' ' ); 
           disp(['Warning: In trajectory nr. ' num2str(links(i,1)) '!!!']);
           disp('!!!First frame < trajectory Start!!!');
        end
        
        trajectories(links(i,1)).range(1,1:2)=links(i,2:3);
        
    end
    
        
end

