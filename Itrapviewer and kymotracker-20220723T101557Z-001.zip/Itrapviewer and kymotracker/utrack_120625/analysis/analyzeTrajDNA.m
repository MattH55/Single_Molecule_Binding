function [ analysisIndividualTraj,cummDistrMovie ] = analyzeTrajDNA( cells,trajectories,analysisPara )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


if nargin<3
    analysisPara=[];
    disp(' ');
    disp('Warning: no analysis parameters specified!');
end

[sizeCells,nrTraj]=size(cells);
if sizeCells==0
    nrCells=length(trajectories);
    traj=1:1:length(trajectories);
else
    nrCells=sizeCells;
end



cummDistrCells=repmat(struct('cummDistr',[],'mean5IntDistr',[],'mean5MaxIntDistr',[],'meanFullIntDistr',[],...
    'mean5IntDistr_gauss',[],'mean5MaxIntDistr_gauss',[],'meanFullIntDistr_gauss',[],...
    'mean5IntDistr_gauss_2pi',[],'mean5MaxIntDistr_gauss_2pi',[],'meanFullIntDistr_gauss_2pi',[],...
    'mean5IntDistr_loc',[],'mean5MaxIntDistr_loc',[],'meanFullIntDistr_loc',[],...
    'mean5IntDistr_loc_2pi',[],'mean5MaxIntDistr_loc_2pi',[],'meanFullIntDistr_loc_2pi',[]),nrCells,1);
trajMovie=[];
mean5IntDistrMovie=[];
mean5MaxIntDistrMovie=[];
meanFullIntDistrMovie=[];

mean5IntDistrMovie_gauss=[];
mean5MaxIntDistrMovie_gauss=[];
meanFullIntDistrMovie_gauss=[];

mean5IntDistrMovie_gauss_2pi=[];
mean5MaxIntDistrMovie_gauss_2pi=[];
meanFullIntDistrMovie_gauss_2pi=[];

mean5IntDistrMovie_loc=[];
mean5MaxIntDistrMovie_loc=[];
meanFullIntDistrMovie_loc=[];

mean5IntDistrMovie_loc_2pi=[];
mean5MaxIntDistrMovie_loc_2pi=[];
meanFullIntDistrMovie_loc_2pi=[];

meanSqrdMovie=[];
trajNumMovie=[];

 analysisIndividualTraj=[];

%disp('nrCells');
%disp(nrCells);
for i=1:nrCells
    if sizeCells==0
    traj=i;    
    else
    traj=cells(i,:);
    traj=traj(find(traj));
    end
    
    
    mean5IntDistr=[];
    mean5MaxIntDistr=[];
    meanFullIntDistr=[];
    
    mean5IntDistr_gauss=[];
    mean5MaxIntDistr_gauss=[];
    meanFullIntDistr_gauss=[];

    mean5IntDistr_gauss_2pi=[];
    mean5MaxIntDistr_gauss_2pi=[];
    meanFullIntDistr_gauss_2pi=[];

    mean5IntDistr_loc=[];
    mean5MaxIntDistr_loc=[];
    meanFullIntDistr_loc=[];

    mean5IntDistr_loc_2pi=[];
    mean5MaxIntDistr_loc_2pi=[];
    meanFullIntDistr_loc_2pi=[];
    
    meanSqrd=[];
    trajNum=[];
    
    for k=1:length(traj)
        if isempty(trajectories(traj(k)).x)
            traj(k)=0;
        end    
    end
    traj=traj(find(traj));
    if isempty(traj)
    else
        
        trajMovie=horzcat(trajMovie,traj);
        
        for j=1:length(traj)
            
            mean5IntDistr=vertcat(mean5IntDistr,round(trajectories(traj(j)).mean5Int));
            mean5MaxIntDistr=vertcat(mean5MaxIntDistr,round(trajectories(traj(j)).mean5MaxInt));
            meanFullIntDistr=vertcat(meanFullIntDistr,round(trajectories(traj(j)).meanFullInt));
            
            mean5IntDistr_gauss=vertcat(mean5IntDistr_gauss,round(trajectories(traj(j)).mean5Int_gauss));
            mean5MaxIntDistr_gauss=vertcat(mean5MaxIntDistr_gauss,round(trajectories(traj(j)).mean5MaxInt_gauss));
            meanFullIntDistr_gauss=vertcat(meanFullIntDistr_gauss,round(trajectories(traj(j)).meanFullInt_gauss));
            
            mean5IntDistr_gauss_2pi=vertcat(mean5IntDistr_gauss_2pi,round(trajectories(traj(j)).mean5Int_gauss_2pi));
            mean5MaxIntDistr_gauss_2pi=vertcat(mean5MaxIntDistr_gauss_2pi,round(trajectories(traj(j)).mean5MaxInt_gauss_2pi));
            meanFullIntDistr_gauss_2pi=vertcat(meanFullIntDistr_gauss_2pi,round(trajectories(traj(j)).meanFullInt_gauss_2pi));
            
            mean5IntDistr_loc=vertcat(mean5IntDistr_loc,round(trajectories(traj(j)).mean5Int_loc));
            mean5MaxIntDistr_loc=vertcat(mean5MaxIntDistr_loc,round(trajectories(traj(j)).mean5MaxInt_loc));
            meanFullIntDistr_loc=vertcat(meanFullIntDistr_loc,round(trajectories(traj(j)).meanFullInt_loc));
            
            mean5IntDistr_loc_2pi=vertcat(mean5IntDistr_loc_2pi,round(trajectories(traj(j)).mean5Int_loc_2pi));
            mean5MaxIntDistr_loc_2pi=vertcat(mean5MaxIntDistr_loc_2pi,round(trajectories(traj(j)).mean5MaxInt_loc_2pi));
            meanFullIntDistr_loc_2pi=vertcat(meanFullIntDistr_loc_2pi,round(trajectories(traj(j)).meanFullInt_loc_2pi));
            
            meanSqrd=vertcat(meanSqrd,trajectories(traj(j)).meanSqrd);
            trajNum=vertcat(trajNum,traj(j));
            
        end
    end
    %disp(length(meanSqrd));
    %disp('kkk');
    %disp(length(mean5IntDistr));
    
   
    
    mean5IntDistrMovie=vertcat(mean5IntDistrMovie,mean5IntDistr);
    [mean5IntDistr,IX]=sort(mean5IntDistr);
    mean5IntDistr=horzcat(mean5IntDistr,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    
    
    mean5IntDistrMovie_gauss_2pi=vertcat(mean5IntDistrMovie_gauss_2pi,mean5IntDistr_gauss_2pi);
    [mean5IntDistr_gauss_2pi,IX]=sort(mean5IntDistr_gauss_2pi);
    mean5IntDistr_gauss_2pi=horzcat(mean5IntDistr_gauss_2pi,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    mean5IntDistrMovie_gauss=vertcat(mean5IntDistrMovie_gauss,mean5IntDistr_gauss);
    [mean5IntDistr_gauss,IX]=sort(mean5IntDistr_gauss);
    mean5IntDistr_gauss=horzcat(mean5IntDistr_gauss,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    mean5IntDistrMovie_loc=vertcat(mean5IntDistrMovie_loc,mean5IntDistr_loc);
    [mean5IntDistr_loc,IX]=sort(mean5IntDistr_loc);
    mean5IntDistr_loc=horzcat(mean5IntDistr_loc,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    mean5IntDistrMovie_loc_2pi=vertcat(mean5IntDistrMovie_loc_2pi,mean5IntDistr_loc_2pi);
    [mean5IntDistr_loc_2pi,IX]=sort(mean5IntDistr_loc_2pi);
    mean5IntDistr_loc_2pi=horzcat(mean5IntDistr_loc_2pi,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    mean5MaxIntDistrMovie=vertcat(mean5MaxIntDistrMovie,mean5MaxIntDistr);
    [mean5MaxIntDistr,IX]=sort(mean5MaxIntDistr);
    mean5MaxIntDistr=horzcat(mean5MaxIntDistr,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    mean5MaxIntDistrMovie_gauss=vertcat(mean5MaxIntDistrMovie_gauss,mean5MaxIntDistr_gauss);
    [mean5MaxIntDistr_gauss,IX]=sort(mean5MaxIntDistr_gauss);
    mean5MaxIntDistr_gauss=horzcat(mean5MaxIntDistr_gauss,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    mean5MaxIntDistrMovie_gauss_2pi=vertcat(mean5MaxIntDistrMovie_gauss_2pi,mean5MaxIntDistr_gauss_2pi);
    [mean5MaxIntDistr_gauss_2pi,IX]=sort(mean5MaxIntDistr_gauss_2pi);
    mean5MaxIntDistr_gauss_2pi=horzcat(mean5MaxIntDistr_gauss_2pi,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    mean5MaxIntDistrMovie_loc=vertcat(mean5MaxIntDistrMovie_loc,mean5MaxIntDistr_loc);
    [mean5MaxIntDistr_loc,IX]=sort(mean5MaxIntDistr_loc);
    mean5MaxIntDistr_loc=horzcat(mean5MaxIntDistr_loc,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    mean5MaxIntDistrMovie_loc_2pi=vertcat(mean5MaxIntDistrMovie_loc_2pi,mean5MaxIntDistr_loc_2pi);
    [mean5MaxIntDistr_loc_2pi,IX]=sort(mean5MaxIntDistr_loc_2pi);
    mean5MaxIntDistr_loc_2pi=horzcat(mean5MaxIntDistr_loc_2pi,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    meanFullIntDistrMovie=vertcat(meanFullIntDistrMovie,meanFullIntDistr);
    [meanFullIntDistr,IX]=sort(meanFullIntDistr);
    meanFullIntDistr=horzcat( meanFullIntDistr,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    meanFullIntDistrMovie_gauss=vertcat(meanFullIntDistrMovie_gauss,meanFullIntDistr_gauss);
    [meanFullIntDistr_gauss,IX]=sort(meanFullIntDistr_gauss);
    meanFullIntDistr_gauss=horzcat( meanFullIntDistr_gauss,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    meanFullIntDistrMovie_gauss_2pi=vertcat(meanFullIntDistrMovie_gauss_2pi,meanFullIntDistr_gauss_2pi);
    [meanFullIntDistr_gauss_2pi,IX]=sort(meanFullIntDistr_gauss_2pi);
    meanFullIntDistr_gauss_2pi=horzcat( meanFullIntDistr_gauss_2pi,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    meanFullIntDistrMovie_loc=vertcat(meanFullIntDistrMovie_loc,meanFullIntDistr_loc);
    [meanFullIntDistr_loc,IX]=sort(meanFullIntDistr_loc);
    meanFullIntDistr_loc=horzcat( meanFullIntDistr_loc,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    meanFullIntDistrMovie_loc_2pi=vertcat(meanFullIntDistrMovie_loc_2pi,meanFullIntDistr_loc_2pi);
    [meanFullIntDistr_loc_2pi,IX]=sort(meanFullIntDistr_loc_2pi);
    meanFullIntDistr_loc_2pi=horzcat( meanFullIntDistr_loc_2pi,trajNum(IX),meanSqrd(IX),(meanSqrd(IX)*80*80/(4*32)),(meanSqrd(IX)*0.08*0.08/(4*0.032)));
    
    
    analysisIndividualTrajDummy=getCummOutTrajDNA( trajectories, traj, analysisPara);
    
    
    analysisIndividualTrajDummy.mean5IntDistr=mean5IntDistr;
    analysisIndividualTrajDummy.mean5MaxIntDistr=mean5MaxIntDistr;
    analysisIndividualTrajDummy.meanFullIntDistr=meanFullIntDistr;
    analysisIndividualTrajDummy.mean5IntDistr_gauss=mean5IntDistr_gauss;
    analysisIndividualTrajDummy.mean5MaxIntDistr_gauss=mean5MaxIntDistr_gauss;
    analysisIndividualTrajDummy.meanFullIntDistr_gauss=meanFullIntDistr_gauss;
    analysisIndividualTrajDummy.mean5IntDistr_gauss_2pi=mean5IntDistr_gauss_2pi;
    analysisIndividualTrajDummy.mean5MaxIntDistr_gauss_2pi=mean5MaxIntDistr_gauss_2pi;
    analysisIndividualTrajDummy.meanFullIntDistr_gauss_2pi=meanFullIntDistr_gauss_2pi;
    analysisIndividualTrajDummy.mean5IntDistr_loc=mean5IntDistr_loc;
    analysisIndividualTrajDummy.mean5MaxIntDistr_loc=mean5MaxIntDistr_loc;
    analysisIndividualTrajDummy.meanFullIntDistr_loc=meanFullIntDistr_loc;
    analysisIndividualTrajDummy.mean5IntDistr_loc_2pi=mean5IntDistr_loc_2pi;
    analysisIndividualTrajDummy.mean5MaxIntDistr_loc_2pi=mean5MaxIntDistr_loc_2pi;
    analysisIndividualTrajDummy.meanFullIntDistr_loc_2pi=meanFullIntDistr_loc_2pi;
    analysisIndividualTrajDummy.allIntDistr=sort(getCumIntensitiesOutTraject( trajectories,traj ));
    analysisIndividualTrajDummy.allIntDistrGauss2pi=sort(getCumIntensitiesOutTrajectGauss2pi( trajectories,traj ));
    analysisIndividualTrajDummy.allIntDistrLoc2pi=sort(getCumIntensitiesOutTrajectLoc2pi( trajectories,traj ));
    
    
    
    
    analysisIndividualTraj= horzcat(analysisIndividualTraj,analysisIndividualTrajDummy);
    
    %disp('i');
    %disp(i);
    %disp('analysisIndividualTraj');
    %disp(analysisIndividualTraj);
    meanSqrdMovie=vertcat(meanSqrdMovie,meanSqrd);
    trajNumMovie=vertcat(trajNumMovie,trajNum);
     
     
   
end
%disp('ggggggggggggggg');
%disp(length(mean5IntDistrMovie));
%disp(mean5IntDistrMovie);
%disp(length(meanSqrdMovie));
%disp(length(mean5MaxIntDistrMovie));
%disp(length(meanFullIntDistrMovie));
%disp('gssssssssssssssssss');
cummDistrMovie=getCummOutTrajDNA( trajectories, trajMovie,analysisPara);

[mean5IntDistrMovie,IX]=sort(mean5IntDistrMovie);
cummDistrMovie.mean5IntDistr=horzcat(mean5IntDistrMovie,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));

[mean5IntDistrMovie_gauss,IX]=sort(mean5IntDistrMovie_gauss);
cummDistrMovie.mean5IntDistr_gauss=horzcat(mean5IntDistrMovie_gauss,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));

[mean5IntDistrMovie_gauss_2pi,IX]=sort(mean5IntDistrMovie_gauss_2pi);
cummDistrMovie.mean5IntDistr_gauss_2pi=horzcat(mean5IntDistrMovie_gauss_2pi,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));

[mean5IntDistrMovie_loc,IX]=sort(mean5IntDistrMovie_loc);
cummDistrMovie.mean5IntDistr_loc=horzcat(mean5IntDistrMovie_loc,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));

[mean5IntDistrMovie_loc_2pi,IX]=sort(mean5IntDistrMovie_loc_2pi);
cummDistrMovie.mean5IntDistr_loc_2pi=horzcat(mean5IntDistrMovie_loc_2pi,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));



[meanFullIntDistrMovie,IX]=sort(meanFullIntDistrMovie);
cummDistrMovie.meanFullIntDistr=horzcat(meanFullIntDistrMovie,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));

[meanFullIntDistrMovie_gauss,IX]=sort(meanFullIntDistrMovie_gauss);
cummDistrMovie.meanFullIntDistr_gauss=horzcat(meanFullIntDistrMovie_gauss,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));

[meanFullIntDistrMovie_gauss_2pi,IX]=sort(meanFullIntDistrMovie_gauss_2pi);
cummDistrMovie.meanFullIntDistr_gauss_2pi=horzcat(meanFullIntDistrMovie_gauss_2pi,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));

[meanFullIntDistrMovie_loc,IX]=sort(meanFullIntDistrMovie_loc);
cummDistrMovie.meanFullIntDistr_loc=horzcat(meanFullIntDistrMovie_loc,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));

[meanFullIntDistrMovie_loc_2pi,IX]=sort(meanFullIntDistrMovie_loc_2pi);
cummDistrMovie.meanFullIntDistr_loc_2pi=horzcat(meanFullIntDistrMovie_loc_2pi,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));


cummDistrMovie.allIntDistr=sort(getCumIntensitiesOutTraject( trajectories,trajMovie ));
cummDistrMovie.allIntDistrGauss2pi=sort(getCumIntensitiesOutTrajectGauss2pi( trajectories,trajMovie ));
cummDistrMovie.allIntDistrLoc2pi=sort(getCumIntensitiesOutTrajectLoc2pi( trajectories,trajMovie ));

[mean5MaxIntDistrMovie,IX]=sort(mean5MaxIntDistrMovie);
cummDistrMovie.mean5MaxIntDistr=horzcat(mean5MaxIntDistrMovie,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));

[mean5MaxIntDistrMovie_gauss,IX]=sort(mean5MaxIntDistrMovie_gauss);
cummDistrMovie.mean5MaxIntDistr_gauss=horzcat(mean5MaxIntDistrMovie_gauss,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));

[mean5MaxIntDistrMovie_gauss_2pi,IX]=sort(mean5MaxIntDistrMovie_gauss_2pi);
cummDistrMovie.mean5MaxIntDistr_gauss_2pi=horzcat(mean5MaxIntDistrMovie_gauss_2pi,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));

[mean5MaxIntDistrMovie_loc,IX]=sort(mean5MaxIntDistrMovie_loc);
cummDistrMovie.mean5MaxIntDistr_loc=horzcat(mean5MaxIntDistrMovie_loc,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));

[mean5MaxIntDistrMovie_loc_2pi,IX]=sort(mean5MaxIntDistrMovie_loc_2pi);
cummDistrMovie.mean5MaxIntDistr_loc_2pi=horzcat(mean5MaxIntDistrMovie_loc_2pi,trajNumMovie(IX),meanSqrdMovie(IX),(meanSqrdMovie(IX)*80*80/(4*32)),(meanSqrdMovie(IX)*0.08*0.08/(4*0.032)));


%disp('length(meanSqrdMovie)');
%disp(length(meanSqrdMovie(IX)));
%disp(length(meanFullIntDistrMovie));


end

