function [ analysisData] = getCummOutTrajDNA( trajectories,traj ,analysisPara)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

analysisData = repmat(struct('meanRsqrdSteps',[],'meanXsqrdSteps',[],'meanYsqrdSteps',[],...
                'RdiffConst',[],'XdiffConst',[],'YdiffConst',[],...
                'deltaRdiffConst',[],'deltaXdiffConst',[],'deltaYdiffConst',[],...
                'sigmaR',[],'sigmaX',[],'sigmaY',[],...
                'deltaSigmaR',[],'deltaSigmaX',[],'deltaSigmaY',[],...
                'cpdRsqrd',struct('displ',[]),'cpdXsqrd',struct('displ',[]),'cpdYsqrd',struct('displ',[]),...
                'RdiffConstSteps',[],'XdiffConstSteps',[],'YdiffConstSteps',[],'traj',[]),1);






if nargin<3 || ~isfield(analysisPara, 'numTimeLags') || isempty(analysisPara.numTimeLags) 

    numOfSteps=8;
    disp('errorNumOfSteps');
else
    numOfSteps=int8(analysisPara.numTimeLags);
end

if nargin<3 || ~isfield(analysisPara, 'pixelSize') || isempty(analysisPara.pixelSize) 
    disp('pixelSize');
    pixelSize=0.075;
else
    pixelSize=analysisPara.pixelSize;
end

if nargin<3 || ~isfield(analysisPara, 'timeLapse') || isempty(analysisPara.timeLapse) 
       disp('errorTimelapse');
    timeLapse=0.301;
else
    timeLapse=analysisPara.timeLapse;
end

if nargin<3 || ~isfield(analysisPara, 'diffDim') || isempty(analysisPara.diffDim) 
    disp('erroDiffDimr');
    %disp(~isfield(analysisPara, 'diffDim'));
    dim=2;
else
    dim=analysisPara.diffDim;
end

if nargin<3 || ~isfield(analysisPara, 'msdDispFlag') || isempty(analysisPara.msdDispFlag) 
    disp('msdDispFlag');
   msdDispFlag=0;
else
    msdDispFlag=analysisPara.msdDispFlag;
end





sqrdDispl=repmat(struct('RsqrdDispl',[],'XsqrdDispl',[],'YsqrdDispl',[]),numOfSteps);


if nargin<2||isempty(traj)
    numTracks=length(trajectories);
    for i=1:numTracks
        traj(i)=i;
    end
else
    %%%disp('hashshah');
    numTracks=numel(traj);
end
analysisData.traj=traj;
%disp('numOfSteps');
%%disp(numOfSteps);
%%disp('pixelSize');
%disp(pixelSize);
%disp('timeLapse');
%disp(timeLapse);
%%disp('dim');
%disp(dim);



for k=1:numOfSteps
    for i=1:numTracks
        for j=1:numel(trajectories(traj(i)).x)-k
            if  trajectories(traj(i)).x(j)>0 && trajectories(traj(i)).x(j+k)>0
               %disp(trajectories(traj(i)).x(j));
               %disp(trajectories(traj(i)).x(j+2));
               xSqrd=(trajectories(traj(i)).x(j)-trajectories(traj(i)).x(j+k))^2;
               ySqrd=(trajectories(traj(i)).y(j)-trajectories(traj(i)).y(j+k))^2;
               rSqrd=xSqrd+ySqrd;
               
               sqrdDispl(k).RsqrdDispl=vertcat(sqrdDispl(k).RsqrdDispl,rSqrd);
               sqrdDispl(k).XsqrdDispl=vertcat(sqrdDispl(k).XsqrdDispl,xSqrd);
               sqrdDispl(k).YsqrdDispl=vertcat(sqrdDispl(k).YsqrdDispl,ySqrd);
            end
        end
        
    end
    
   analysisData.meanRsqrdSteps(k,1)=mean(sqrdDispl(k).RsqrdDispl)*pixelSize*pixelSize;
   analysisData.meanYsqrdSteps(k,1)=mean(sqrdDispl(k).YsqrdDispl)*pixelSize*pixelSize;
   analysisData.meanXsqrdSteps(k,1)=mean(sqrdDispl(k).XsqrdDispl)*pixelSize*pixelSize;
   
   analysisData.RdiffConstSteps(k,1)=analysisData.meanRsqrdSteps(k,1)/(2*dim*double(k)*timeLapse);
   analysisData.XdiffConstSteps(k,1)=analysisData.meanXsqrdSteps(k,1)/(2*dim*double(k)*timeLapse);
   analysisData.YdiffConstSteps(k,1)=analysisData.meanYsqrdSteps(k,1)/(2*dim*double(k)*timeLapse);
   
   sqrdDispl(k).RsqrdDispl=sort(sqrdDispl(k).RsqrdDispl);
   sqrdDispl(k).XsqrdDispl=sort(sqrdDispl(k).XsqrdDispl);
   sqrdDispl(k).YsqrdDispl=sort(sqrdDispl(k).YsqrdDispl);
   
   
  
   
   
   
   
   numDispl=numel(sqrdDispl(k).RsqrdDispl);
   %disp(sqrdDispl(k).RsqrdDispl);
   for i=1:numDispl
       analysisData.cpdRsqrd(k,1).displ(i,2)=1-(i/numDispl);
       analysisData.cpdRsqrd(k,1).displ(i,1)=sqrdDispl(k).RsqrdDispl(i)*pixelSize*pixelSize;
       analysisData.cpdXsqrd(k,1).displ(i,2)=1-(i/numDispl);
       analysisData.cpdXsqrd(k,1).displ(i,1)=sqrdDispl(k).XsqrdDispl(i)*pixelSize*pixelSize;
       analysisData.cpdYsqrd(k,1).displ(i,2)=1-(i/numDispl);
       analysisData.cpdYsqrd(k,1).displ(i,1)=sqrdDispl(k).YsqrdDispl(i)*pixelSize*pixelSize;
       if k==1 
       %disp(sqrdDispl(k).RsqrdDispl(i)*pixelSize*pixelSize);
       %disp(1-(i/numDispl));
       end
   end
   
   
end


indx=~isnan(analysisData.meanRsqrdSteps);
%indxX=~isnan(analysisData.meanXsqrdSteps);
%indxY=~isnan(analysisData.meanYsqrdSteps);

yR=analysisData.meanRsqrdSteps(~isnan(analysisData.meanRsqrdSteps));
yX=analysisData.meanXsqrdSteps(~isnan(analysisData.meanXsqrdSteps));
yY=analysisData.meanYsqrdSteps(~isnan(analysisData.meanYsqrdSteps));

num=length(yR);
%numX=length(yX);
%numY=length(yY);

x=timeLapse:timeLapse:num*timeLapse;
%xX=timeLapse:timeLapse:numX*timeLapse;
%xY=timeLapse:timeLapse:numY*timeLapse;

x=x';
xp=0:0.01:num*timeLapse;
%disp('x');
%disp(x);
%disp('y');
%disp(yR);

%[pcoeffR,sR]=polyfit(x,yR,1);
%[pcoeffX,sX]=polyfit(x,yX,1);
%[pcoeffY,sY]=polyfit(x,yY,1);


[brobR,statsR] = robustfit(x,yR,'ols');
[brobX,statsX] = robustfit(x,yX,'ols');
[brobY,statsY] = robustfit(x,yY,'ols');


pcoeffR=fliplr(brobR');
pcoeffX=fliplr(brobX');
pcoeffY=fliplr(brobY');

[ypR]=polyval(pcoeffR,xp);
[ypY]=polyval(pcoeffY,xp);
[ypX]=polyval(pcoeffX,xp);

analysisData.RdiffConst=pcoeffR(1)/(2*dim);
analysisData.XdiffConst=pcoeffX(1)/(2*dim);
analysisData.YdiffConst=pcoeffY(1)/(2*dim);

analysisData.sigmaR=pcoeffR(2);
analysisData.sigmaX=pcoeffX(2);
analysisData.sigmaY=pcoeffY(2);

analysisData.deltaRdiffConst=statsR.se(2);
analysisData.deltaXdiffConst=statsX.se(2);
analysisData.deltaYdiffConst=statsY.se(2);

analysisData.deltaSigmaR=statsR.se(1);
analysisData.deltaSigmaX=statsX.se(1);
analysisData.deltaSigmaY=statsY.se(1);


if msdDispFlag==1
   
    

    figure, plot(x,yR,'*',xp,ypR,'b',x,yX,'O',xp,ypX,'g',x,yY,'d',xp,ypY,'r')
    titHandle=title (['MSD curve combined of trajectories ' num2str(min(traj)) ' - ' num2str(max(traj))]);
    set(titHandle,'fontsize',16);
    xlabel('timeLapse (s)');
    ylabel(' MSD (um)');
    xlhand = get(gca,'xlabel');
    ylhand = get(gca,'ylabel');
    set(xlhand,'fontsize',16);
    set(ylhand,'fontsize',16);
end
% figure, plot(x,yX,'O',xp,ypX,'m')
% titHandle=title ('MSD curve X');
% set(titHandle,'fontsize',16);
% xlabel('timeLapse (s)');
% ylabel(' r^2(um)');
% xlhand = get(gca,'xlabel');
% ylhand = get(gca,'ylabel');
% set(gca,'XTick',0:0.1:0.2)
% set(xlhand,'fontsize',16);
% set(ylhand,'fontsize',16);
% 
% figure, plot(x,yR,'O',xp,ypR,'m')
% axis([0 0.2 0.01 1])
% titHandle=title ('MSD curve R');
% set(titHandle,'fontsize',16);
% xlabel('timeLapse (s)');
% ylabel(' r^2(um)');
% xlhand = get(gca,'xlabel');
% ylhand = get(gca,'ylabel');
% %set(gca,'XTick',0:0.1:0.2)
% set(xlhand,'fontsize',16);
% set(ylhand,'fontsize',16);






 

