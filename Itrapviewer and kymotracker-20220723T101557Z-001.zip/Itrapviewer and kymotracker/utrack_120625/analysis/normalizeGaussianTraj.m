function [ trajectories ] = normalizeGaussianTraj( trajectories )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

number=length(trajectories);
for i=1:number;
    for j=1:length(trajectories(i).intens)
        if trajectories(i).intens(j)>0
            
            a=exp(-((trajectories(i).x(j)-256)^2+(trajectories(i).y(j)-256)^2)/500^2);
            f=1/a;
        
            trajectories(i).intens(j)=trajectories(i).intens(j)*f;
            trajectories(i).int_gauss_2pi(j)=trajectories(i).int_gauss_2pi(j)*f;
        end
    end
end

end

