global expPath





%select number of the first and the last image to be processed 
imageNumStartEnd=[1 50];

%specify the minimal length of trajectories taken into account for
%analysis and display
trajFilterLength=8;

%%


%setpath;    % sets the path to location of images 
    
[roiRange]=selectRegionDNA; % selects the ROI for tracking and display - returns the ROI coordinates[ movieInfo,exceptions,localMaxima,background,psfSigma ]...
    

%detection and fitting of fluorescent particles 
%change here the detection parameters!!!
[ movieInfo,exceptions,localMaxima,background,psfSigma ]...
=detectGeneral_120522(imageNumStartEnd);    

%particle linking
%%%change here the tracking parameters
scriptTrackGeneral_120522;      


%filter for obtained trajectories
[tracksFinalFiltered]=filterTrajLengthPsfBgr(tracksFinal,trajFilterLength,[0 900],[0 900],[0],[900],[0 2000]);%filters for trajectories with certain properties
%parameters: 1. name of output-variable, 2. minimal trajectory length, 3. window for trajectory start, 4. window for trajectory end
%5. minimal meanRsquared(pixel), 6. maximalSegmentLength, 7. startCoordinate x 


%[trajectories_filtered_all]=getTraj_DNA(tracksFinalFiltered,[],[]);% transforms data structure in a more digestible form
[trajectories_filtered]=getTrajIntAmpPsfBgr_5(tracksFinalFiltered,[],[]);% transforms data structure in a more digestible form



overlayTracksMovie_auto_110522(tracksFinalFiltered,imageNumStartEnd,[],1,'cell_1_test.avi',[],[],1,0,[roiRange(1,1) roiRange(1,2); roiRange(2,1) roiRange(2,2)],0,[],[],2,1);
%%%output-variables
%tracksFinal,startend,dragtailLength,saveMovie,movieName,filterSigma,classifyGaps,highlightES,showRaw,imageRange,onlyTracks,classifyLft,diffAnalysisRes,intensityScale,...
%    colorTracks)

%links
links=[];
