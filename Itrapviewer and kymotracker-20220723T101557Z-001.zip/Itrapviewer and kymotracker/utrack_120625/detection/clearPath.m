% clears global variable for a selected path 
clear global expPath
