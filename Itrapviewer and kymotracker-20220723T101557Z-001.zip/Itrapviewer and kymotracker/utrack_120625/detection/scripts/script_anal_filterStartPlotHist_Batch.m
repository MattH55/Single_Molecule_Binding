script_anal_filterStartPlotHist('E:\DATA_11_05_23\fData\Felix\12_04_26\','260412','TatB');
script_anal_filterStartPlotHist('E:\DATA_11_05_23\fData\Felix\12_04_24\','240412','TatBSufiKK');
script_anal_filterStartPlotHist('E:\DATA_11_05_23\fData\Felix\12_04_20\','200412','TatBSufI');
script_anal_filterStartPlotHist('E:\DATA_11_05_23\fData\Felix\12_04_19\','190412','TatB');
script_anal_filterStartPlotHist('E:\DATA_11_05_23\fData\Felix\12_03_28\','280312','TatB');
script_anal_filterStartPlotHist('E:\DATA_11_05_23\fData\Felix\12_03_29\','290312','TatBSufI');
script_anal_filterStartPlotHist('E:\DATA_11_05_23\fData\Felix\12_04_27\','270412','TatBSufIKKnInd');
script_anal_filterStartPlotHist('E:\DATA_11_05_23\fData\Felix\12_05_04\','040512','TatBSufIwt');