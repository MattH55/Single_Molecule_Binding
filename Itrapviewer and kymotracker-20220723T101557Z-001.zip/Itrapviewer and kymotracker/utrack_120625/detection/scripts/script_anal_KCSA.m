




global expPath;

setpath;

movies=43:1:54;
%startNum=31;
%endNum=35;
savePlot=1;
%expName='trajectories_filtered_all_25deg_';
h=0;
trajectoriesCat=[];
trajectoriesCatAll=[];
cpd_binned=[];
cpd_all=[];
cd(expPath);
increment=4;
for k=1:length(movies)
    
    h=h+1;
    trajName=['trajectories_filtered_all_25deg_start20_' num2str(movies(k))];
    evalin('base',[ '[ current_trajectories ] = ' trajName ]);
    %disp(movies(k));
    trajectoriesCat=vertcat(trajectoriesCat,current_trajectories);
    
    %trajectoriesCatAll=vertcat(trajectoriesCatAll,current_trajectories);
    if h==increment
        h=0;
        disp(movies(k));
        numberFirst=num2str(movies(k)-increment+1);
        numberSecond=num2str(movies(k));
        [ cummCells_dummy,cpd_cat ]=analyzeCells_1( [],trajectoriesCat );
        
        assignin('base', [ 'trajectoriesCat_' numberFirst '_' numberSecond   ],  trajectoriesCat);
        assignin('base', [ 'cpd_cat_' numberFirst '_' numberSecond], cpd_cat);
        plotCummLLs([cpd_cat],[ 'cpd-cat-' numberFirst '-' numberSecond],1);
        
        cpd_binned=horzcat(cpd_binned ,cpd_cat);
        cpd_cat=[];
        trajectoriesCat=[];
    end
    if movies(k)==58
        h=0;
        
        numberFirst=num2str(movies(k)-increment+1);
        numberSecond=num2str(movies(k));
        [ cummCells_dummy,cpd_cat ]=analyzeCells_1( [],trajectoriesCat );
        
        assignin('base', [ 'trajectoriesCat_' numberFirst '_' numberSecond   ],  trajectoriesCat);
        assignin('base', [ 'cpd_cat_' numberFirst '_' numberSecond], cpd_cat);
        plotCummLLs([cpd_cat],[ 'cpd-cat-' numberFirst '-' numberSecond],1);
        
        cpd_binned=horzcat(cpd_binned ,cpd_cat);
        cpd_cat=[];
        trajectoriesCat=[];
    end
end
%[ cummCells_dummy,cpd_all ]=analyzeCells_1( [],trajectoriesCatAll );
incrementStr=num2str(increment);
plotCummLLs([cpd_binned],[ 'cpd-' incrementStr '-binned-test' ],1);   
%plotCummLLs([cpd_all],[ 'cpd-all' ],1);  
