


numberOfTrajArray=zeros(100,1);

numberOfTrajArray(1,1)=22;
numberOfTrajArray(2,1)=17;
numberOfTrajArray(3,1)=16;
numberOfTrajArray(4,1)=13;
numberOfTrajArray(5,1)=12;
numberOfTrajArray(6,1)=10;
numberOfTrajArray(10,1)=18;
movies=[1 2 3 4 5 6 10];
startNum=31;
endNum=35;
savePlot=1;
expName='120117_tatA_S_P13_';

for j=1:length(movies)

numberOfTraj=numberOfTrajArray(movies(j),1);    
movieName=[expName num2str(movies(j)) '_'];
trajName=['trajectories_filtered_all_25deg_' num2str(movies(j))];
cells=[];
linkLen=[];
traj_linked=[];
%traj_ranged=[];

for i=1:numberOfTraj
    if i==1
    evalin('base',[ '[ traj_linked ] = linkTraj(' trajName ',l_'  movieName num2str(i) ')' ])
    else
    evalin('base',[ '[ traj_linked ] = linkTraj(' 'traj_linked' ',l_'  movieName num2str(i) ')'])
    end
    disp('movienam');
    disp(movieName);
    disp('num2str(i)');
    disp(num2str(i));
    evalin('base',[ 'linkLen=length(l_' movieName num2str(i) '(:,1))'])
    evalin('base',['cells(1:linkLen,i)=l_' movieName num2str(i) '(:,1)']);
end

[ traj_dummy,traj_ranged,trajNum ] = rangeTraj_1_int( traj_linked,cells );
[ cummCells_dummy,cpd(1,j) ] = analyzeCells_1( [],traj_ranged );

[ cpd_single ] = getCumTraj( traj_ranged );
plotCummLLs(cpd_single,[ 'cpd_single' movieName],savePlot);
assignin('base', [ 'c' movieName ], cells);
assignin('base', [ 'cpd_s' movieName], cpd(1,j));
assignin('base', [ 'trj_l' movieName], traj_linked);
assignin('base', [ 'trj_r' movieName], traj_ranged);
assignin('base', [ 'cpd_single' movieName], cpd(1,j));
assignin('base', [ 'trj_num' movieName], trajNum);
if j==1
    traj_conc=traj_ranged;
    else
    traj_conc=vertcat(traj_conc,traj_ranged);
end


end
[ cpd_single_all ] = getCumTraj( traj_conc );
[ cummCells_dummy,cpd_conc ] = analyzeCells_1( [],traj_conc );
assignin('base', [ 'cpd_conc' expName num2str(movies(1)) '__' num2str(movies(length(movies)))], cpd_conc);
assignin('base', [ 'cpd_single' expName num2str(movies(1)) '__' num2str(movies(length(movies)))], cpd(1,j));
assignin('base', [ 'trj_c' expName num2str(movies(1)) '__' num2str(movies(length(movies)))], traj_conc);
assignin('base', [ 'cpd_single_movies' expName num2str(movies(1)) '__' num2str(movies(length(movies)))], cpd);
assignin('base', [ 'cpd_single_all' expName num2str(movies(1)) '__' num2str(movies(length(movies)))], cpd_single_all);

plotCummLLs([cpd],[ 'cpd_single_movies' expName num2str(movies(1)) '__' num2str(movies(length(movies)))],savePlot);
plotCummLLs([cpd_conc],[ 'cpd_conc' expName num2str(movies(1)) '__' num2str(movies(length(movies)))],savePlot);
plotCummLLs([cpd_single_all],[ 'cpd_single_all' expName num2str(movies(1)) '__' num2str(movies(length(movies)))],savePlot);

clear('numberOfTrajArray','startNum','endNum','expName','numberOfTraj','movieName','trajName','linkLen','i','j');
clear('traj_linked','traj_ranged','traj_conc','traj_dummy','trajNum','cummCells_dummy','cpd','cpd_single','cpd_conc','cpd_single_all' );

