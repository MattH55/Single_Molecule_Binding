global expPath


filenameBase='E:\DATA_11_05_23\fData\Felix\12_04_19\KCSA_';
mkdir([filenameBase '\workspace\']);




startNum=1;
endNum=52;




    
    


for j=startNum:endNum
    
    try
    i=j-1;
        
    cd([filenameBase num2str(i)]);
    dirData = dir('*.tif');         %# Get the selected file data
       fileNames = {dirData.name};     %# Create a cell array of file names
    for iFile = 1:numel(fileNames)  %# Loop over the file names
    newName = sprintf('img_%04d.tif',iFile);  %# Make the new name
    try
    movefile(fileNames{iFile},newName);        %# Rename the file
    catch
    end
    end
        
    
    expPath=[filenameBase num2str(i) '\'];
    cd(expPath);
    %load('workspace.mat');
    cellFilterOverlay_04(0)
    scriptDetectGeneralPsfMask300new
    scriptTrackGeneralModPsfBgrInt
    
    
    trajName=['trajectories_filtered_all_25deg_' num2str(i)];
    cummdistrName=['cummDistrMovie_all_' num2str(i)];
    trajName_start20=['trajectories_filtered_all_25deg_start20_' num2str(i)];
    cummdistrName_start20=['cummDistrMovie_all_start20_' num2str(i)];
    
    
    [tracksFinalFiltered]=filterTrajLengthPsfBgr(tracksFinal,6,[0 300],[0 300],[0],[500],[0 512]);
    [trajectories_filtered_all]=getTrajIntAmpPsfBgr_4(tracksFinalFiltered,[],[]);
    [ cummDistrCells_all ,cummDistrMovie_all ] = analyzeCells([] ,trajectories_filtered_all );
    
    [tracksFinalFiltered_start20]=filterTrajLengthPsfBgr(tracksFinal,6,[20 300],[0 300],[0],[500],[0 512]);
    [trajectories_filtered_all_start20]=getTrajIntAmpPsfBgr_4(tracksFinalFiltered_start20,[],[]);
    [ cummDistrCells_all_start20 ,cummDistrMovie_all_start20 ] = analyzeCells([] ,trajectories_filtered_all_start20 );
    
    
    
    assignin('base', trajName_start20, trajectories_filtered_all_start20);
    assignin('base', cummdistrName_start20, cummDistrMovie_all_start20);
    assignin('base', trajName, trajectories_filtered_all);
    assignin('base', cummdistrName, cummDistrMovie_all);
    
    
    
    
    
    cells=[];
    cd(expPath);
    save('workspace.mat');
    cd([filenameBase '\workspace\']);
    save(['workspace_' num2str(i) '.mat']);
    
    
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 30],[],1,'cell_1.mov',[],[],1,0,[1 200; 1 200],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_2.mov',[],[],1,0,[1 200; 156 356],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_3.mov',[],[],1,0,[1 200; 312 512],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_4.mov',[],[],1,0,[156 356; 1 200],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_5.mov',[],[],1,0,[156 356; 156 356],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_6.mov',[],[],1,0,[156 356; 312 512],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_7.mov',[],[],1,0,[312 512; 1 200],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_8.mov',[],[],1,0,[312 512; 156 356],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1
    %500],[],1,'cell_9.mov',[],[],1,0,[312 512; 312 512],0,[],[],2,1);
    %save('tracksFinalFiltered','-mat');
    %save('trajectories','-mat');
    %save('cells','-mat');
    clear(trajName_start20,trajName,cummdistrName_start20,cummdistrName);
    catch
    %disp(['error    ' expPath]);      
    end
end






filenameBase='E:\DATA_11_05_23\fData\Felix\12_04_19\TatB_';


startNum=20;
endNum=52;

for j=startNum:endNum
    
    try
    i=j-1;
    expPath=[filenameBase num2str(i) '\'];
    disp([filenameBase num2str(i) '\']);
    cd(expPath);
    load(['workspace.mat'],'tracksFinalFiltered');
        
    
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_1.mov',[],[],1,0,[1 200; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_2.mov',[],[],1,0,[1 200; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_3.mov',[],[],1,0,[1 200; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_4.mov',[],[],1,0,[156 356; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_5.mov',[],[],1,0,[156 356; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_6.mov',[],[],1,0,[156 356; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_7.mov',[],[],1,0,[312 512; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_8.mov',[],[],1,0,[312 512; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_9.mov',[],[],1,0,[312 512; 312 512],0,[],[],2,1);
    catch
          
    end
end

filenameBase='E:\DATA_11_05_23\fData\Felix\12_04_19\TatBshort_';
cd([filenameBase '\workspace\']);

startNum=1;
endNum=52;

for j=startNum:endNum
    
    try
    i=j-1;
    expPath=[filenameBase num2str(i) '\'];
    disp([filenameBase num2str(i) '\']);
    cd(expPath);
    load(['workspace.mat'],'tracksFinalFiltered');
        
    
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_1.mov',[],[],1,0,[1 200; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_2.mov',[],[],1,0,[1 200; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_3.mov',[],[],1,0,[1 200; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_4.mov',[],[],1,0,[156 356; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_5.mov',[],[],1,0,[156 356; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_6.mov',[],[],1,0,[156 356; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_7.mov',[],[],1,0,[312 512; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_8.mov',[],[],1,0,[312 512; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_9.mov',[],[],1,0,[312 512; 312 512],0,[],[],2,1);
    catch
          
    end
end

filenameBase='E:\DATA_11_05_23\fData\Felix\12_04_19\TatBshort_';
cd([filenameBase '\workspace\']);

startNum=1;
endNum=52;

for j=startNum:endNum
    
    try
    i=j-1;
    expPath=[filenameBase num2str(i) '\'];
    disp([filenameBase num2str(i) '\']);
    cd(expPath);
    load(['workspace.mat'],'tracksFinalFiltered');
        
    
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_1.mov',[],[],1,0,[1 200; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_2.mov',[],[],1,0,[1 200; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_3.mov',[],[],1,0,[1 200; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_4.mov',[],[],1,0,[156 356; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_5.mov',[],[],1,0,[156 356; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_6.mov',[],[],1,0,[156 356; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_7.mov',[],[],1,0,[312 512; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_8.mov',[],[],1,0,[312 512; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_9.mov',[],[],1,0,[312 512; 312 512],0,[],[],2,1);
    catch
          
    end
end

filenameBase='E:\DATA_11_05_23\fData\Felix\12_04_19\KCSA_';
cd([filenameBase '\workspace\']);

startNum=1;
endNum=20;

for j=startNum:endNum
    
    try
    i=j-1;
    expPath=[filenameBase num2str(i) '\'];
    disp([filenameBase num2str(i) '\']);
    cd(expPath);
    load(['workspace.mat'],'tracksFinalFiltered');
        
    
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_1.mov',[],[],1,0,[1 200; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_2.mov',[],[],1,0,[1 200; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_3.mov',[],[],1,0,[1 200; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_4.mov',[],[],1,0,[156 356; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_5.mov',[],[],1,0,[156 356; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_6.mov',[],[],1,0,[156 356; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_7.mov',[],[],1,0,[312 512; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_8.mov',[],[],1,0,[312 512; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_9.mov',[],[],1,0,[312 512; 312 512],0,[],[],2,1);
    catch
          
    end
end

filenameBase='E:\DATA_11_05_23\fData\Felix\12_04_20\KCSA_';
cd([filenameBase '\workspace\']);

startNum=1;
endNum=20;

for j=startNum:endNum
    
    try
    i=j-1;
    expPath=[filenameBase num2str(i) '\'];
    disp([filenameBase num2str(i) '\']);
    cd(expPath);
    load(['workspace.mat'],'tracksFinalFiltered');
        
    
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_1.mov',[],[],1,0,[1 200; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_2.mov',[],[],1,0,[1 200; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_3.mov',[],[],1,0,[1 200; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_4.mov',[],[],1,0,[156 356; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_5.mov',[],[],1,0,[156 356; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_6.mov',[],[],1,0,[156 356; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_7.mov',[],[],1,0,[312 512; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_8.mov',[],[],1,0,[312 512; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_9.mov',[],[],1,0,[312 512; 312 512],0,[],[],2,1);
    catch
          
    end
end


filenameBase='E:\DATA_11_05_23\fData\Felix\12_04_20\TatBSufI_';
cd([filenameBase '\workspace\']);

startNum=1;
endNum=63;

for j=startNum:endNum
    
    try
    i=j-1;
    expPath=[filenameBase num2str(i) '\'];
    disp([filenameBase num2str(i) '\']);
    cd(expPath);
    load(['workspace.mat'],'tracksFinalFiltered');
        
    
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_1.mov',[],[],1,0,[1 200; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_2.mov',[],[],1,0,[1 200; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_3.mov',[],[],1,0,[1 200; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_4.mov',[],[],1,0,[156 356; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_5.mov',[],[],1,0,[156 356; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_6.mov',[],[],1,0,[156 356; 312 512],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_7.mov',[],[],1,0,[312 512; 1 200],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_8.mov',[],[],1,0,[312 512; 156 356],0,[],[],2,1);
    overlayTracksMoviePsfBgr_auto_new(tracksFinalFiltered,[1 300],[],1,'cell_9.mov',[],[],1,0,[312 512; 312 512],0,[],[],2,1);
    catch
          
    end
end
