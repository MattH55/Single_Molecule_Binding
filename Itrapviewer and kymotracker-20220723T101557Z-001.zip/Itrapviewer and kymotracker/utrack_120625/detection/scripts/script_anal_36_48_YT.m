


numberOfTrajArray=zeros(100,1);
numberOfTrajArray(48,1)=5;
numberOfTrajArray(47,1)=3;
numberOfTrajArray(45,1)=7;
numberOfTrajArray(44,1)=2;
numberOfTrajArray(43,1)=6;
numberOfTrajArray(42,1)=1;
numberOfTrajArray(41,1)=2;
numberOfTrajArray(40,1)=4;
numberOfTrajArray(39,1)=7;
numberOfTrajArray(38,1)=6;
numberOfTrajArray(37,1)=7;
numberOfTrajArray(36,1)=4;
movies=[36 37 38 39 40 43 44 45 47 48];
startNum=31;
endNum=35;
savePlot=1;
expName='_111208_tatA25degYT_';

for j=1:length(movies)

numberOfTraj=numberOfTrajArray(movies(j),1);    
movieName=[expName num2str(movies(j)) '_'];
trajName=['trajectories_filtered_all_25deg_' num2str(movies(j))];
cells=[];
linkLen=[];
traj_linked=[];
%traj_ranged=[];

for i=1:numberOfTraj
    if i==1
    evalin('base',[ '[ traj_linked ] = linkTraj(' trajName ',l'  movieName num2str(i) ')' ])
    else
    evalin('base',[ '[ traj_linked ] = linkTraj(' 'traj_linked' ',l'  movieName num2str(i) ')'])
    end
    evalin('base',[ 'linkLen=length(l' movieName num2str(i) '(:,1))'])
    evalin('base',['cells(1:linkLen,i)=l' movieName num2str(i) '(:,1)']);
end

[ traj_dummy,traj_ranged,trajNum ] = rangeTraj_1_int( traj_linked,cells );
[ cummCells_dummy,cpd(1,j) ] = analyzeCells_1( [],traj_ranged );

[ cpd_single ] = getCumTraj( traj_ranged );
plotCummLLs(cpd_single,[ 'cpd_single' movieName],savePlot);
assignin('base', [ 'c' movieName ], cells);
assignin('base', [ 'cpd_s' movieName], cpd(1,j));
assignin('base', [ 'trj_l' movieName], traj_linked);
assignin('base', [ 'trj_r' movieName], traj_ranged);
assignin('base', [ 'cpd_single' movieName], cpd(1,j));
assignin('base', [ 'trj_num' movieName], trajNum);
if j==1
    traj_conc=traj_ranged;
    else
    traj_conc=vertcat(traj_conc,traj_ranged);
end


end
[ cpd_single_all ] = getCumTraj( traj_conc );
[ cummCells_dummy,cpd_conc ] = analyzeCells_1( [],traj_conc );
assignin('base', [ 'cpd_conc' expName num2str(movies(1)) '__' num2str(movies(length(movies)))], cpd_conc);
assignin('base', [ 'cpd_single' expName num2str(movies(1)) '__' num2str(movies(length(movies)))], cpd(1,j));
assignin('base', [ 'trj_c' expName num2str(movies(1)) '__' num2str(movies(length(movies)))], traj_conc);
assignin('base', [ 'cpd_single_movies' expName num2str(movies(1)) '__' num2str(movies(length(movies)))], cpd);
assignin('base', [ 'cpd_single_all' expName num2str(movies(1)) '__' num2str(movies(length(movies)))], cpd_single_all);

plotCummLLs([cpd],[ 'cpd_single_movies' expName num2str(movies(1)) '__' num2str(movies(length(movies)))],savePlot);
plotCummLLs([cpd_conc],[ 'cpd_conc' expName num2str(movies(1)) '__' num2str(movies(length(movies)))],savePlot);
plotCummLLs([cpd_single_all],[ 'cpd_single_all' expName num2str(movies(1)) '__' num2str(movies(length(movies)))],savePlot);

clear('numberOfTrajArray','startNum','endNum','expName','numberOfTraj','movieName','trajName','linkLen','i','j');
clear('traj_linked','traj_ranged','traj_conc','traj_dummy','trajNum','cummCells_dummy','cpd','cpd_single','cpd_conc','cpd_single_all' );

