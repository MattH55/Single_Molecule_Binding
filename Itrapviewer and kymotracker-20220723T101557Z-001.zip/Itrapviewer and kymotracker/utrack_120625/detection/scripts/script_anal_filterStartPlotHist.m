

function [ output_args ] = script_anal_filterStartPlotHist( filenameBase,date,indicator2  )
    
global expPath

x=0:400:20000;
indicator1='KCSA';

if nargin<3
indicator2='TatB';
date='260412';
filenameBase='E:\DATA_11_05_23\fData\Felix\12_04_26\';
end




startNum=2;
endNum=41;


cpds_all=[];
traj_f_all=[];
traj_f_5conc=[];
cpds_conc5_all=[];

cpds_st20_all=[];
traj_f_st20_all=[];
traj_f_st20_5conc=[];
cpds_conc5_st20_all=[];

cpds_n5_dummy=[];
cpds_n5_st20_dummy=[];
%traj_0_10_ff_all=[];
    %traj_0_15_ff_all=[];
    %traj_5_15_ff_all=[];
    traj_5_20_ff_all=[];
    %traj_10_20_ff_all=[];
    %traj_10_25_ff_all=[];
    
    %hist_0_10_ff_all=[];
    %hist_0_15_ff_all=[];
   % hist_5_15_ff_all=[];
    hist_5_20_ff_all=[];
    %hist_10_20_ff_all=[];
    %hist_10_25_ff_all=[];

    
k=0;
list=[];


for l=1:2;
    %try
    if l==2
        
    path=[filenameBase indicator1 '_' '\workspace'];
    
    disp(path);
    cd(path );
    else
        
     path=[filenameBase indicator2 '_' '\workspace'];
     disp(path);
    cd(path );
    end

for j=startNum:endNum
    
    try
    
    i=j-1;
    
    
    load(['workspace_' num2str(i) '.mat'],'tracksFinal');
    
    
    %[tFF_0_10]=filterTrajLengthPsfBgr(tracksFinal,6,[0 10],[0 300],[0],[500],[0 512]);
    %[tFF_0_15]=filterTrajLengthPsfBgr(tracksFinal,6,[0 15],[0 300],[0],[500],[0 512]);
    %[tFF_5_15]=filterTrajLengthPsfBgr(tracksFinal,6,[5 15],[0 300],[0],[500],[0 512]);
    [tFF_5_20]=filterTrajLengthPsfBgr(tracksFinal,6,[100 120],[0 300],[0],[500],[0 512]);
    %[tFF_10_20]=filterTrajLengthPsfBgr(tracksFinal,6,[10 20],[0 300],[0],[500],[0 512]);
    %[tFF_10_25]=filterTrajLengthPsfBgr(tracksFinal,6,[10 25],[0 300],[0],[500],[0 512]);
    
    %[traj_0_10_ff]=getTrajIntAmpPsfBgr_4(tFF_0_10,[],[]);
    %[traj_0_15_ff]=getTrajIntAmpPsfBgr_4(tFF_0_15,[],[]);
    %[traj_5_15_ff]=getTrajIntAmpPsfBgr_4(tFF_5_15,[],[]);
    [traj_5_20_ff]=getTrajIntAmpPsfBgr_4(tFF_5_20,[],[]);
    %[traj_10_20_ff]=getTrajIntAmpPsfBgr_4(tFF_10_20,[],[]);
    %[traj_10_25_ff]=getTrajIntAmpPsfBgr_4(tFF_10_25,[],[]);
    
    %[ cummDistrCells_all ,cpd__0_10_ff ] = analyzeCells_1([] ,traj_0_10_ff );
    %[ cummDistrCells_all ,cpd__0_15_ff ] = analyzeCells_1([] ,traj_0_15_ff );
    %[ cummDistrCells_all ,cpd__5_15_ff ] = analyzeCells_1([] ,traj_5_15_ff );
    %[ cummDistrCells_all ,cpd__5_20_ff ] = analyzeCells_1([] ,traj_5_20_ff );
    %[ cummDistrCells_all ,cpd__10_20_ff ] = analyzeCells_1([] ,traj_10_20_ff );
    %[ cummDistrCells_all ,cpd__10_15_ff ] = analyzeCells_1([] ,traj_10_25_ff );
    
    
    %if isempty(cpd__0_10_ff.twoStep)
    %else
        
        
    %cpds_0_10_ff_all=horzcat(cpds_0_10_ff_all,cpd__0_10_ff);
    
    %cpds_n5_dummy=horzcat(cpds_n5_dummy,cummDistrMovie_all);
   
        
    %cpds_n5_st20_dummy=horzcat(cpds_n5_st20_dummy,cummDistrMovie_all_start20);
    %if i==startNum-1
    %disp(traj_0_10_ff);
    %[ cummDistrCells_all ,cpd__0_10_ff ] = analyzeCells_1([] ,traj_0_10_ff );
    %[ cummDistrCells_all ,cpd__0_15_ff ] = analyzeCells_1([] ,traj_0_15_ff );
    %[ cummDistrCells_all ,cpd__5_15_ff ] = analyzeCells_1([] ,traj_5_15_ff );
    [ cummDistrCells_all ,cpd__5_20_ff ] = analyzeCells_1([] ,traj_5_20_ff );
    %[ cummDistrCells_all ,cpd__10_20_ff ] = analyzeCells_1([] ,traj_10_20_ff );
    %[ cummDistrCells_all ,cpd__10_25_ff ] = analyzeCells_1([],traj_10_25_ff );
    
    
    %traj_f_all=vertcat(traj_f_all,trajectories_filtered_all);
    %traj_0_10_ff_all=vertcat(traj_0_10_ff_all,traj_0_10_ff);
    %traj_0_15_ff_all=vertcat(traj_0_15_ff_all,traj_0_15_ff);
    %traj_5_15_ff_all=vertcat(traj_5_15_ff_all,traj_5_15_ff);
    traj_5_20_ff_all=vertcat(traj_5_20_ff_all,traj_5_20_ff);
    %traj_10_20_ff_all=vertcat(traj_10_20_ff_all,traj_10_20_ff);
    %traj_10_25_ff_all=vertcat(traj_10_25_ff_all,traj_10_25_ff);
    
    %hist_0_10_ff_all=vertcat(hist_0_10_ff_all,cpd__0_10_ff.mean5IntDistr_gauss(:,1));
    %hist_0_15_ff_all=vertcat(hist_0_15_ff_all,cpd__0_15_ff.mean5IntDistr_gauss(:,1));
    %hist_5_15_ff_all=vertcat(hist_5_15_ff_all,cpd__5_15_ff.mean5IntDistr_gauss(:,1));
    hist_5_20_ff_all=vertcat(hist_5_20_ff_all,cpd__5_20_ff.mean5IntDistr_gauss(:,1));
    %hist_10_20_ff_all=vertcat(hist_10_20_ff_all,cpd__10_20_ff.mean5IntDistr_gauss(:,1));
    %hist_10_25_ff_all=vertcat(hist_10_25_ff_all,cpd__10_25_ff.mean5IntDistr_gauss(:,1));
    %traj_f_5conc=vertcat(traj_f_5conc,trajectories_filtered_all);
    
    %cpds_st20_all=horzcat(cpds_st20_all,cummDistrMovie_all_start20);
    %traj_f_st20_all=vertcat(traj_f_st20_all,trajectories_filtered_all_start20);
    %traj_f_st20_5conc=vertcat(traj_f_st20_5conc,trajectories_filtered_all_start20);
    
    k=k+1;
    list(k)=i;
    
    %if k==5 || j==endNum
     %   disp(list);
    %    disp('num2str(length(cpds_n5_dummy))');
     %   disp(num2str(length(cpds_n5_dummy)));
     %   assignin('base', ['cpds_'  indicator '_' num2str(list(1)) '_' num2str(list(k))],  cpds_n5_dummy);
    %    assignin('base', ['cpds_st20_'  indicator '_' num2str(list(1)) '_' num2str(list(k))],  cpds_n5_st20_dummy);
        
    %    [ dummy ,cpd_dummy ] = analyzeCells_1([] ,traj_f_5conc );
    %    [ dummy ,cpd_st20_dummy ] = analyzeCells_1([] ,traj_f_st20_5conc );
    %    assignin('base', ['cpd_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], cpd_dummy);
    %    assignin('base', ['cpd_st20_' indicator '_' num2str(list(1)) '_' num2str(list(k))], cpd_st20_dummy);
        
        %cpds_conc5_all=horzcat(cpds_conc5_all,cpd_dummy);
        %cpds_conc5_st20_all=horzcat(cpds_conc5_st20_all,cpd_st20_dummy);
         
        %assignin('base', ['traj_f_' indicator '_' num2str(list(1)) '_' num2str(list(k))], traj_f_5conc);
        %assignin('base', ['traj_f_st20_' num2str(list(1)) '_' num2str(list(k))], traj_f_st20_5conc);
        
        %cpds_n5_dummy=[];
        %cpds_n5_st20_dummy=[];
        %traj_f_st20_5conc=[];
        %traj_f_5conc=[];
        %list=[];
        %k=0;
    %end
    %end
    catch
        
       disp([path 'workspace_' num2str(i) '.mat']);
       disp(['failed']);
    
    end
    
end


    
if l==1
    
    %figure
    %hist(hist_5_20_ff_all,x);
    %title([indicator1 date],'FontWeight','bold');
    hist_KCSA=hist_5_20_ff_all;
    bar_5_20_ff_all_KCSA=hist(hist_5_20_ff_all,x);
    
    bar_5_20_ff_all_KCSAnorm=bar_5_20_ff_all_KCSA/max(bar_5_20_ff_all_KCSA);
    
    %figure;
    %bar(x,bar_5_20_ff_all_KCSA);
    %title([indicator1 date],'FontWeight','bold');
    assignin('base', ['hist_5_20_ff_'  indicator1 date '_' num2str(list(1)) '_' num2str(list(k))], hist_5_20_ff_all);
    assignin('base', ['bar_5_20_ff_all_norm_'  indicator1 date '_' num2str(list(1)) '_' num2str(list(k))], bar_5_20_ff_all_KCSAnorm');
    assignin('base', ['bar_5_20_ff_all_'  indicator1 date '_' num2str(list(1)) '_' num2str(list(k))], bar_5_20_ff_all_KCSA');
else
    assignin('base', ['hist_5_20_ff_'  indicator2 date '_' num2str(list(1)) '_' num2str(list(k))], hist_5_20_ff_all);
    %figure
    %hist(hist_5_20_ff_all,x);
    bar_5_20_ff_all_TatB=hist(hist_5_20_ff_all,x);
    
    %title([indicator2 date],'FontWeight','bold');
    hist_TatB=hist_5_20_ff_all;
    
    bar_5_20_ff_all_TatBnorm=bar_5_20_ff_all_TatB/max(bar_5_20_ff_all_TatB);
    
    %figure;
    %bar(x,bar_5_20_ff_all_TatB);
    %title([indicator2 date],'FontWeight','bold');
    assignin('base', ['hist_5_20_ff_'  indicator2 date '_' num2str(list(1)) '_' num2str(list(k))], hist_5_20_ff_all);
    assignin('base', ['bar_5_20_ff_all_norm_'  indicator2 date '_' num2str(list(1)) '_' num2str(list(k))], bar_5_20_ff_all_KCSAnorm');
    assignin('base', ['bar_5_20_ff_all_'  indicator2 date '_' num2str(list(1)) '_' num2str(list(k))], bar_5_20_ff_all_KCSA');

end

    %catch
        
    %end

end

try
figure;
h=bar(x,[bar_5_20_ff_all_TatB' bar_5_20_ff_all_KCSA' ]);
%h=get(gca);
set(h(1),'BarWidth',1.8,'FaceColor','b','LineWidth',1,'LineStyle','-','EdgeColor','k');
set(h(2),'BarWidth',1.8,'FaceColor','g','LineWidth',1,'LineStyle','-','EdgeColor','k');
%set(h(1),'FaceColor','r');
axis([0  5000 0 max(bar_5_20_ff_all_TatB)])
titHandle=title (date);
set(titHandle,'fontsize',16);
xlabel('Intensity (a.u.)');
ylabel('Counts');
xlhand = get(gca,'xlabel');
ylhand = get(gca,'ylabel');
%set(gca,'XTick',0:400:5000)

set(xlhand,'fontsize',16);
set(ylhand,'fontsize',16);
saveas(gcf,'intHistComb');

catch
    h=bar(x,[bar_5_20_ff_all_TatB' ]);
    %h=get(gca);
    set(h,'BarWidth',1.8,'FaceColor','b','LineWidth',1,'LineStyle','-','EdgeColor','k');
    %set(h(2),'BarWidth',1.8,'FaceColor','g','LineWidth',1,'LineStyle','-','EdgeColor','k');
    %set(h(1),'FaceColor','r');
    axis([0  5000 0 max(bar_5_20_ff_all_TatB)])
    titHandle=title (date);
    set(titHandle,'fontsize',16);
    xlabel('Intensity (a.u.)');
    ylabel('Counts');
    xlhand = get(gca,'xlabel');
    ylhand = get(gca,'ylabel');
    %set(gca,'XTick',0:400:5000)

    set(xlhand,'fontsize',16);
    set(ylhand,'fontsize',16);
    saveas(gcf,'intHistComb'); 
end
try
figure;
h=bar(x,[bar_5_20_ff_all_TatBnorm' bar_5_20_ff_all_KCSAnorm' ]);

set(h(1),'BarWidth',1.8,'FaceColor','b','LineWidth',1,'LineStyle','-','EdgeColor','k');
set(h(2),'BarWidth',1.8,'FaceColor','g','LineWidth',1,'LineStyle','-','EdgeColor','k');
%set(h(1),'FaceColor','r');
axis([0  5000 0 1])
titHandle=title ([date ' normalized']);
set(titHandle,'fontsize',16);
xlabel('Intensity (a.u.)');
ylabel('Norm. Counts');
xlhand = get(gca,'xlabel');
ylhand = get(gca,'ylabel');
%set(gca,'XTick',0:400:5000)

set(xlhand,'fontsize',16);
set(ylhand,'fontsize',16);
saveas(gcf,'intHistCombNorm');

save(['hist_bar' date]);
catch
h=bar(x,[bar_5_20_ff_all_TatBnorm'  ]);

set(h,'BarWidth',1.8,'FaceColor','b','LineWidth',1,'LineStyle','-','EdgeColor','k');
%set(h(2),'BarWidth',1.8,'FaceColor','g','LineWidth',1,'LineStyle','-','EdgeColor','k');
%set(h(1),'FaceColor','r');
axis([0  5000 0 1])
titHandle=title ([date ' normalized']);
set(titHandle,'fontsize',16);
xlabel('Intensity (a.u.)');
ylabel('Norm. Counts');
xlhand = get(gca,'xlabel');
ylhand = get(gca,'ylabel');
%set(gca,'XTick',0:400:5000)

set(xlhand,'fontsize',16);
set(ylhand,'fontsize',16);
saveas(gcf,'intHistCombNorm');

save(['hist_bar' date]);
end
%assignin('base', ['cpds_' indicator '_all'],  cpds_all);
%assignin('base', ['cpds_st20_' indicator '_all'],  cpds_st20_all);


%assignin('base', ['cpds_conc5_' indicator '_all'],  cpds_conc5_all);
%assignin('base', ['cpds_conc5_st20_' indicator '_all'],  cpds_conc5_st20_all);%

%assignin('base', ['traj_f_all_' indicator '_' ], traj_f_all);

%plotCummLLs(cpds_all,['cpds-' indicator '-all'],1);
%plotCummLLs(cpds_conc5_all,['cpds-conc5-' indicator '-all'],1)

%plotCummLLs(cpds_st20_all,['cpds-st20-' indicator '-all'],1);
%plotCummLLs(cpds_conc5_st20_all,['cpds-conc5-st20-' indicator '-all'],1);

%yesAll=1;
%if yesAll==1

%[ cummDistrCells_all ,cpd__0_10_ff_all ] = analyzeCells_1([] ,traj_0_10_ff_all );
%[ cummDistrCells_all ,cpd__0_15_ff_all ] = analyzeCells_1([] ,traj_0_15_ff_all );
%[ cummDistrCells_all ,cpd__5_15_ff_all ] = analyzeCells_1([] ,traj_5_15_ff_all );
%[ cummDistrCells_all ,cpd__5_20_ff_all ] = analyzeCells_1([] ,traj_5_20_ff_all );
%[ cummDistrCells_all ,cpd__10_20_ff_all ] = analyzeCells_1([] ,traj_10_20_ff_all );
%[ cummDistrCells_all ,cpd__10_25_ff_all ] = analyzeCells_1([],traj_10_25_ff_all );

%assignin('base', ['hist_0_10_ff_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], hist_0_10_ff_all);
%assignin('base', ['hist_0_15_ff_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], hist_0_15_ff_all);
%assignin('base', ['hist_5_15_ff_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], hist_5_15_ff_all);
%assignin('base', ['hist_5_20_ff_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], hist_5_20_ff_all);
%assignin('base', ['hist_10_20_ff_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], hist_10_20_ff_all);
%assignin('base', ['hist_10_25_ff_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], hist_10_25_ff_all);

%figure;
%hist(cpd__0_10_ff_all.mean5IntDistr_gauss(:,1),x);
%figure;
%hist(cpd__0_15_ff_all.mean5IntDistr_gauss(:,1),x);
%figure
%hist(hist_5_15_ff_all,x);
%figure
%hist(hist_5_20_ff_all,x);
%figure
%hist(hist_10_20_ff_all,x);
%figure
%hist(hist_10_25_ff_all,x);


    
%plotCummLLs(cummDistrMovie_all,['cpds-concall-' indicator],1);
%assignin('base', ['cpds_concAll' indicator],  cummDistrMovie_all);

%end
%save(['ws_full_' indicator '.mat']);