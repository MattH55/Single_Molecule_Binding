


    
global expPath















filenameBase='E:\DATA_11_05_23\fData\Felix\12_03_28\TatB_\workspace\';
indicator='SufI';

startNum=1;
endNum=50;
cummDistrall=[];
trajectories_filt_all=[];
trajectories_filt_5iter=[];
cummDistrMovie_iter5=[];

cummDistrallStart20=[];
trajectories_filt_allStart20=[];
trajectories_filt_5iterStart20=[];
cummDistrMovie_iter5start20=[];



    
k=1;

cd(filenameBase);
disp('filenamebase');
for j=startNum:endNum
    
    try
    i=j-1;
    k=k+1;
    %expPath=[filenameBase];
    disp(num2str(i));
   
    %open(['workspace_' num2str(i) '.mat']);
    load(['workspace_' num2str(i) '.mat'],'cummDistrMovie_all','trajectories_filtered_all');
    cummDistrall=horzcat(cummDistrall,cummDistrMovie_all);
    trajectories_filt_all=vertcat(trajectories_filt_all,trajectories_filtered_all);
    trajectories_filt_5iter=vertcat(trajectories_filt_5iter,trajectories_filtered_all);
    
    cummDistrallStart20=horzcat(cummDistrall,cummDistrMovie_all_start20);
    trajectories_filt_allStart20=vertcat(trajectories_filt_allStart20,trajectories_filtered_all_start20);
    trajectories_filt_5iterStart20=vertcat(trajectories_filt_5iterStart20,trajectories_filtered_all_start20);
    
    
    if k==5
        
        
        [ cummDistrCells ,cummDistrMovieDummy ] = analyzeCells([] ,trajectories_filt_5iter );
        cummDistrMovie_iter5=horzcat(cummDistrMovie_iter5,cummDistrMovieDummy);
        trajectories_filt_5iter=[];
        k=0;
        [ cummDistrCells ,cummDistrMovieDummy ] = analyzeCells([] ,trajectories_filt_5iterStart20 );
        cummDistrMovie_iter5Start20=horzcat(cummDistrMovie_iter5Start20,cummDistrMovieDummy);
        trajectories_filt_5iterStart20=[];
        %k=0;
    end
        
    end  
    
end

plotCummLLs(cummDistrall,'nnn',0);
plotCummLLs(cummDistrMovie_iter5,'5iterationStart20',0);
plotCummLLs(cummDistrallStart20,'nnn',0);
plotCummLLs(cummDistrMovie_iter5Start20,'5iterationStart20',0);
[ cummDistrCells_all_ ,cummDistrMovie_all ] = analyzeCells([] ,trajectories_filt_all );
%plotCummLLs(cummDistrMovie_all);


