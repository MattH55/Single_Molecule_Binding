


    
global expPath















filenameBase='E:\DATA_11_05_23\fData\Felix\12_03_29\TatBSufI_\workspace\';
indicator='SufI';

startNum=1;
endNum=64;
cummDistrall=[];
trajectories_filt_all=[];
trajectories_filt_5iter=[];
cummDistrMovie_iter5=[];

cummDistrallStart20=[];
trajectories_filt_allStart20=[];
trajectories_filt_5iterStart20=[];
cummDistrMovie_iter5start20=[];

    
k=0;
list=[];

cd(filenameBase);
disp('filenamebase');
for j=startNum:endNum
    
    try
    
    i=j-1;
    
    %expPath=[filenameBase];
    %disp(num2str(i));
   
    %open(['workspace_' num2str(i) '.mat']);
    load(['workspace_' num2str(i) '.mat'],'cummDistrMovie_all','trajectories_filtered_all','cummDistrMovie_all_start20','trajectories_filtered_all_start20');
    cummDistrall=horzcat(cummDistrall,cummDistrMovie_all);
    trajectories_filt_all=vertcat(trajectories_filt_all,trajectories_filtered_all);
    trajectories_filt_5iter=vertcat(trajectories_filt_5iter,trajectories_filtered_all);
    
    cummDistrallStart20=horzcat(cummDistrall,cummDistrMovie_all_start20);
    trajectories_filt_allStart20=vertcat(trajectories_filt_allStart20,trajectories_filtered_all_start20);
    trajectories_filt_5iterStart20=vertcat(trajectories_filt_5iterStart20,trajectories_filtered_all_start20);
    
    k=k+1;
    list(k)=i;
    if k==5
        
        %disp(num2str(list(1)));
        [ cummDistrCells ,cummDistrMovieDummy ] = analyzeCells([] ,trajectories_filt_5iter );
        cummDistrMovie_iter5=horzcat(cummDistrMovie_iter5,cummDistrMovieDummy);
        trajectories_filt_5iter=[];
        
        assignin('base', ['trajectories_filt_' num2str(list(1)) '_' num2str(list(5))], trajectories_filt_5iter);
        assignin('base', ['cummDistrMovie_' num2str(list(1)) '_' num2str(list(5))], cummDistrMovieDummy);
        k=0;
        
        [ cummDistrCells ,cummDistrMovieDummyStart20 ] = analyzeCells([] ,trajectories_filt_5iterStart20 );
        cummDistrMovie_iter5start20=horzcat(cummDistrMovie_iter5start20,cummDistrMovieDummyStart20);
        trajectories_filt_5iterStart20=[];
        assignin('base', ['trajectories_filtStart20_' num2str(list(1)) '_' num2str(list(5))], trajectories_filt_5iterStart20);
        assignin('base', ['cummDistrMovie_' num2str(list(1)) '_' num2str(list(5))], cummDistrMovieDummyStart20);
        %k=0;
        list=[];
    end
    catch
        disp(num2str(i));
    end  
    
end

plotCummLLs(cummDistrall,'all',0);
plotCummLLs(cummDistrMovie_iter5,'5iteration',0);
plotCummLLs(cummDistrallStart20,'all_start20',0);
plotCummLLs(cummDistrMovie_iter5start20,'5iterationStart20',0);
[ cummDistrCells_all_ ,cummDistrMovie_all ] = analyzeCells([] ,trajectories_filt_all );
plotCummLLs(cummDistrMovie_all);


