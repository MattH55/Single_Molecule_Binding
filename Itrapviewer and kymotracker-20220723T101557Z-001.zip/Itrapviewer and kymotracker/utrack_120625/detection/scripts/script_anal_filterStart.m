


    
global expPath

filenameBase='E:\DATA_11_05_23\fData\Felix\12_04_26\KCSA_';
indicator='KCSA_';

startNum=1;
endNum=60;


cpds_all=[];
traj_f_all=[];
traj_f_5conc=[];
cpds_conc5_all=[];

cpds_st20_all=[];
traj_f_st20_all=[];
traj_f_st20_5conc=[];
cpds_conc5_st20_all=[];

cpds_n5_dummy=[];
cpds_n5_st20_dummy=[];
traj_0_10_ff_all=[];
    traj_0_15_ff_all=[];
    traj_5_15_ff_all=[];
    traj_5_20_ff_all=[];
    traj_10_20_ff_all=[];
    traj_10_25_ff_all=[];
    
    hist_0_10_ff_all=[];
    hist_0_15_ff_all=[];
    hist_5_15_ff_all=[];
    hist_5_20_ff_all=[];
    hist_10_20_ff_all=[];
    hist_10_25_ff_all=[];

    
k=0;
list=[];

cd([filenameBase '\workspace'] );
disp([filenameBase '\workspace'] );
for j=startNum:endNum
    
    try
    
    i=j-1;
    
    
    load(['workspace_' num2str(i) '.mat'],'tracksFinal');
    
    
    [tFF_0_10]=filterTrajLengthPsfBgr(tracksFinal,6,[0 10],[0 300],[0],[500],[0 512]);
    [tFF_0_15]=filterTrajLengthPsfBgr(tracksFinal,6,[0 15],[0 300],[0],[500],[0 512]);
    [tFF_5_15]=filterTrajLengthPsfBgr(tracksFinal,6,[5 15],[0 300],[0],[500],[0 512]);
    [tFF_5_20]=filterTrajLengthPsfBgr(tracksFinal,6,[5 20],[0 300],[0],[500],[0 512]);
    [tFF_10_20]=filterTrajLengthPsfBgr(tracksFinal,6,[10 20],[0 300],[0],[500],[0 512]);
    [tFF_10_25]=filterTrajLengthPsfBgr(tracksFinal,6,[10 25],[0 300],[0],[500],[0 512]);
    
    [traj_0_10_ff]=getTrajIntAmpPsfBgr_4(tFF_0_10,[],[]);
    [traj_0_15_ff]=getTrajIntAmpPsfBgr_4(tFF_0_15,[],[]);
    [traj_5_15_ff]=getTrajIntAmpPsfBgr_4(tFF_5_15,[],[]);
    [traj_5_20_ff]=getTrajIntAmpPsfBgr_4(tFF_5_20,[],[]);
    [traj_10_20_ff]=getTrajIntAmpPsfBgr_4(tFF_10_20,[],[]);
    [traj_10_25_ff]=getTrajIntAmpPsfBgr_4(tFF_10_25,[],[]);
    
    %[ cummDistrCells_all ,cpd__0_10_ff ] = analyzeCells_1([] ,traj_0_10_ff );
    %[ cummDistrCells_all ,cpd__0_15_ff ] = analyzeCells_1([] ,traj_0_15_ff );
    %[ cummDistrCells_all ,cpd__5_15_ff ] = analyzeCells_1([] ,traj_5_15_ff );
    %[ cummDistrCells_all ,cpd__5_20_ff ] = analyzeCells_1([] ,traj_5_20_ff );
    %[ cummDistrCells_all ,cpd__10_20_ff ] = analyzeCells_1([] ,traj_10_20_ff );
    %[ cummDistrCells_all ,cpd__10_15_ff ] = analyzeCells_1([] ,traj_10_25_ff );
    
    
    %if isempty(cpd__0_10_ff.twoStep)
    %else
        
        
    %cpds_0_10_ff_all=horzcat(cpds_0_10_ff_all,cpd__0_10_ff);
    
    %cpds_n5_dummy=horzcat(cpds_n5_dummy,cummDistrMovie_all);
   
        
    %cpds_n5_st20_dummy=horzcat(cpds_n5_st20_dummy,cummDistrMovie_all_start20);
    %if i==startNum-1
    %disp(traj_0_10_ff);
    [ cummDistrCells_all ,cpd__0_10_ff ] = analyzeCells_1([] ,traj_0_10_ff );
    [ cummDistrCells_all ,cpd__0_15_ff ] = analyzeCells_1([] ,traj_0_15_ff );
    [ cummDistrCells_all ,cpd__5_15_ff ] = analyzeCells_1([] ,traj_5_15_ff );
    [ cummDistrCells_all ,cpd__5_20_ff ] = analyzeCells_1([] ,traj_5_20_ff );
    [ cummDistrCells_all ,cpd__10_20_ff ] = analyzeCells_1([] ,traj_10_20_ff );
    [ cummDistrCells_all ,cpd__10_25_ff ] = analyzeCells_1([],traj_10_25_ff );
    
    
    %traj_f_all=vertcat(traj_f_all,trajectories_filtered_all);
    traj_0_10_ff_all=vertcat(traj_0_10_ff_all,traj_0_10_ff);
    traj_0_15_ff_all=vertcat(traj_0_15_ff_all,traj_0_15_ff);
    traj_5_15_ff_all=vertcat(traj_5_15_ff_all,traj_5_15_ff);
    traj_5_20_ff_all=vertcat(traj_5_20_ff_all,traj_5_20_ff);
    traj_10_20_ff_all=vertcat(traj_10_20_ff_all,traj_10_20_ff);
    traj_10_25_ff_all=vertcat(traj_10_25_ff_all,traj_10_25_ff);
    
    hist_0_10_ff_all=vertcat(hist_0_10_ff_all,cpd__0_10_ff.mean5MaxIntDistr(:,1));
    hist_0_15_ff_all=vertcat(hist_0_15_ff_all,cpd__0_15_ff.mean5MaxIntDistr(:,1));
    hist_5_15_ff_all=vertcat(hist_5_15_ff_all,cpd__5_15_ff.mean5MaxIntDistr(:,1));
    hist_5_20_ff_all=vertcat(hist_5_20_ff_all,cpd__5_20_ff.mean5MaxIntDistr(:,1));
    hist_10_20_ff_all=vertcat(hist_10_20_ff_all,cpd__10_20_ff.mean5MaxIntDistr(:,1));
    hist_10_25_ff_all=vertcat(hist_10_25_ff_all,cpd__10_25_ff.mean5MaxIntDistr(:,1));
    %traj_f_5conc=vertcat(traj_f_5conc,trajectories_filtered_all);
    
    %cpds_st20_all=horzcat(cpds_st20_all,cummDistrMovie_all_start20);
    %traj_f_st20_all=vertcat(traj_f_st20_all,trajectories_filtered_all_start20);
    %traj_f_st20_5conc=vertcat(traj_f_st20_5conc,trajectories_filtered_all_start20);
    
    k=k+1;
    list(k)=i;
    
    %if k==5 || j==endNum
     %   disp(list);
    %    disp('num2str(length(cpds_n5_dummy))');
     %   disp(num2str(length(cpds_n5_dummy)));
     %   assignin('base', ['cpds_'  indicator '_' num2str(list(1)) '_' num2str(list(k))],  cpds_n5_dummy);
    %    assignin('base', ['cpds_st20_'  indicator '_' num2str(list(1)) '_' num2str(list(k))],  cpds_n5_st20_dummy);
        
    %    [ dummy ,cpd_dummy ] = analyzeCells_1([] ,traj_f_5conc );
    %    [ dummy ,cpd_st20_dummy ] = analyzeCells_1([] ,traj_f_st20_5conc );
    %    assignin('base', ['cpd_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], cpd_dummy);
    %    assignin('base', ['cpd_st20_' indicator '_' num2str(list(1)) '_' num2str(list(k))], cpd_st20_dummy);
        
        %cpds_conc5_all=horzcat(cpds_conc5_all,cpd_dummy);
        %cpds_conc5_st20_all=horzcat(cpds_conc5_st20_all,cpd_st20_dummy);
         
        %assignin('base', ['traj_f_' indicator '_' num2str(list(1)) '_' num2str(list(k))], traj_f_5conc);
        %assignin('base', ['traj_f_st20_' num2str(list(1)) '_' num2str(list(k))], traj_f_st20_5conc);
        
        %cpds_n5_dummy=[];
        %cpds_n5_st20_dummy=[];
        %traj_f_st20_5conc=[];
        %traj_f_5conc=[];
        %list=[];
        %k=0;
    %end
    %end
    catch
       disp(num2str(i));
    
    end
    
end


%assignin('base', ['cpds_' indicator '_all'],  cpds_all);
%assignin('base', ['cpds_st20_' indicator '_all'],  cpds_st20_all);


%assignin('base', ['cpds_conc5_' indicator '_all'],  cpds_conc5_all);
%assignin('base', ['cpds_conc5_st20_' indicator '_all'],  cpds_conc5_st20_all);%

%assignin('base', ['traj_f_all_' indicator '_' ], traj_f_all);

%plotCummLLs(cpds_all,['cpds-' indicator '-all'],1);
%plotCummLLs(cpds_conc5_all,['cpds-conc5-' indicator '-all'],1)

%plotCummLLs(cpds_st20_all,['cpds-st20-' indicator '-all'],1);
%plotCummLLs(cpds_conc5_st20_all,['cpds-conc5-st20-' indicator '-all'],1);

%yesAll=1;
%if yesAll==1

%[ cummDistrCells_all ,cpd__0_10_ff_all ] = analyzeCells_1([] ,traj_0_10_ff_all );
%[ cummDistrCells_all ,cpd__0_15_ff_all ] = analyzeCells_1([] ,traj_0_15_ff_all );
%[ cummDistrCells_all ,cpd__5_15_ff_all ] = analyzeCells_1([] ,traj_5_15_ff_all );
%[ cummDistrCells_all ,cpd__5_20_ff_all ] = analyzeCells_1([] ,traj_5_20_ff_all );
%[ cummDistrCells_all ,cpd__10_20_ff_all ] = analyzeCells_1([] ,traj_10_20_ff_all );
%[ cummDistrCells_all ,cpd__10_25_ff_all ] = analyzeCells_1([],traj_10_25_ff_all );

assignin('base', ['hist_0_10_ff_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], hist_0_10_ff_all);
assignin('base', ['hist_0_15_ff_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], hist_0_15_ff_all);
assignin('base', ['hist_5_15_ff_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], hist_5_15_ff_all);
assignin('base', ['hist_5_20_ff_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], hist_5_20_ff_all);
assignin('base', ['hist_10_20_ff_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], hist_10_20_ff_all);
assignin('base', ['hist_10_25_ff_'  indicator '_' num2str(list(1)) '_' num2str(list(k))], hist_10_25_ff_all);

%figure;
%hist(cpd__0_10_ff_all.mean5MaxIntDistr(:,1),x);
%figure;
%hist(cpd__0_15_ff_all.mean5MaxIntDistr(:,1),x);
%figure
%hist(hist_5_15_ff_all,x);
figure
hist(hist_5_20_ff_all,x);
%figure
%hist(hist_10_20_ff_all,x);
%figure
%hist(hist_10_25_ff_all,x);


    
%plotCummLLs(cummDistrMovie_all,['cpds-concall-' indicator],1);
%assignin('base', ['cpds_concAll' indicator],  cummDistrMovie_all);

%end
%save(['ws_full_' indicator '.mat']);