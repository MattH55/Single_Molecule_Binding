


    
global expPath

filenameBase='E:\DATA_11_05_23\fData\Felix\12_04_20\TatBSufI_';
indicator='SufI_12_04_20';

startNum=1;
endNum=45;


cpds_all=[];
traj_f_all=[];
traj_f_5conc=[];
cpds_conc5_all=[];

cpds_st20_all=[];
traj_f_st20_all=[];
traj_f_st20_5conc=[];
cpds_conc5_st20_all=[];

cpds_n5_dummy=[];
cpds_n5_st20_dummy=[];


    
k=0;
list=[];

cd([filenameBase '\workspace'] );
disp('filenamebase');
for j=startNum:endNum
    
    try
    
    i=j-1;
    
    
    load(['workspace_' num2str(i) '.mat'],'cummDistrMovie_all','trajectories_filtered_all','cummDistrMovie_all_start20','trajectories_filtered_all_start20');
    
    
    cpds_all=horzcat(cpds_all,cummDistrMovie_all);
    
    cpds_n5_dummy=horzcat(cpds_n5_dummy,cummDistrMovie_all);
   
        
    cpds_n5_st20_dummy=horzcat(cpds_n5_st20_dummy,cummDistrMovie_all_start20);
    
    
    traj_f_all=vertcat(traj_f_all,trajectories_filtered_all);
    traj_f_5conc=vertcat(traj_f_5conc,trajectories_filtered_all);
    
    cpds_st20_all=horzcat(cpds_all,cummDistrMovie_all_start20);
    traj_f_st20_all=vertcat(traj_f_st20_all,trajectories_filtered_all_start20);
    traj_f_st20_5conc=vertcat(traj_f_st20_5conc,trajectories_filtered_all_start20);
    
    k=k+1;
    list(k)=i;
    
    if k==5 || j==endNum
        
        disp('num2str(length(cpds_n5_dummy))');
        disp(num2str(length(cpds_n5_dummy)));
        assignin('base', ['cpds_'  indicator '_' num2str(list(1)) '_' num2str(list(5))],  cpds_n5_dummy);
        assignin('base', ['cpds_st20_'  indicator '_' num2str(list(1)) '_' num2str(list(5))],  cpds_n5_st20_dummy);
        
        [ dummy ,cpd_dummy ] = analyzeCells([] ,traj_f_5conc );
        [ dummy ,cpd_st20_dummy ] = analyzeCells([] ,traj_f_st20_5conc );
        assignin('base', ['cpd_'  indicator '_' num2str(list(1)) '_' num2str(list(5))], cpd_dummy);
        assignin('base', ['cpd_st20_' indicator '_' num2str(list(1)) '_' num2str(list(5))], cpd_st20_dummy);
        
        cpds_conc5_all=horzcat(cpds_conc5_all,cpd_dummy);
        cpds_conc5_st20_all=horzcat(cpds_conc5_st20_all,cpd_st20_dummy);
         
        assignin('base', ['traj_f_' indicator '_' num2str(list(1)) '_' num2str(list(5))], traj_f_5conc);
        assignin('base', ['traj_f_st20_' num2str(list(1)) '_' num2str(list(5))], traj_f_st20_5conc);
        
        
        cpds_n5_dummy=[];
        cpds_n5_st20_dummy=[];
        traj_f_st20_5conc=[];
        traj_f_5conc=[];
        list=[];
        k=0;
    end
    catch
        disp(num2str(i));
    end  
    
end


assignin('base', ['cpds_' indicator '_all'],  cpds_all);
assignin('base', ['cpds_st20_' indicator '_all'],  cpds_st20_all);


assignin('base', ['cpds_conc5_' indicator '_all'],  cpds_conc5_all);
assignin('base', ['cpds_conc5_st20_' indicator '_all'],  cpds_conc5_st20_all);

plotCummLLs(cpds_all,['cpds_' indicator '_all'],0);
plotCummLLs(cpds_conc5_all,['cpds_conc5_' indicator '_all'],0)

plotCummLLs(cpds_st20_all,'all_start20',0);
plotCummLLs(cpds_conc5_st20_all,['cpds_conc5_st20_' indicator '_all'],0);

%[ cummDistrCells_all_ ,cummDistrMovie_all ] = analyzeCells([] ,traj_f_all );
%plotCummLLs(cummDistrMovie_all);


