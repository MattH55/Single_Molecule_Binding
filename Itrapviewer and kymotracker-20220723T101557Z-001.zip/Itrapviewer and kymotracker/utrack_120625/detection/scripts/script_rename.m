


    
%global expPath














%E:\DATA_11_05_23\fData\Felix\12_02_09\TATa_SufI_ind_P10p5W_12
filenameBase='E:\DATA_11_05_23\fData\Felix\12_04_19\KCSA_';
%filenameBase='E:\DATA_11_05_23\fData\Felix\12_02_09\TATa_SufI_ind_P10p5W_';
%filenameBase='E:\DATA_11_05_23\fData\Felix\12_02_08\TATa_SufI_ind_P10p5W_';


startNum=23;
endNum=24;



for j=startNum:endNum
    i=j-1;
    try
    cd([filenameBase num2str(i)]);
    dirData = dir('*.tif');         %# Get the selected file data
       fileNames = {dirData.name};     %# Create a cell array of file names
    for iFile = 1:numel(fileNames)  %# Loop over the file names
    newName = sprintf('img_%04d.tif',iFile);  %# Make the new name
    movefile(fileNames{iFile},newName);        %# Rename the file
    end
    end
end


