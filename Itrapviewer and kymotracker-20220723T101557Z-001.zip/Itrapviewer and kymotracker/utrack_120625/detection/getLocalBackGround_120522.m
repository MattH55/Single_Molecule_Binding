function [bgMean,bgStd,bgrArea] = getLocalBackGround_120522(imageLast5,localMax,radiusMinMax)

%the function in its current form assigns blocks of 11x11 pixels the
%same background values, for the sake of speed

%This file is part of u-track.
%
%    u-track is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%    u-track is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with u-track.  If not, see <http://www.gnu.org/licenses/>.
%
%
%Copyright: Khuloud Jaqaman 01/2008

[sizeY,sizeX]=size(imageLast5);
%dummy=imageSize;
%imageSize(1)=dummy(2);
%imageSize(2)=dummy(1);


imageDummy=nan(sizeY,sizeX);
innerRadius=radiusMinMax(1);
outerRadius=radiusMinMax(2);

[numMax,dummy]=size(localMax);%%%number of maxima in cluster
r=zeros(numMax,1);

sizeT=2*numMax*uint16(3.14159265*(outerRadius^2-innerRadius^2));
imageLocal = NaN(sizeT,1);


maxPosY=localMax(:,2)'+outerRadius;
maxPosX=localMax(:,1)'+outerRadius;
minPosY=localMax(:,2)'-outerRadius;
minPosX=localMax(:,1)'-outerRadius;


%get min/max coordinates of local maxima cluster region
iPixelYMin=round(max(min(minPosY),1));
iPixelYMax=round(min(max(maxPosY),sizeY));


iPixelXMin=round(max(min(minPosX),1));
iPixelXMax=round(min(max(maxPosX),sizeX));


%disp('localMax');
%disp(localMax);

%disp('iPixelYMin');
%disp(iPixelYMin);
%disp(iPixelYMax);
%disp('iPixelXMin');
%disp(iPixelXMin);
%disp(iPixelXMax);
%disp('sizeY sizeX');
%disp([sizeY sizeX]);
%initialize count of valid pixels for bgr calulation 
count=0;

%go over all pixels within limits
for iPixelY = iPixelYMin : iPixelYMax
    for iPixelX = iPixelXMin : iPixelXMax
        
        %calculate distances of pixel position to local maxima positions
        for m=1:numMax
            r(m)=sqrt((iPixelX-localMax(m,1))^2+(iPixelY-localMax(m,2))^2);
        end
        
        %all distances must be > innerRadius (redundant?) and at least one
        %radius must be smaller than outerRadius
        if min(r(:)>innerRadius)>0 && max(r(:)<outerRadius)>0
        
            count=count+1;
            imageLocal(count)=imageLast5(iPixelY,iPixelX);
            %disp('[iPixelY iPixelX]');
            
            %disp([iPixelY iPixelX]);
            %disp(imageLocal(count)*65536);
            imageDummy(iPixelY,iPixelX)=1;    
        end
    end
end

imageLocal(isnan(imageLocal))=[];
bgrArea=find(~isnan(imageDummy));
%imageDisp=imageLast5;
%imageDisp(bgrArea)=1;
%imageDisp(localMax(2),localMax(1))=1;
%imtool(imageDisp);
%Determine background         
if ~isempty(imageLocal)
    [bgMean,bgStd] = robustMean(imageLocal(:));
else
    disp('Background calculation failed  - isEpmty');
    bgMean = NaN;
    bgStd = NaN;
end
