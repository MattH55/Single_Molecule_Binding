function [  ] = selectImageRegions(  )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


%ask user for images
imageDir='C:\tfromTest\test\';
[fName,dirName] = uigetfile([imageDir '*.tif'],'specify first image in the stack - specify very first image, even if not to be plotted');

%define region of interest
imageROI=imread([dirName fName]);

intMinMax=[min(min(imageROI)) max(max(imageROI))];
figure, imshow(imageROI,intMinMax),title('Draw ROI and double-click to continue.');
imcontrast;

h=imrect;
position = wait(h);

h.delete;
h=imrect(gca,position);
setColor(h,'r');
%api = iptgetapi(h);
%api.addNewPositionCallback(@(p) assignin('base','pos',p));
position2=wait(h);

%disp(pos);
close all;

imageRange(2,1)=uint16(position(1));
imageRange(2,2)=uint16(position(1)+position(3));
imageRange(1,1)=uint16(position(2));
imageRange(1,2)=uint16(position(2)+position(4));

%figure, imshow(imageROI,intMinMax),title('Move ROI and double-click to continue.');
%h = imrect(position);
%position2 = wait(h);
%close all;

imageRange2(2,1)=uint16(position2(1));
imageRange2(2,2)=uint16(position2(1)+position2(3));
imageRange2(1,1)=uint16(position2(2));
imageRange2(1,2)=uint16(position2(2)+position2(4));


disp(imageRange);
disp(imageRange2);

%image_base(1:imageRange(1,2)-imageRange(1,1)+1,1:imageRange(2,2)-imageRange(2,1)+1)=imageROI(imageRange(1,1):imageRange(1,2),imageRange(2,1):imageRange(2,2));
image_base=imageROI(imageRange(1,1):imageRange(1,2),imageRange(2,1):imageRange(2,2));

image_input=imageROI(imageRange2(1,1):imageRange2(1,2),imageRange2(2,1):imageRange2(2,2));

mkdir([imageDir '\selection']);

imwrite(image_base,[imageDir '\selection\img_1_Sequence_000.tif'],'tif');
imwrite(image_input,[imageDir '\selection\img_2_Sequence_000.tif'],'tif');
imwrite(image_input,[imageDir '\selection\img_3_Sequence_000.tif'],'tif');
imwrite(image_input,[imageDir '\selection\img_4_Sequence_000.tif'],'tif');
imwrite(image_input,[imageDir '\selection\img_5_Sequence_000.tif'],'tif');

setpath
scriptDetectGeneralPsf_test
scriptTrackGeneralModPsfBgrInt

end

