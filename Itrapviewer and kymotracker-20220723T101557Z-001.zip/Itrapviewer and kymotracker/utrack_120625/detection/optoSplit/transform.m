function [ base_points, input_points,TFORM ] = transformTest( movieInfo,pointToPoint )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here



[numPoints,dummy]=size(pointToPoint)
base_points=zeros(numPoints,2);
input_points=zeros(numPoints,2);
disp(numPoints);

for i=1:numPoints
    disp(i);
    base_points(i,1)=movieInfo(1).xCoord(pointToPoint(i,1));
    input_points(i,1)=movieInfo(2).xCoord(pointToPoint(i,2));
    base_points(i,2)=movieInfo(1).yCoord(pointToPoint(i,1));
    input_points(i,2)=movieInfo(2).yCoord(pointToPoint(i,2));

end




TFORM = cp2tform(input_points, base_points, 'polynomial');

imageDir='C:\tfromTest\test\';

[fName,dirName] = uigetfile([imageDir '*.tif'],'specify first base');
imbase=imread([dirName fName]);

[fName,dirName] = uigetfile([imageDir '*.tif'],'specify first input');
iminput=imread([dirName fName]);

[registered]= imtransform(iminput, TFORM,'bicubic','XData', [1 size(imbase,2)],'YData', [1 size(imbase,1)]);

figure,imshow(iminput);
figure,imshow(registered);
figure; imshow(imbase);

mkdir([dirName '\resultsTransform\']);
imwrite(iminput,[dirName '\resultsTransform\img_1.tif'],'tif');
imwrite(registered,[dirName '\resultsTransform\img_2.tif'],'tif');
imwrite(imbase,[dirName '\resultsTransform\img_3.tif'],'tif');


end

