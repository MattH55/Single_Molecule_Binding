function [ base_points, input_points,TFORM ] = transformStack( movieInfo,pointToPoint,imageRange,imageRange2  )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here



[numPoints,dummy]=size(pointToPoint)
base_points=zeros(numPoints,2);
input_points=zeros(numPoints,2);
disp(numPoints);

for i=1:numPoints
    disp(i);
    base_points(i,1)=movieInfo(1).xCoord(pointToPoint(i,1));
    input_points(i,1)=movieInfo(2).xCoord(pointToPoint(i,2));
    base_points(i,2)=movieInfo(1).yCoord(pointToPoint(i,1));
    input_points(i,2)=movieInfo(2).yCoord(pointToPoint(i,2));

end




TFORM = cp2tform(input_points, base_points, 'affine');

imageDir='C:\tfromTest\test\';

[fNameStart,dirName] = uigetfile([imageDir '*.tif'],'specify first image in stack');
%imbase=imread([dirName fName]);

[fNameEnd,dirName] = uigetfile([dirName '*.tif'],'specify last image in stack');
%iminput=imread([dirName fName]);

digits4Enum=4;
ending='__000.tif';
enumString = getStringIndx(digits4Enum);

fNameBase=fNameStart( 1:length(fNameStart)-length(ending)-4 );
nameStartNumber=fNameStart(length(fNameStart)-length(ending)-4 : length(fNameStart)-length(ending) );
nameEndNumber=fNameEnd(length(fNameStart)-length(ending)-4 : length(fNameStart)-length(ending));

startNumber=str2num(nameStartNumber)+1;
endNumber=str2num(nameEndNumber)+1;
disp('nameStartNumber');
disp('nameEndNumber');
disp('startNumber');
disp('endNumber');
disp(nameStartNumber);
disp(nameEndNumber);
disp(startNumber);
disp(endNumber);

mkdir([dirName '\base\']);
mkdir([dirName '\inputTransform\']);
mkdir([dirName '\input\']);


for i=startNumber:endNumber
    
    imageTMP=imread([dirName fNameBase enumString(i,:) ending]);
    %disp([dirName fNameBase enumString(i,:) ending]);
    %figure,imshow(imageTMP);
    
    imbase=imageTMP(imageRange(1,1):imageRange(1,2),imageRange(2,1):imageRange(2,2));
    iminput=imageTMP(imageRange2(1,1):imageRange2(1,2),imageRange2(2,1):imageRange2(2,2));
    %figure, imshow(imbase);
    
    
    [registered]= imtransform(iminput, TFORM,'bicubic','XData', [1 size(imbase,2)],'YData', [1 size(imbase,1)]);

    %imwrite(registered,[dirName '\resultsTransform\ ],'tif');
    imwrite(registered,[dirName '\inputTransform\' fNameBase enumString(i,:) ending],'tif');
    imwrite(imbase,[dirName '\base\' fNameBase enumString(i,:) ending],'tif');
    imwrite(iminput,[dirName '\input\' fNameBase enumString(i,:) ending],'tif');


end

%% Subfunction 1

function enumString = getStringIndx(digits4Enum)

switch digits4Enum
    case 4
        enumString = repmat('0',9999,4);
        for i = 1 : 10
            enumString(i,:) = ['000' num2str(i-1)];
        end
        for i = 11 : 100
            enumString(i,:) = ['00' num2str(i-1)];
        end
        for i = 101 : 1000
            enumString(i,:) = ['0' num2str(i-1)];
        end
        for i = 1001 : 10000
            enumString(i,:) = num2str(i-1);
        end
    case 3
        enumString = repmat('0',999,3);
        for i = 1 : 9
            enumString(i,:) = ['00' num2str(i)];
        end
        for i = 10 : 99
            enumString(i,:) = ['0' num2str(i)];
        end
        for i = 100 : 999
            enumString(i,:) = num2str(i);
        end
    case 2
        enumString = repmat('0',99,2);
        for i = 1 : 9
            enumString(i,:) = ['0' num2str(i)];
        end
        for i = 10 : 99
            enumString(i,:) = num2str(i);
        end
    case 1
        enumString = repmat('0',9,1);
        for i = 1 : 9
            enumString(i,:) = num2str(i);
        end
end

