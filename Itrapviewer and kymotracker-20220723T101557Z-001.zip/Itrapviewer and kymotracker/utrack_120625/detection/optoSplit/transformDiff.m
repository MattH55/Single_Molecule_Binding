function [ diff ] = transformDiff( movieInfo, inputPoints )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
diff=zeros(length(inputPoints),1);
for i=1:length (inputPoints)
    disp(inputPoints(i,1));
    disp(inputPoints(i,2));
    diff(i) = sqrt((movieInfo(1).xCoord(inputPoints(i,1))-movieInfo(2).xCoord(inputPoints(i,2)))^2+(movieInfo(1).yCoord(inputPoints(i,1))-movieInfo(2).yCoord(inputPoints(i,2)))^2);
    disp(sqrt((movieInfo(1).xCoord(inputPoints(i,1))-movieInfo(2).xCoord(inputPoints(i,2)))^2+(movieInfo(1).yCoord(inputPoints(i,1))-movieInfo(2).yCoord(inputPoints(i,2)))^2));
end

end

