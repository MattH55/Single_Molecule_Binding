function [ base_points, input_points,TFORM ] = transformTest( trajectories_filtered_all )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

numPoints=length(trajectories_filtered_all);
base_points=zeros(numPoints,2);
input_points=zeros(numPoints,2);
disp(numPoints);
for i=1:numPoints
    disp(i);
    base_points(i,1)=trajectories_filtered_all(i).x(1);
    input_points(i,1)=trajectories_filtered_all(i).x(2);
    base_points(i,2)=trajectories_filtered_all(i).y(1);
    input_points(i,2)=trajectories_filtered_all(i).y(2);

end




TFORM = cp2tform(input_points, base_points, 'polynomial');

imageDir='C:\tfromTest\test\';

[fName,dirName] = uigetfile([imageDir '*.tif'],'specify first base');
imbase=imread([dirName fName]);

[fName,dirName] = uigetfile([imageDir '*.tif'],'specify first input');
iminput=imread([dirName fName]);

[registered]= imtransform(iminput, TFORM,'XData', [1 size(imbase,2)],'YData', [1 size(imbase,1)]);

figure,imshow(iminput);
figure,imshow(registered);
figure; imshow(imbase);

mkdir([dirName '\resultsTransform\']);
imwrite(iminput,[dirName '\resultsTransform\img_1.tif'],'tif');
imwrite(registered,[dirName '\resultsTransform\img_2.tif'],'tif');
imwrite(imbase,[dirName '\resultsTransform\img_3.tif'],'tif');


end

