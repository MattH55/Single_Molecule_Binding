function [ intensToMsd,intens] = statsSignVsMSD(trajectories,dR)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


stat = repmat(struct('MSD',[],'MMSD',[],'meanInt',[],'meanAvInt',[],'maxAmp',[],'meanAmp',[],'averAmp',[],'meanAvAmp',[]),length(trajectories),1);
intensToMsd=[];
intens=[];
disp(length(trajectories));
for j=1:50
    k=0;
    meanR=(2*dR)*(j-1);
    disp(meanR);
    intens(j)=meanR;
    meanSqrdDispl2=[];
    for i=1:length(trajectories)
    
        if trajectories(i).maxInt>meanR-dR && trajectories(i).maxInt<meanR+dR
            
            for l=1:numel(trajectories(i).x)-2
                if trajectories(i).x(l)>0 && trajectories(i).x(l+2)>0
                    disp(trajectories(i).x(l));
                    disp(trajectories(i).x(l+2));
                    xSqrd=(trajectories(i).x(l)-trajectories(i).x(l+2))^2;
                    ySqrd=(trajectories(i).y(l)-trajectories(i).y(l+2))^2;
                    rSqrd=xSqrd+ySqrd;
                    meanSqrdDispl2=horzcat(meanSqrdDispl2,rSqrd);
                end
            end
            
   
        end
    
     
    end
    intensToMsd(j)=mean(meanSqrdDispl2);
end

intensToMsd=intensToMsd';
intens=intens';

