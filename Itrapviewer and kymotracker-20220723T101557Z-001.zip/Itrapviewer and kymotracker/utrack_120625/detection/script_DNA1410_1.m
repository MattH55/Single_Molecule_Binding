global expPath






%specify the minimal length of trajectories taken into account for
%analysis and display
trajFilterLength=3;

%%


%setpath;    % sets the path to location of images 
roiFullFlag = 0;
[kymo,bgParam,bitDepth]=selectRegionDNA(roiFullFlag); % selects the ROI for tracking and display - returns the ROI coordinates[ movieInfo,exceptions,localMaxima,background,psfSigma ]...


%detection and fitting of fluorescent particles 
%change here the detection parameters!!!
% [ movieInfo,exceptions,localMaxima,background,psfSigma ]...
% =detectGeneralDNA_141013_1(kymo);    
detectGeneralDNA_141013_1_script


resfig=figure;
imshow(kymo);
hold on;
maxX=[];
maxY=[];
for i=1:length(localMaxima)
    for j=1:length(localMaxima(i).cands);
        maxX=[maxX,localMaxima(i).cands(j).Lmax(1)];
        maxY=[maxY,i];
    end
end
if ~isempty(maxX)
        plot(maxY,maxX,'yo');
end

%particle linking
%%%change here the tracking parameters
scriptTrackGeneral_120522;      


%filter for obtained trajectories
[tracksFinalFiltered]=filterTrajLengthPsfBgr(tracksFinal,trajFilterLength,[0 900],[0 900],[0],[900],[0 2000]);%filters for trajectories with certain properties
%parameters: 1. name of output-variable, 2. minimal trajectory length, 3. window for trajectory start, 4. window for trajectory end
%5. minimal meanRsquared(pixel), 6. maximalSegmentLength, 7. startCoordinate x 


%[trajectories_filtered_all]=getTraj_DNA(tracksFinalFiltered,[],[]);% transforms data structure in a more digestible form
[trajectories_filtered]=getTrajIntAmpPsfBgr_DNA1410_1(tracksFinalFiltered,[],[]);% transforms data structure in a more digestible form

%% plot the bunch
resfig2=figure;
imshow(kymo);
hold on;
maxX=[];
maxY=[];
for i=1:length(localMaxima)
    for j=1:length(localMaxima(i).cands);
        maxX=[maxX,localMaxima(i).cands(j).Lmax(1)];
        maxY=[maxY,i];
    end
end
if ~isempty(maxX)
        plot(maxY,maxX,'co');
end
for i=1:length(trajectories_filtered)
    figure(resfig2)
    iexist=trajectories_filtered(i).x==1;
    imiss=~iexist
    plot(trajectories_filtered(i).i(iexist),trajectories_filtered(i).y(iexist)...
        ,'yo-','markersize',5);
    for j=find(imiss)
       ixmiss=mean(trajectories_filtered(i).i([j-1,j+1]));
       ymiss=mean(trajectories_filtered(i).y([j-1,j+1]));
       plot(ixmiss,ymiss,'rx','markersize',5,'hittest','off')
    end
end

analysisPara=repmat(struct('timelapse',[],'pixelSize',[],'diffDim',[],'numTimeLags',[],'msdDispFlag',[],'trajFilterLength',[]),1);
[ analysisData] = getCummOutTrajDNA( trajectories_filtered,[] ,analysisPara)