function [ movieInfo,exceptions,localMaxima,background,psfSigma ] = detectGeneral_120522( numImages )
%This file is part of u-track.
%
%    u-track is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%    u-track is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with u-track.  If not, see <http://www.gnu.org/licenses/>.
%
%Copyright Jaqaman 01/08

%% movie information

%movieParam.imageDir = 'C:/Users/Felix/Documents/MATLAB/u-track/andrea1/'; %directory where images are
global expPath

if  exist('expPath')==0 || exist('expPath')==2 || isempty(expPath)
    clearPath;
    setPath;
    %path=[uigetdir('C:\Users\Fos\Documents\MATLAB\utrack\','select folder containing BF image folder') '/'];
else
    disp(' ');
    disp(['Path previously selected: ' expPath]);
    disp('In order to select a different path run clearPath and/or setPath');
    
    %path=expPath;
end
movieParam.imageDir=expPath;
cd(expPath);



%rename images in folder expPath to "img_0001.tif"
try
    dirData = dir('*.tif');         %# Get the selected file data
    fileNames = {dirData.name};     %# Create a cell array of file names
    numImagesInFolder=numel(fileNames);
    for iFile = 1:numImagesInFolder  %# Loop over the file names
    newName = sprintf('img_%04d.tif',iFile);  %# Make the new name
    movefile(fileNames{iFile},newName);        %# Rename the file
    end
catch
    disp(' ');
    disp('Renaming: Filenames are already in the correct format');     
end

%catch insufficient image selection
if nargin<1 || isempty(numImages)
    numImages(1)=1;
    numImages(2)=numImagesInFolder;
    disp(' ');
    disp(['All ' num2str(numImages) ' images selected for detection']);
elseif numImages(2)<1 || numImages(1)>=numImages(2)
    disp(' ');
    disp('Error in image selection for detection');
    disp(['Imagenumber start/end: ' num2str(numImages)]);
    return
end
    



%movieParam.imageDir = 'C:/Users/Felix/Documents/MATLAB/u-track/11_02_17/YT_2/1500_60ms_1/'; %directory where images are
movieParam.filenameBase = 'img_'; %image file name base
movieParam.firstImageNum= numImages(1); %number of first image in movie
movieParam.lastImageNum = numImages(2); %number of last image in movie
movieParam.digits4Enum = 4; %number of digits used for frame enumeration (1-4).

%% detection parameters

%Camera bit-depth
detectionParam.bitDepth = 16;

%The standard deviation of the point spread function is defined
%as 0.21*(emission wavelength)/(numerical aperture). If the wavelength is
%given in nanometers, this will be in nanometers. To convert to pixels,
%divide by the pixel side length (which should also be in nanometers).
detectionParam.psfSigma = 1.3;

%Boundaries in pixels for sigma fit
detectionParam.psfSigmaMinMax = [1.2 4];

%For tracking on DNA - flag for detcting local background with box 
%above and below the DNA for detecting local background
detectionParam.bgrDetectBoxFlag = 0;

%distance from DNA and half the width of background detection box in pixels
detectionParam.offsetSizeBgrBox = [5 5];

%inner and outer radius in pixels for local background detection disk
detectionParam.bgrRadiusMinMax = [3 5];

%Parameters for detecting background by moving rectangle in "first value" and "second value" size
detectionParam.spatMovBgrParam = [11 15];



%Number of frames before and after a frame for time averaging
%For no time averaging, set to 0
detectionParam.integWindow = 0;

%Alpha-value for initial detection of local maxima
detectionParam.alphaLocMax = 0.1;

%Maximum number of iterations for PSF sigma estimation for detected local
%maxima
%To use the input sigma without modification, set to 0
detectionParam.numSigmaIter = 0;

%1 to attempt to fit more than 1 kernel in a local maximum, 0 to fit only 1
%kernel per local maximum
%If psfSigma is < 1 pixel, set doMMF to 0, not 1. There is no point
%in attempting to fit additional kernels in one local maximum under such
%low spatial resolution
detectionParam.doMMF = 0;

%1 update background area before final fitting, 0 no update
detectionParam.bgrUpdateFlag = 0;

%Alpha-values for statistical tests in mixture-model fitting step
detectionParam.testAlpha = struct('alphaR',0.001,'alphaA',0.001,'alphaD',0.001,'alphaF',0);

%1 to visualize detection results, frame by frame, 0 otherwise. Use 1 only
%for small movies. In the resulting images, blue dots indicate local
%maxima, red dots indicate local maxima surviving the mixture-model fitting
%step, pink dots indicate where red dots overlap with blue dots
detectionParam.visual = 1;

%1 to visualize background detection areas, frame by frame, 0 otherwise. Use 1 only
%for small movies. In the resulting images, blue dots indicate local
%maxima, red dots indicate local maxima surviving the mixture-model fitting
%step, pink dots indicate where red dots overlap with blue dots
detectionParam.visualBgr = 1;

if detectionParam.visualBgr==1;
    mkdir([expPath '\backGrdDetection\']);
end


%% save results

saveResults.dir = movieParam.imageDir; %directory where to save input and output
saveResults.filename = 'testDetection.mat'; %name of file where input and output are saved

%% run the detection function

[movieInfo,exceptions,localMaxima,background,psfSigma] = ...
    detectSubResFeatures2D_StandAlone_120522(movieParam,detectionParam,saveResults);

%% Output variables

%The important output variable is movieInfo, which contains the detected
%particle information

%for a movie with N frames, movieInfo is a structure array with N entries.
%Every entry has the fields xCoord, yCoord, zCoord (if 3D) and amp.
%If there are M features in frame i, each one of these fields in
%moveiInfo(i) will be an Mx2 array, where the first column is the value
%(e.g. x-coordinate in xCoord and intensity in amp) and the second column
%is the standard deviation.

