function [ ] = cellFilterOverlay_120522(overlayFlag)
%Uses two brightfield images to detect celloutlines
%Generates a binery mask used in function "detectGeneral_120522"
%Has the option to generate in which cell outlines are overlayed

global expPath;
show=0; %display steps in cell boundary detection procedure set show=1



if nargin<1 || isempty(overlayFlag)
overlayFlag=0;
end

%select experiment folder
if  exist('expPath')==0 || exist('expPath')==2 || isempty(expPath)
    
    path=[uigetdir('C:\Users\Fos\Documents\MATLAB\utrack\','select folder containing BF image folder') '/'];
    imageDir=path;
    %disp(['actual path:' imageDir]);
else
    %disp(['Path previously selected: ' expPath]);
    %disp('In order to select a different path run clearPath and/or setPath');
    imageDir=expPath;
end



%create array of strings for numeration of images  
enumStringFluo = getStringIndx(4);
enumStringBF = getStringIndx(3);

%create filename bases
filenameBaseFluo='img_00000';
filenameBaseBF='img_000000000__';

%create folders
imageSaveDir=[imageDir 'boundaryOverlay/'];
imageSaveDirMask=[imageDir 'mask/'];
mkdir(imageSaveDir);
mkdir(imageSaveDirMask);
pathBF=[imageDir 'BF/'];

%read images
%disp([pathBF filenameBaseBF enumStringBF(imageNumBottom,:) '.tif']);
imBottom=imread([pathBF 'img_000000000_Snap_000' '.tif']);
imTop=imread([pathBF 'img_000000001_Snap_000' '.tif']);
imMiddle=imread([pathBF 'img_000000000_Snap_000' '.tif']);
imSub=imTop-imBottom;
[Ximg,Yimg]=size(imBottom);

%create gradient image from substracted BF images
[junk threshold] = edge(imSub, 'sobel');
fudgeFactor = 0.5;
imGradient = edge(imSub,'sobel', threshold * fudgeFactor);
imGradient=im2uint8(imGradient);
imwrite(imGradient,[imageSaveDirMask 'imGradient.tif'],'tif');

%connect gradient lines
se = strel('disk',2);
se2 = strel('disk',3);
imGradientConnected = imclose(imGradient,se);
imGradientMask=im2uint8(imGradientConnected);
imwrite(imGradientMask,[imageSaveDirMask 'imGradientConnected.tif'],'tif');

%filter out small objects 
imGradientFiltered = bwareaopen(imGradientConnected,300);
imGradientFiltered=im2uint8(imGradientFiltered);
imwrite(imGradientFiltered,[imageSaveDirMask 'imGradientFiltered.tif'],'tif');

%fill holes in gradient ring
imGradientRingFilled = imclose(imGradientFiltered,se2);
imGradientRingFilled=im2uint8(imGradientRingFilled);
imwrite(imGradientRingFilled,[imageSaveDirMask 'imGradientRingFilled.tif'],'tif');
imGradientFilled = imfill(imGradientRingFilled,'holes');


%detect inner bondary of gradient ring
imInnerRing = zeros([Ximg Yimg]); 
[B,L,N] = bwboundaries(imGradientRingFilled);
for k=1:length(B)
    boundary = B{k};
    if(k > N)
        for l=1:length(boundary(:,2))         
            imInnerRing(boundary(l,1),boundary(l,2))=1;
        end
    end
end


%
imInnerRingFilled=imfill(imInnerRing,'holes');
imwrite(imInnerRingFilled,[imageSaveDirMask 'imInnerRingFilled.tif'],'tif');

%filter out small objects 
imInnerRingFilled = bwareaopen(imInnerRingFilled,300);
imInnerRingFilled=im2uint8(imInnerRingFilled);
imwrite(imInnerRingFilled,[imageSaveDirMask 'imInnerRingFilled_filtered.tif'],'tif');

%dilate mask
se90 = strel('line', 5, 90);
se0 = strel('line', 5, 0);
imInnerRingDilate = imdilate(imInnerRing, [se90 se0]);
imInnerRingFilledDilate = imdilate(imInnerRingFilled, [se90 se0]);
imwrite(imInnerRingDilate,[imageSaveDirMask 'imInnerRingDilate.tif'],'tif');
imwrite(imInnerRingFilledDilate,[imageSaveDirMask 'imInnerRingFilledDilate.tif'],'tif');
imwrite(im2bw(imInnerRingFilledDilate),[imageSaveDirMask 'mask.tif'],'tif');





%cell outline overlay with brightfield image
imCellBoundary = zeros([Ximg Yimg]); 
[B,L,N] = bwboundaries(imInnerRingDilate);
for k=1:length(B)
    boundary = B{k};
    if(k > N)
    else
        
        for l=1:length(boundary(:,2))         
            imMiddle(boundary(l,1),boundary(l,2))=16536;
            imCellBoundary(boundary(l,1),boundary(l,2)) = 256;
        end
    end
end
%figure,imshow(imMiddle);
imwrite(im2uint8(imCellBoundary),[imageSaveDirMask 'imCellBoundary.tif'],'tif');
imwrite(imMiddle,[imageSaveDirMask 'imMiddle.tif'],'tif');


%cell outline overlay with fluorescence images
if overlayFlag==1
    [B,L,N] = bwboundaries(imInnerRingFilledDilate);
    
    for i=1:300
        imageTmp = imread([imageDir filenameBaseFluo enumStringFluo(i,:) '_Sequence_000.tif']);    
        for k=1:length(B)
            boundary = B{k};
            if(k > N)

            else
                for l=1:length(boundary(:,2))         
                    imageTmp(boundary(l,1),boundary(l,2))=0;
                end
            end
        end
        imwrite(imageTmp,[imageSaveDir filenameBaseFluo enumStringFluo(i+1,:) '.tif'],'tif');
    end
    
end


%M=uint16(imGradientFilled).*imBottom;
%figure, imshow(M), title('filled');
%figure, imshow(imFluo), title('fluo');
%figure, imshow(imMiddle), title('imBottom');

if show==1
    figure, imshow(imGradient), title('imGradient');
    figure, imshow(imGradientConnected), title('binary gradient connected');
    figure, imshow(imGradientFiltered), title('imGradientFiltered');
    figure, imshow(imGradientRingFilled), title('binary gradient mask');
    figure,imshow(imInnerRingFilled), title('imInnerRingFilled');
    figure, imshow(imInnerRing), title('imInnerRing');
    figure,imshow(imInnerRingDilate), title('imInnerRingDilate');
    figure,imshow(imInnerRingFilledDilate), title('imInnerRingFilledDilate');
    figure,imshow(im2bw(imInnerRingFilledDilate)), title('imInnerRingFilledDilateBW');
    figure,imshow(imCellBoundary), title('imCellBoundary');
end

end
%% Subfunction 1

function enumString = getStringIndx(digits4Enum)

switch digits4Enum
    case 4
        enumString = repmat('0',9999,4);
        for i = 1 : 10
            enumString(i,:) = ['000' num2str(i-1)];
        end
        for i = 11 : 100
            %disp(num2str(i-1));
            %disp(['00' num2str(i-1)]);
            enumString(i,:) = ['00' num2str(i-1)];
        end
        for i = 101 : 1000
            enumString(i,:) = ['0' num2str(i-1)];
        end
        for i = 1001 : 9999
            enumString(i,:) = num2str(i-1);
        end
    case 3
        enumString = repmat('0',999,3);
        for i = 1 : 10
            enumString(i,:) = ['00' num2str(i-1)];
        end
        for i = 11 : 100
            enumString(i,:) = ['0' num2str(i-1)];
        end
        for i = 101 : 1000
            enumString(i,:) = num2str(i-1);
        end
    case 2
        enumString = repmat('0',99,2);
        for i = 1 : 9
            enumString(i,:) = ['0' num2str(i-1)];
        end
        for i = 10 : 99
            enumString(i,:) = num2str(i-1);
        end
    case 1
        enumString = repmat('0',9,1);
        for i = 1 : 9
            enumString(i,:) = num2str(i-1);
        end
end
end

