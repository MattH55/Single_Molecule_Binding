
%clear;

global expPath





filenameBase='E:\DATA_11_05_23\fData\Felix\KCSA60ms_';
imageNumStartEnd=[7 7];

mkdir([filenameBase '\workspace\']);

startNum=1;
endNum=1;

for j=startNum:endNum
    
    %try
    i=j-1;
        
    
    expPath=[filenameBase num2str(i) '\'];
    cellFilterOverlay_120522(0);
    
    
    
    %Particle detection 
    [ movieInfo,exceptions,localMaxima,background,psfSigma ]...
    =detectGeneral_120522(imageNumStartEnd);
    
    %Particle linking
    scriptTrackGeneral_120522;
    
    trajName=['trajectories_filtered_all_25deg_' num2str(i)];
    cummdistrName=['cummDistrMovie_all_' num2str(i)];
    trajName_start20=['trajectories_filtered_all_25deg_start20_' num2str(i)];
    cummdistrName_start20=['cummDistrMovie_all_start20_' num2str(i)];
    
    
    [tracksFinalFiltered]=filterTrajLengthPsfBgr(tracksFinal,2,[0 300],[0 300],[0],[500],[0 512]);
    [trajectories_filtered_all]=getTrajIntAmpPsfBgr_4(tracksFinalFiltered,[],[]);
    [trajectories_notFiltered_all]=getTrajIntAmpPsfBgr_4(tracksFinal,[],[]);
    [ cummDistrCells_all ,cummDistrMovie_all ] = analyzeCells_1([] ,trajectories_filtered_all );
    
    [tracksFinalFiltered_start20]=filterTrajLengthPsfBgr(tracksFinal,6,[20 300],[0 300],[0],[500],[0 512]);
    [trajectories_filtered_all_start20]=getTrajIntAmpPsfBgr_4(tracksFinalFiltered_start20,[],[]);
    [ cummDistrCells_all_start20 ,cummDistrMovie_all_start20 ] = analyzeCells_1([] ,trajectories_filtered_all_start20 );
    
    
    
    assignin('base', trajName_start20, trajectories_filtered_all_start20);
    assignin('base', cummdistrName_start20, cummDistrMovie_all_start20);
    assignin('base', trajName, trajectories_filtered_all);
    assignin('base', cummdistrName, cummDistrMovie_all);
    
    
    
    
    
    cells=[];
    cd(expPath);
    save('workspace.mat');
    cd([filenameBase '\workspace\']);
    save(['workspace_' num2str(i) '.mat']);
    overlayTracksMovie_auto_110522(tracksFinalFiltered,imageNumStartEnd,[-2],1,'cell_144_test.avi',[],[],1,0,[ 1 512;1 512],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto_new(tracksFinal,[1 300],[],1,'cell_2.mov',[],[],1,0,[1 200; 156 356],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto_new(tracksFinal,[1 300],[],1,'cell_3.mov',[],[],1,0,[1 200; 312 512],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto_new(tracksFinal,[1 300],[],1,'cell_4.mov',[],[],1,0,[156 356; 1 200],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto_new(tracksFinal,[1 300],[],1,'cell_5.mov',[],[],1,0,[156 356; 156 356],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto_new(tracksFinal,[1 300],[],1,'cell_6.mov',[],[],1,0,[156 356; 312 512],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto_new(tracksFinal,[1 300],[],1,'cell_7.mov',[],[],1,0,[312 512; 1 200],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto_new(tracksFinal,[1 300],[],1,'cell_8.mov',[],[],1,0,[312 512; 156 356],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto_new(tracksFinal,[1 300],[],1,'cell_9.mov',[],[],1,0,[312 512; 312 512],0,[],[],2,1);
    
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 30],[],1,'cell_1.mov',[],[],1,0,[1 200; 1 200],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_2.mov',[],[],1,0,[1 200; 156 356],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_3.mov',[],[],1,0,[1 200; 312 512],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_4.mov',[],[],1,0,[156 356; 1 200],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_5.mov',[],[],1,0,[156 356; 156 356],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_6.mov',[],[],1,0,[156 356; 312 512],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_7.mov',[],[],1,0,[312 512; 1 200],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1 500],[],1,'cell_8.mov',[],[],1,0,[312 512; 156 356],0,[],[],2,1);
    %overlayTracksMoviePsfBgr_auto(tracksFinalFiltered,[1
    %500],[],1,'cell_9.mov',[],[],1,0,[312 512; 312 512],0,[],[],2,1);
    %save('tracksFinalFiltered','-mat');
    %save('trajectories','-mat');
    %save('cells','-mat');
    clear(trajName_start20,trajName,cummdistrName_start20,cummdistrName);
    %catch
    disp(['error in   ' expPath]);      
    %end
end

