function [bgMean,bgStd,bgrArea] = getLocalBackGround_DNA_120522(imageLast5,localMax,offsetSizeBgrBox)

%global expPath
%This function calculates the background in two boxes
%separated in y from the cluster by -/+offsetSizeBgrBox(1) and has a size
%of (offsetSizeBgrBox(1)+1)^2

%This file is part of u-track.
%
%    u-track is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%    u-track is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with u-track.  If not, see <http://www.gnu.org/licenses/>.
%
%
%Copyright: Khuloud Jaqaman 01/2008

imageSize=size(imageLast5);
imageDummy=nan(imageSize(1),imageSize(2));
offset=offsetSizeBgrBox(1);
boxSize=offsetSizeBgrBox(2);


[numMax,dummy]=size(localMax);%%%number of maxima in cluster

%initializing size of template
sizeT=numMax*2*(2*boxSize+1)^2;
%imageLocal = NaN(sizeT,1);

%expected that detected molecules are on a line in Y-direction
meanPosY=round(mean(localMax(:,2)));


    


%maxPosY=round(min(max(localMax(:,1)+boxSize),imageSize(1)));
%minPosY=round(max(min(localMax(:,1)-boxSize),1));

%set box boundaries in x-direction
iPixelXMax=round(min(max(localMax(:,1)+boxSize),imageSize(2)));
iPixelXMin=round(max(min(localMax(:,1)-boxSize),1));

%set box boundaries in y-direction
iPixelYMin(1) = max(offset+meanPosY,1); 
iPixelYMax(1)= min(offset+meanPosY+2*boxSize,imageSize(1));


iPixelYMin(2) = max(meanPosY-offset-2*boxSize,1); 
iPixelYMax(2)= min(meanPosY-offset,imageSize(1));


count=0;


%go over all pixels within limits
for k=1:2
    for iPixelY= iPixelYMin(k):iPixelYMax(k)       
        for iPixelX = iPixelXMin : iPixelXMax
            count=count+1;
            %imageLocal(count)=imageLast5(iPixelY,iPixelX);
            imageDummy(iPixelY,iPixelX)=imageLast5(iPixelY,iPixelX);   
        end
     end
end

%clean up nan's

bgrArea=find(~isnan(imageDummy));



imageDummy(isnan(imageDummy))=[];
%Determine background         
if ~isempty(imageDummy)
    [bgMean,bgStd] = robustMean(imageDummy(:)); 
else
    disp('Background calculation failed  - isEpmty');
    bgMean = NaN;
    bgStd = NaN;
end
