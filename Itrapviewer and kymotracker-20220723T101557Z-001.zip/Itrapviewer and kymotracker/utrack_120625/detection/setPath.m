%creates global variable for a selected path 
global expPath
expPath=[uigetdir('C:\','select folder containing fluorescent images to be tracked') '/'];


