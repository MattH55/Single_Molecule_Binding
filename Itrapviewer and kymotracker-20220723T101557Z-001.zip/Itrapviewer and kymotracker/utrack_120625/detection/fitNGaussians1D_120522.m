function [F,J] = fitNGaussians1D(x0,image,index,bgAmp)
%FITNGAUSSIANS2D yields F, the difference between an image and a theoretical image produced by N Gaussians, and J, the Jacobian of F.
%
%SYNOPSIS [F,J] = fitNGaussians2D(x0,image,index,psfSigma)
%
%INPUT  x0      : initial guess of PSF positions and amplitudes and
%                 background noise.
%       image   : Image part being analyzed.
%       index   : x,y-indices of pixels considered.
%       psfSigma: Standard deviation of point spread function (nm).

%OUTPUT F       : Residuals from fitting an image with supplied
%                 Gaussians.
%       J       : The Jacobian matrix of F.
%       errFlag : 0 if function executes normally, 1 otherwise.
%
%This file is part of u-track.
%
%    u-track is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%    u-track is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with u-track.  If not, see <http://www.gnu.org/licenses/>.
%
%
%Copyright: Khuloud Jaqaman, August 2005

%% Output

F = [];
J = [];

%% Input

%check whether correct number of input arguments was used
if nargin ~= 4
    disp('--fitNGaussians2D: Incorrect number of input arguments!');
    return
end

%% Calculating F & J
%%%disp('inGaussian');
%extract background intensity from x0 and remove from vector
%%%bgAmp = x0(end);
x0 = x0(1:end);

%get number of PSFs considered
numPSF = length(x0);
%%disp('x0');
%%disp(x0);
%%disp('numPSF');
%%disp(numPSF);
%disp('dummy');
%disp(dummy);

numPSF=int8(numPSF/4);
%%%disp('numPSF');
%%%disp(numPSF);
%reshape 3nx1 vector x0 into nx3 matrix
%%%disp('numPSF_fitNG');
%%%disp(numPSF);
%%disp('x0');
%%disp(x0);


x0 = reshape(x0,4,numPSF);
x0 = x0';
%%%disp('inGaussian2');

%extract PSF center positions and amplitudes
psfPos = x0(:,1:2);
psfAmp = x0(:,3);
psfSigm = x0(:,4);
%disp('psfPos');
%disp(psfAmp);
%disp(psfPos);
%disp(psfSigm);


%%%disp('inGaussian3');
%find minimum and maximum pixel indices
minIndxX = min(index(:,1));
maxIndxX = max(index(:,1));
minIndxY = min(index(:,2));
maxIndxY = max(index(:,2));

%determine the contribution of each PSF (assuming amplitude 1) to a 
%pixel based on its x-coordinate (needed to calculate F & J)

%%%creates gauss along x axis through center of locMax but relatively
%%%to the y position this applies to every x-line!!!! 

psfIntegX = zeros(maxIndxX-minIndxX+1,numPSF);
for i=1:numPSF
    %%%disp('-------------------------------------------------------');
    %%%disp('start');
    %%%disp('list');
    x=(minIndxX:maxIndxX)';
    %%%disp(x);
    %%%disp('pos');
    %%%disp(psfPos(i,1));
    %%%disp('psf');
    %%%disp(psfSigm(i));
    psfIntegX(:,i) = GaussListND((minIndxX:maxIndxX)',...
        psfSigm(i),psfPos(i,1));
    %%%disp('result');
    %%%disp(psfIntegX(:,i));%%%array of gauss intens values
    %%%disp('end');
    
end


%determine the contribution of each PSF (assuming amplitude 1) to a 
%pixel based on its y-coordinate (needed to calculate F & J)

%%%creates gauss along y axis through center of locMax

%%%disp('inGaussianStart');

psfIntegY = zeros(maxIndxY-minIndxY+1,numPSF);
for i=1:numPSF
    psfIntegY(:,i) = GaussListND((minIndxY:maxIndxY)',...
    psfSigm(i),psfPos(i,2));
    
end

%%%disp('inGaussianEnd');

%calculate the value of each PSF (assuming amplitude 1) at the 
%x-coordinates of the corners of all pixels (needed to calculate J)

%%%creates gauss along x axis through center of locMax but at the position
%%%inbetween two pixels but relatively
%%%to the y position this applies to every x-line!!!! 


psfValueX = zeros(maxIndxX-minIndxX+2,numPSF);
for i=1:numPSF
    psfValueX(:,i) = exp(-((minIndxX-0.5:maxIndxX+0.5)'...
        -psfPos(i,1)).^2/2/psfSigm(i)^2);
   
end



%calculate the value of each PSF (assuming amplitude 1) at the
%y-coordinates of the corners of all pixels (needed to calculate J)

%%%creates gauss along x axis through center of locMax but at the position
%%%inbetween two pixels

psfValueY = zeros(maxIndxY-minIndxY+2,numPSF);
for i=1:numPSF
    psfValueY(:,i) = exp(-((minIndxY-0.5:maxIndxY+0.5)'...
        -psfPos(i,2)).^2/2/psfSigm(i)^2);
    
end
%%%disp('psfValueY');
%%%disp(psfValueY);


%get number of pixels in image
numPixel = length(image);
%disp('size(image)');
%disp(size(image));

%get xy-indices relative to minimum
relIndxX = index(:,1) - minIndxX + 1;
relIndxY = index(:,2) - minIndxY + 1; 

indX=zeros(numPSF,length(index(:,1)));
for i=1:numPSF
    indX(i,:)=index(:,1)-psfPos(i,1);
end

indY=zeros(numPSF,length(index(:,2)));
for i=1:numPSF
    indY(i,:)=index(:,2)-psfPos(i,2);
end
%%%disp(indX);
%%%disp(indY);
indSqrt=indX.*indX+indY.*indY;
for i=1:numPSF
    indSqrt(i,:)=indSqrt(i,:)/psfSigm(i)^3;
end
%calculate the value of F at all pixels
%%% F(singlePixel)=Amp*xContr*yContr+backGroung-image(singlePixel)
%%% sum applies in case of multiple gaussians in one cluster
%disp('sdsd');
%disp((sum(repmat(psfAmp,1,numPixel).*psfIntegX(relIndxX,:)'.*psfIntegY(relIndxY,:)',1))'+ repmat(bgAmp,numPixel,1));
%disp(image);
F = (sum(repmat(psfAmp,1,numPixel).*psfIntegX(relIndxX,:)'.*psfIntegY(relIndxY,:)',1))' ...
    + repmat(bgAmp,numPixel,1) - image;

%%%disp('repmat(psfAmp,1,numPixel)');
%%%disp(repmat(psfAmp,1,numPixel));
%%%disp('psfIntegX(relIndxX,:)');
%%%disp(psfIntegX(relIndxX,:)');
%%%disp('psfIntegX(relIndxY,:)');
%%%disp(psfIntegY(relIndxY,:)');


%disp('repmat(psfAmp,1,numPixel).*psfIntegX(relIndxX,:)');
x=repmat(psfAmp,1,numPixel).*psfIntegX(relIndxX,:)'.*psfIntegY(relIndxY,:)';
%disp(x');
%disp(image);
%%%disp('-------------------------------------------------------');


%disp('inGaussian8');
%calculate the derivative at all pixels
J = ones(numPixel,4*numPSF); %(last column for background amplitude)
%disp(numPixel);
%disp(J);
%disp(repmat(psfAmp',numPixel,1).*(psfValueX(relIndxX,:)-...
    %psfValueX(relIndxX+1,:)).*psfIntegY(relIndxY,:));
J(:,1:4:4*numPSF) = repmat(psfAmp',numPixel,1).*(psfValueX(relIndxX,:)-...
    psfValueX(relIndxX+1,:)).*psfIntegY(relIndxY,:); %w.r.t. x
J(:,2:4:4*numPSF) = repmat(psfAmp',numPixel,1).*(psfValueY(relIndxY,:)-...
    psfValueY(relIndxY+1,:)).*psfIntegX(relIndxX,:); %w.r.t. y
J(:,3:4:4*numPSF) = psfIntegX(relIndxX,:).*psfIntegY(relIndxY,:); %w.r.t. amp
%%%disp('psfSigma');
%%%disp(psfSigm);
%%%disp('indSqrt(:,:)');
%%%disp(indSqrt(:,:)');
J(:,4:4:4*numPSF) = repmat(psfAmp',numPixel,1).*psfIntegX(relIndxX,:).*psfIntegY(relIndxY,:).*indSqrt(:,:)';
%disp(J);
%disp('inGaussian9');
%remove pixels with NaN (which means they are out of the cropped image
%area)
indxPixel = find(~isnan(image));
F = F(indxPixel);
J = J(indxPixel,:);
%imtool(F);
%disp('inGaussian10');
%disp(F);
%%%disp(J(:,1:3:3*numPSF));
%%%disp(J);
%%%disp(indSqrt);
%% ~~ the end ~~ 




%% OLD CODE

% % J = ones(numPixel,3*numPSF+1);
% % F = ones(numPixel,1);
% % 
% % for i=1:numPixel %for each pixel
% % 
% %     %get xy-indices relative to minimum
% %     relIndxX = index(i,1) - minIndxX + 1;
% %     relIndxY = index(i,2) - minIndxY + 1;
% %     
% %     %calculate the value of F
% %     F(i) = sum(psfAmp.*psfIntegX(relIndxX,:)'.*psfIntegY(relIndxY,:)') ...
% %         + bgAmp - image(i);
% % 
% %     %calculate the derivative wrt x-coordinate
% %     J(i,1:3:3*numPSF) = psfAmp'.*(psfValueX(relIndxX,:)-...
% %         psfValueX(relIndxX+1,:)).*psfIntegY(relIndxY,:)/psfSigma^2;
% % 
% %     %calculate the derivative wrt y-coordinate
% %     J(i,2:3:3*numPSF) = psfAmp'.*(psfValueY(relIndxY,:)-...
% %         psfValueY(relIndxY+1,:)).*psfIntegX(relIndxX,:)/psfSigma^2;
% % 
% %     %calculate the derivative wrt amplitude
% %     J(i,3:3:3*numPSF) = psfIntegX(relIndxX,:).*psfIntegY(relIndxY,:);
% % 
% %     %since the derivative wrt background intensity = 1, this is already
% %     %accounted for in the initial assignment of J.
% %     
% % end



