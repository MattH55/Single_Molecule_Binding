
imageStack=imread('C:\experimentsVU\diffusion test1\boundaryOverlay\img_000000001.tif');
h=imshow(imageStack);
xlim([0 10]);
ylim([0 10]);
hold on;
set(gcf, 'Position', [100 100 612 612]);

clf;
imageStack=imread('C:\experimentsVU\diffusion test1\boundaryOverlay\img_000000001.tif');
h=imshow(imageStack);
xlim([0 10]);
ylim([0 10]);
hold on;
set(gcf, 'Position', [100 100 612 612]);