
global expPath;
expPath='C:\tfromTest\test\selectionNew\test2\';
[ imageArray,imageRange,imageRange2 ] = selectImageRegions_1(  );
[movieInfo]=detectBeads_1(imageArray);
overlayPositions(movieInfo,[],[],1,'test3.mov');
pointToPoint=zeros(1,2);
openvar('pointToPoint');
h=msgbox('Enlist corresponding numbers in rows of "pointToPoint" vaiable, then call "transform( movieInfo,pointToPoint )"' ,'Bead identification','help');
pointToPoint=zeros(1,2);
openvar(pointToPoint);
