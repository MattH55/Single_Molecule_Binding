function [ output_args ] = rename( input_args )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

path=[uigetdir('C:\Users\Fos\Documents\MATLAB\utrack\','select folder containing fluorescent images to be tracked') '/'];
cd(path);
dirData = dir('*.tif');         %# Get the selected file data
fileNames = {dirData.name};     %# Create a cell array of file names
for iFile = 1:numel(fileNames)  %# Loop over the file names
  newName = sprintf('img_%04d.jpg',iFile);  %# Make the new name
  movefile(fileNames{iFile},newName);        %# Rename the file
end

end

