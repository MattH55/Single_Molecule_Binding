function [ ] = plotCummL( input )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


f={'mo','ro','bo','ms','rs','bs','m*','r*','b*','rs','bs','m*','r*','b*'};


j=0;
figure
for i=1:length(input)
    j=j+1;
    if j==14
        j=1;
    end
    %disp(f);
    semilogy(input(i).twoStep(:,1),input(i).twoStep(:,2),char(f(j)),'MarkerSize',3);
    hold on
    
end
axis([0 0.2 0.01 1])
end
