function [ ] = plotCummL( input )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


f={'ko','ro','bo','go','yo','mo','co','ks','rs','bs','gs','ys','ms','cs','k*','r*','b*','g*','y*','m*','c*'};

m=size(f);
j=0;
figure
for i=1:length(input)
    j=j+1;
    if j==22
        j=1;
    end
    %disp(f);
    semilogy(input(i).twoStep(:,1),input(i).twoStep(:,2),char(f(j)),'MarkerSize',3);
    hold on
    
end
axis([0 0.2 0.01 1])
end
