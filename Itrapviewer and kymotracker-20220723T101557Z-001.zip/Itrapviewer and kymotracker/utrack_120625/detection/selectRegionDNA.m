function [ kymo , background , bitDepth] = selectRegionDNA(roiFullFlag, path )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
global expPath

if nargin<1
    roiFullFlag=0;
    if  exist('expPath')==0 || exist('expPath')==2 || isempty(expPath)
        imageDir='C:\';
    else
        imageDir=expPath;
    end
elseif nargin==1
    if  exist('expPath')==0 || exist('expPath')==2 || isempty(expPath)
        imageDir='C:\';
    else
        imageDir=expPath;
    end
else
    imageDir=path;
end
    
%ask user for images
try
    [fName,dirName] = uigetfile([imageDir '*.tif'],'specify first image in the stack - specify very first image, even if not to be plotted');
catch
     imageDir='C:\';
      [fName,dirName] = uigetfile([imageDir '*.tif'],'specify first image in the stack - specify very first image, even if not to be plotted');
end
expPath=dirName;
imageROI=imread([dirName fName]);
if strcmp(class(imageROI),'uint8')
    bitDepth=8;
elseif strcmp(class(imageROI),'uint16')
    bitDepth=16;
end
intMinMax=[min(min(imageROI)) max(max(imageROI))];
t1=figure;
if roiFullFlag, txt='double-click to continue';
else, txt='Draw ROI and double-click to continue.';
end
imshow(imageROI,intMinMax),title(txt);
h = imrect;
position = wait(h);
status=0;
while status==0
    status=close(t1);
end
%hold off;
%clf;
if roiFullFlag
    imageRange(2,1)=1;
    imageRange(2,2)=size(imageROI,2);
    imageRange(1,1)=1;
    imageRange(1,2)=size(imageROI,1);
else
imageRange(2,1)=max(position(1),1);
imageRange(2,2)=min(position(1)+position(3),size(imageROI,2));
imageRange(1,1)=max(position(2),1);
imageRange(1,2)=min(position(2)+position(4),size(imageROI,1));
end

kymo=imageROI(imageRange(1,1):imageRange(1,2),imageRange(2,1):imageRange(2,2));
kymo=double(kymo) / (2^bitDepth-1);

t1=figure;
imshow(imageROI,intMinMax),title('Draw background ROI');
hrect=rectangle('position',position,'edgecolor','y','hittest','off');
h = imrect;
position = wait(h);
status=0;
while status==0
    status=close(t1);
end
%hold off;
%clf;
bgRange(2,1)=max(position(1),1);
bgRange(2,2)=min(position(1)+position(3),size(imageROI,2));
bgRange(1,1)=max(position(2),1);
bgRange(1,2)=min(position(2)+position(4),size(imageROI,1));

background=bgRange;
bgkymo=imageROI(bgRange(1,1):bgRange(1,2),bgRange(2,1):bgRange(2,2));
bgkymo=double(bgkymo)/ (2^bitDepth-1);
bgMean=mean(bgkymo(:));
bgStd=std(double(bgkymo(:)));
background=struct('bgMean',bgMean,'bgStd',bgStd);
% dirNameMask=[dirName 'mask\'];
% disp(dirNameMask);
% 
% mkdir(dirNameMask);
% 
% [xpixel,ypixel]=size(imageROI);
% disp(size(imageROI));
% mask=zeros(xpixel,ypixel);
% %imshow(mask);
% imwrite(im2bw(mask),[dirNameMask 'mask2.tif'],'tif');
% mask(imageRange(1,1):imageRange(1,2),imageRange(2,1):imageRange(2,2))=1;
% %for i=imageRange(2,1):imageRange(2,2)
% %    for j=imageRange(1,1):imageRange(1,2)
% %        mask(i,j)=1;
% %    end
% %end
% 
% imwrite(im2bw(mask),[dirNameMask 'mask.tif'],'tif');
% 
% 

end

