function [intensity] = getLocalIntens_110522(imageLast5,localMax,background)

%the function in its current form assigns blocks of 11x11 pixels the
%same background values, for the sake of speed

%This file is part of u-track.
%
%    u-track is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%    u-track is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with u-track.  If not, see <http://www.gnu.org/licenses/>.
%
%
%Copyright: Khuloud Jaqaman 01/2008

imageSize=size(imageLast5);
innerRadius=3;
outerRadius=5;
%%%disp('getLocalBackground');
sizeT=uint16(3.14159265*(outerRadius^2-innerRadius^2));
imageLocal = NaN(sizeT,1);
count=0;

minX=1;     % Iddo HACK
minY=1;
maxX=imageSize(1);
maxY=imageSize(2);
% maxPosY=min(512,round(localMax(:,1)'+innerRadius+1));
% maxPosX=min(512,round(localMax(:,2)'+innerRadius+1));
% minPosY=max(1,round(localMax(:,1)'-innerRadius-1));
% minPosX=max(1,round(localMax(:,2)'-innerRadius-1));

maxPosY=min(maxY,round(localMax(:,1)'+innerRadius+1));   % Iddo Hack
maxPosX=min(maxX,round(localMax(:,2)'+innerRadius+1));
minPosY=max(minY,round(localMax(:,1)'-innerRadius-1));
minPosX=max(minX,round(localMax(:,2)'-innerRadius-1));
    
   
%%%disp('localMax');
%%%disp(localMax);
%%%disp('localMax(:,1)');
%%%disp(localMax(:,1));
%%%disp('imageSize');
%%%disp(imageSize);
%%%disp('maxPosY');
%%%disp(maxPosY);
%%%disp('minPosY');
%%%disp(minPosY);
%%%disp('maxPosX');
%%%disp(maxPosX);
%%%disp('minPosX');
%%%disp(minPosX);

%%%get the limits of the cluster
%iPixelYMin=round(max(min(minPosY),1));
%%iPixelXMin=round(max(min(minPosX),1));
%iPixelXMax=round(min(max(maxPosX),imageSize(2)));

%%%disp('iPixelYMin');
%%%disp(iPixelYMin);
%%%disp('iPixelYMax');
%%%disp(iPixelYMax);
%%%disp('iPixelXMin');
%%%disp(iPixelXMin);
%%%disp('iPixelXMax');
%%%disp(iPixelXMax);


[numMax,dummy]=size(localMax);%%%number of maxima in cluster
r=zeros(numMax,1);
    %%%iPixelYMin(max)=max(localMaxPosY-outerRadius,1);
    %%%iPixelYMax(max)=min(localMaxPosY+outerRadius,imageSizeY);
    %%%iPixelXMin=max(localMaxPosX-outerRadius,1);
    %%%iPixelXMax=min(localMaxPosX+outerRadius,imageSizeX);
    
%%%disp('iPixelYMin');
%%%disp(iPixelYMin);
%%%disp('iPixelYMax');
%%%disp(iPixelYMax);
%%%disp('iPixeXMin');
%%%disp(iPixelXMin);
%%%disp('iPixelXMin');
%%%disp(iPixelXMax);
%go over all pixels within limits
intensity=zeros(numMax,1);
%disp('localMax');

%disp(localMax);
%disp('bgr');

%disp(background);

for i=1:numMax
    for iPixelY=minPosY(i):maxPosY(i)
        for iPixelX=minPosX(i):maxPosX(i)
            r(i)=sqrt((iPixelX-localMax(i,2))^2+(iPixelY-localMax(i,1))^2);
            if r(i)<=innerRadius  
              intensity(i)=max(0,intensity(i)+imageLast5(iPixelX,iPixelY)-background(i,1));
            end
        end
    end
end


