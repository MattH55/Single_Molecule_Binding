This is the "TDMS Reader" (by Jim Hokanson) from the MATLAB Central File Exchange

Version 2.5, as downloaded from:
  http://www.mathworks.com/matlabcentral/fileexchange/30023-tdms-reader