function [ movieInfo,exceptions,localMaxima,background,psfSigma ] = ...
    detectGeneralDNA_kymotracker( kymo, bgParam,pixelsize,exclambda,alpha)
%This file is part of u-track.
%
%    u-track is free software: you can redistribute it and/or modify
%    it under the terms of the GNU General Public License as published by
%    the Free Software Foundation, either version 3 of the License, or
%   (at your option) any later version.
%
%    u-track is distributed in the hope that it will be useful,
%    but WITHOUT ANY WARRANTY; without even the implied warranty of
%    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%    GNU General Public License for more details.
%
%    You should have received a copy of the GNU General Public License
%    along with u-track.  If not, see <http://www.gnu.org/licenses/>.
%
%Copyright Jaqaman 01/08

%% movie information
%% Iddo Hack, TBD% 
% %movieParam.imageDir = 'C:/Users/Felix/Documents/MATLAB/u-track/andrea1/'; %directory where images are
 global expPath

movieParam.imageDir = expPath; %directory where images are
movieParam.filenameBase = 'img_'; %image file name base
movieParam.firstImageNum= 1; %number of first image in movie
movieParam.lastImageNum = size(kymo,2); %number of last image in movie
movieParam.digits4Enum = 4; %number of digits used for frame enumeration (1-4).
movieParam.kymo=kymo;       % Iddo Hack
movieParam.bg=bgParam;      % Iddo Hack


%% detection parameters

%Camera bit-depth
detectionParam.bitDepth = 1;%max(kymo(:));

%The standard deviation of the point spread function is defined
%as 0.21*(emission wavelength)/(numerical aperture). If the wavelength is
%given in nanometers, this will be in nanometers. To convert to pixels,
%divide by the pixel side length (which should also be in nanometers).
detectionParam.psfSigma = 0.21*exclambda/1.27/pixelsize;%1.3;

%Boundaries in pixels for sigma fit
detectionParam.psfSigmaMinMax = [0.5 3];

%For tracking on DNA - flag for detcting local background with box 
%above and below the DNA for detecting local background, set to 2 for
%kymo's that use general bg and std param
detectionParam.bgrDetectBoxFlag = 2;

%distance from DNA and half the width of background detection box in pixels
detectionParam.offsetSizeBgrBox = [5 1];

%inner and outer radius in pixels for local background detection disk
detectionParam.bgrRadiusMinMax = [3 1];

%Parameters for detecting background by moving rectangle in "first value" and "second value" size
detectionParam.spatMovBgrParam = [11 1];



%Number of frames before and after a frame for time averaging
%For no time averaging, set to 0
detectionParam.integWindow = 0;

%Alpha-value for initial detection of local maxima
detectionParam.alphaLocMax = alpha.L;

%Maximum number of iterations for PSF sigma estimation for detected local
%maxima
%To use the input sigma without modification, set to 0
detectionParam.numSigmaIter = 0;

%1 to attempt to fit more than 1 kernel in a local maximum, 0 to fit only 1
%kernel per local maximum
%If psfSigma is < 1 pixel, set doMMF to 0, not 1. There is no point
%in attempting to fit additional kernels in one local maximum under such
%low spatial resolution
detectionParam.doMMF = 0;

%1 update background area before final fitting, 0 no update
detectionParam.bgrUpdateFlag = 0;

%Alpha-values for statistical tests in mixture-model fitting step
%detectionParam.testAlpha = struct('alphaR',0.001,'alphaA',0.001,'alphaD',0.001,'alphaF',0);
detectionParam.testAlpha = struct('alphaR',alpha.R,'alphaA',alpha.A,'alphaD',alpha.D,'alphaF',alpha.F);

%1 to visualize detection results, frame by frame, 0 otherwise. Use 1 only
%for small movies. In the resulting images, blue dots indicate local
%maxima, red dots indicate local maxima surviving the mixture-model fitting
%step, pink dots indicate where red dots overlap with blue dots
detectionParam.visual = 0;

%1 to visualize background detection areas, frame by frame, 0 otherwise. Use 1 only
%for small movies. In the resulting images, blue dots indicate local
%maxima, red dots indicate local maxima surviving the mixture-model fitting
%step, pink dots indicate where red dots overlap with blue dots
detectionParam.visualBgr = 0;
% 


%% run the detection function

[movieInfo,exceptions,localMaxima,background,psfSigma] = ...
    detectSubResFeaturesDNA_StandAlone_kymotracker(movieParam,detectionParam,0);

% figure, hold on
% plot(kymo);
% plot(movieInfo.yCoord,movieInfo.amp,'o')

