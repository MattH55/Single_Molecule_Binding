function [trajectories]=getTrajIntAmpPsfBgr_DNA1410_1(tracks,traj,start)

global kdata




%% Output

tracksFinalFiltered    = [];
amp=[];
bgr=[];
psf=[];
intens=[];
xC=[];
yC=[];

%%


numTracks=size(tracks,1);

if length(tracks)==0
    trajectories = [];
return
end
trajCoord = repmat(struct('xMax','yMax','xMin','yMin'),numTracks,1);

trajectories = repmat(struct('i',[],'t',[],'x',[],'y',[],'rSqrd',[],'rSqrdUm',[],...
    'amp',[],'bgr',[],'psf',[],'intens',[],'int_gauss',[],'int_loc',[],...
    'int_gauss_2pi',[],'int_loc_2pi',[],'meanSqrd',[],...
    'maxInt',[],'maxInt_gauss',[],'maxInt_loc',[],'maxInt_gauss_2pi',[],'maxInt_loc_2pi',[],'maxAmp',[],'maxPsf',[],...
    'mean5Int',[],'mean5Int_gauss',[],'mean5Int_loc',[],'mean5Int_gauss_2pi',[],'mean5Int_loc_2pi',[],'mean5Amp',[],...
    'meanFullInt',[],'meanFullInt_gauss',[],'meanFullInt_loc',[],'meanFullInt_gauss_2pi',[],'meanFullInt_loc_2pi',[],...
    'mean5MaxInt',[],'mean5MaxInt_gauss',[],'mean5MaxInt_loc',[],'mean5MaxInt_gauss_2pi',[],'mean5MaxInt_loc_2pi',[],...
    'frames',[],'trajNum',[],...
    'range',[],'linkNext',[],'linkPrevious',[],'seqOfEvents',[]),numTracks,1);

segmentsSqrd = repmat(struct('xSqrd',[],...
    'ySqrd',[],'rSqrd',[],'meanRSqrd',[]),numTracks,1);

if nargin<2 || isempty(traj)
    numTracks=size(tracks,1);
    tracksFilter=tracks;
    traj=1:1:numTracks;
else
    disp('hhahahhahaha');
    numTracks=numel(traj);
    tracksFilter = repmat(struct('tracksFeatIndxCG',[],...
            'tracksCoordAmpCG',[],'seqOfEvents',[]),numTracks,1);
  
    for i=1:numTracks
        tracksFilter(i)=tracks(traj(i));
    end
end
trackSel=getTrackSELPsfBgr(tracks);



ampTraj=zeros(numTracks,100);
l=0;

for k=1:numTracks
    ll=0;
    trajectories(k).trajNum=traj(k);
    trajectories(k).seqOfEvents=tracksFilter(k).seqOfEvents;
    trajCoord(k).xMin=512;
    trajCoord(k).yMin=512;
    trajCoord(k).xMax=0;
    trajCoord(k).yMax=0;
    
    index=0;
    for j=1:trackSel(k,3)-1
               
        if isnan(tracksFilter(k).tracksCoordAmpCG(1,j*12+1)) || isnan(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1))
            
            segmentsSqrd(k).xSqrd(j)=0;
            segmentsSqrd(k).ySqrd(j)=0;
            segmentsSqrd(k).rSqrd(j)=0;
            trajectories(k).rSqrd(j)=0;
            trajectories(k).rSqrdUm(j)=0;
        else
            
            index=index+1;
            xSqrd=(tracksFilter(k).tracksCoordAmpCG(1,j*12+1)...
                -tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1))^2;
            
            ySqrd=(tracksFilter(k).tracksCoordAmpCG(1,j*12+2)...
                -tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+2))^2;
            rSqrd=xSqrd+ySqrd;
            
            xxx=rSqrd;
                      
            segmentsSqrd(k).xSqrd(j)=xSqrd;
            segmentsSqrd(k).ySqrd(j)=ySqrd;
            segmentsSqrd(k).rSqrd(j)=rSqrd;
            trajectories(k).rSqrd(j)=rSqrd;
            trajectories(k).rSqrdUm(j)=rSqrd*0.08*0.08;
        end
    end
    for j=1:trackSel(k,3)
        
        ll=ll+1; 
        trajectories(k).frames(ll)=trackSel(k,1)-1+ll;
        if isnan(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1))
            
            trajectories(k).i(ll)=0;
            trajectories(k).t(ll)=0;
            trajectories(k).x(ll)=0;
            trajectories(k).y(ll)=0;
            trajectories(k).amp(ll)=0;
            trajectories(k).intens(ll)=0;
            trajectories(k).int_gauss(ll)=0;
            trajectories(k).int_corr(ll)=0;
            trajectories(k).int_gauss_pi(ll)=0;
            trajectories(k).int_corr_pi(ll)=0;
            trajectories(k).bgr(ll)=0;
            trajectories(k).psf(ll)=0;
            
            
            
        else
            l=l+1;
            
            %disp('   ');
            xC(ll)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1);
            yC(ll)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+2);
            xCoord=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1);
            yCoord=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+2);
            ampTraj(k,j)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+4);
            
            
            trajectories(k).i(ll)=trackSel(k,1)+j-1;

            trajectories(k).x(ll)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+1);
            trajectories(k).y(ll)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+2);
            trajectories(k).amp(ll)=(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+4));%*65536);
            trajectories(k).bgr(ll)=(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+11));%*65536);
            trajectories(k).psf(ll)=tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+9);
            
            trajectories(k).intens(ll)=round(trajectories(k).amp(ll)*trajectories(k).psf(ll));
            
            trajectories(k).int_gauss(ll)=round(trajectories(k).amp(ll)*(trajectories(k).psf(ll))^2);
            trajectories(k).int_gauss_2pi(ll)=round(trajectories(k).amp(ll)*(trajectories(k).psf(ll))^2*2*pi);
            
            trajectories(k).int_loc(ll)=round(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+3)*65536/(2*pi));
            trajectories(k).int_loc_2pi(ll)=round(tracksFilter(k).tracksCoordAmpCG(1,(j-1)*12+3)*65536);
            
            %disp('x');
            %disp(xCoord);
            %disp('y');
            %disp(yCoord);
            if xCoord<trajCoord(k).xMin
                trajCoord(k).xMin=xCoord;
                %disp('xMin');
                %disp(trajCoord(k).xMin);
                
                
            end
            if yCoord<trajCoord(k).yMin
                trajCoord(k).yMin=yCoord;
                 
                %disp('yMin');
                %disp(trajCoord(k).yMin);
            end
            if xCoord>trajCoord(k).xMax
                trajCoord(k).xMax=xCoord;
                 
                %disp('xMax');
                %disp(trajCoord(k).xMax);
            end
            if yCoord>trajCoord(k).yMax
                trajCoord(k).yMax=yCoord;
                 
                %disp('yMax');
                %disp(trajCoord(k).yMax);
            end
        end
    end
end

if nargin<3||isempty(start)||start<1
else
    for i=1:numTracks
        diff=start-trajectories(i).frames(1);
        if diff>0 
            if numel(trajectories(i).frames)>(diff+1)
            
                while trajectories(i).x(diff+1)==0
                    diff=diff+1;
                end
                if length(trajectories(i).frames)-(diff+1)<5
                    trajectories(i).frames=[];
                    trajectories(i).x=[];
                    trajectories(i).y=[];
                    trajectories(i).amp=[]; 
                    trajectories(i).intens=[];
                    trajectories(i).int_gauss=[];
                    trajectories(i).int_gauss_2pi=[];
                    trajectories(i).int_loc=[];
                    trajectories(i).int_loc_2pi=[];
                    trajectories(i).bgr=[];
                    trajectories(i).psf=[];
                    trajectories(i).rSqrd=[];
                    trajectories(i).rSqrdUm=[];
                else
                    trajectories(i).frames=trajectories(i).frames(diff+1:end);
                    trajectories(i).x=trajectories(i).x(diff+1:end);
                    trajectories(i).y=trajectories(i).y(diff+1:end);
                    trajectories(i).amp=trajectories(i).amp(diff+1:end); 
                    trajectories(i).intens=trajectories(i).intens(diff+1:end);
                    
                    trajectories(i).int_gauss=trajectories(i).int_gauss(diff+1:end);
                    trajectories(i).int_gauss_2pi=trajectories(i).int_gauss_2pi(diff+1:end);
                    trajectories(i).int_loc=trajectories(i).int_loc(diff+1:end);
                    trajectories(i).int_loc_2pi=trajectories(i).int_loc_2pi(diff+1:end);
                    
                    trajectories(i).bgr=trajectories(i).bgr(diff+1:end);
                    trajectories(i).psf=trajectories(i).psf(diff+1:end);
                    trajectories(i).rSqrd=trajectories(i).rSqrd(diff+1:end);
                    trajectories(i).rSqrdUm=trajectories(i).rSqrdUm(diff+1:end);
                end
            else
                trajectories(i).frames=[];
                trajectories(i).x=[];
                trajectories(i).y=[];
                trajectories(i).amp=[]; 
                
                trajectories(i).intens=[];
                trajectories(i).int_gauss=[];
                trajectories(i).int_gauss_2pi=[];
                trajectories(i).int_loc=[];
                trajectories(i).int_loc_2pi=[];
                
                trajectories(i).bgr=[];
                trajectories(i).psf=[];
                trajectories(i).rSqrd=[];
                trajectories(i).rSqrdUm=[];
                
            end
            
        end
    end
end


for i=1:numTracks
    if ~isempty(trajectories(i).rSqrd)
        rSqrd = trajectories(i).rSqrd(trajectories(i).rSqrd~=0);
        
        trajectories(i).meanSqrd=mean(rSqrd);
        trajectories(i).diffConstUm=(trajectories(i).meanSqrd*0.075*0.075/(2*0.032));
        trajectories(i).diffConstNm=(trajectories(i).meanSqrd*75*75/(2*32));
    else
        trajectories(i).meanSqrd=[];
        trajectories(i).diffConstUm=[];
        trajectories(i).diffConstNm=[];
    end
    
end

for i=1:numTracks
    if ~isempty(trajectories(i).rSqrd)
        trajectories(i).maxInt=max(trajectories(i).intens(:));
        
        trajectories(i).maxInt_gauss=max(trajectories(i).int_gauss(:));
        trajectories(i).maxInt_gauss_2pi=max(trajectories(i).int_gauss_2pi(:));
        trajectories(i).maxInt_loc=max(trajectories(i).int_loc(:));
        trajectories(i).maxInt_loc_2pi=max(trajectories(i).int_loc_2pi(:));
        
        trajectories(i).maxAmp=max(trajectories(i).amp(:));
        trajectories(i).maxPsf=max(trajectories(i).psf(:));
        trajectories(i).mean5Int=0;
        
        trajectories(i).mean5Int_gauss=0;
        trajectories(i).mean5Int_gauss_2pi=0;
        trajectories(i).mean5Int_loc=0;
        trajectories(i).mean5Int_loc_2pi=0;
        
        trajectories(i).mean5Amp=0;
        trajectories(i).meanFullInt=0;
        
        trajectories(i).meanFullInt_gauss=0;
        trajectories(i).meanFullInt_gauss_2pi=0;
        trajectories(i).meanFullInt_loc=0;
        trajectories(i).meanFullInt_loc_2pi=0;
        %lenTraj=length(trajectories(i).intens);
        ll=0;
        nonZeroEntries=trajectories(i).intens>0;
        nonZeroInt=trajectories(i).intens(nonZeroEntries);
        
        nonZeroInt_gauss=trajectories(i).int_gauss(nonZeroEntries);
        nonZeroInt_gauss_2pi=trajectories(i).int_gauss_2pi(nonZeroEntries);
        nonZeroInt_loc=trajectories(i).int_loc(nonZeroEntries);
        nonZeroInt_loc_2pi=trajectories(i).int_loc_2pi(nonZeroEntries);
        
        nonZeroAmp=trajectories(i).amp(nonZeroEntries);
        nonZeroPsf=trajectories(i).psf(nonZeroEntries);
        
        lenTraj=length(nonZeroInt);
        %for k=1:lenTraj
        %    if trajectories(i).intens(k)>0
        %        ll=ll+1;
        %        trajectories(i).meanFullInt=trajectories(i).meanFullInt+mean(trajectories(i).intens(k));
        %    end
        %end
        %trajectories(i).meanFullInt=trajectories(i).meanFullInt/ll;
        trajectories(i).meanFullInt=mean(nonZeroInt);
        
        trajectories(i).meanFullInt_gauss=mean(nonZeroInt_gauss);
        trajectories(i).meanFullInt_gauss_2pi=mean(nonZeroInt_gauss_2pi);
        trajectories(i).meanFullInt_loc=mean(nonZeroInt_loc);
        trajectories(i).meanFullInt_loc_2pi=mean(nonZeroInt_loc_2pi);
        
        trajectories(i).meanFullAmp=mean(nonZeroAmp);
        if lenTraj>4
            %ll=0;
            %for k=1:5
            %    if trajectories(i).intens(k)>0
            %    ll=ll+1;
            %    trajectories(i).mean5Int=trajectories(i).mean5Int+mean(trajectories(i).intens(k));
            %    trajectories(i).mean5Amp=trajectories(i).mean5Amp+mean(trajectories(i).amp(k));
            %    end
            %end
            %trajectories(i).mean5Int=trajectories(i).mean5Int/ll;
            %trajectories(i).mean5Amp=trajectories(i).mean5Amp/ll;
            trajectories(i).mean5Int=mean(nonZeroInt(1:5));
            
            trajectories(i).mean5Int_gauss=mean(nonZeroInt_gauss(1:5));
            trajectories(i).mean5Int_gauss_2pi=mean(nonZeroInt_gauss_2pi(1:5));
            trajectories(i).mean5Int_loc=mean(nonZeroInt_loc(1:5));
            trajectories(i).mean5Int_loc_2pi=mean(nonZeroInt_loc_2pi(1:5));
            
            
            trajectories(i).mean5Amp=mean(nonZeroAmp(1:5));
            
            nonZeroIntSort=sort(nonZeroInt,'descend');
            
            nonZeroIntSort_gauss=sort(nonZeroInt_gauss,'descend');
            nonZeroIntSort_gauss_2pi=sort(nonZeroInt_gauss_2pi,'descend');
            nonZeroIntSort_loc=sort(nonZeroInt_loc,'descend');
            nonZeroIntSort_loc_2pi=sort(nonZeroInt_loc_2pi,'descend');
            
            trajectories(i).mean5MaxInt=mean(nonZeroIntSort(1:5));
            
            trajectories(i).mean5MaxInt_gauss=mean(nonZeroIntSort_gauss(1:5));
            trajectories(i).mean5MaxInt_gauss_2pi=mean(nonZeroIntSort_gauss_2pi(1:5));
            trajectories(i).mean5MaxInt_loc=mean(nonZeroIntSort_loc(1:5));
            trajectories(i).mean5MaxInt_loc_2pi=mean(nonZeroIntSort_loc_2pi(1:5));
            
        else
            %ll=0;

            %for k=1:lenTraj

             %  if trajectories(i).intens(k)>0
             %   ll=ll+1;
            %    trajectories(i).mean5Int=trajectories(i).mean5Int+mean(trajectories(i).intens(k));
             %   trajectories(i).mean5Amp=trajectories(i).mean5Amp+mean(trajectories(i).amp(k));
            %    end
            %end
            trajectories(i).mean5Int=trajectories(i).meanFullInt;
            
            trajectories(i).mean5Int_gauss=trajectories(i).meanFullInt_gauss;
            trajectories(i).mean5Int_gauss_2pi=trajectories(i).meanFullInt_gauss_2pi;
            trajectories(i).mean5Int_loc=trajectories(i).meanFullInt_loc;
            trajectories(i).mean5Int_loc_2pi=trajectories(i).meanFullInt_loc_2pi;
            
            
            trajectories(i).mean5Amp=trajectories(i).meanFullAmp;
            
            
            trajectories(i).mean5MaxInt=trajectories(i).meanFullInt;
            
            trajectories(i).mean5MaxInt_gauss=trajectories(i).meanFullInt_gauss;
            trajectories(i).mean5MaxInt_gauss_2pi=trajectories(i).meanFullInt_gauss_2pi;
            trajectories(i).mean5MaxInt_loc=trajectories(i).meanFullInt_loc;
            trajectories(i).mean5MaxInt_loc_2pi=trajectories(i).meanFullInt_loc_2pi;
            
        end
    end
end

%ask user for images
%%%[fName,dirName] = uigetfile('*.tif','specify first image in the stack - specify very first image, even if not to be plotted');
if nargin<4 || isempty(extension)
    extension=30;
end
for i=1:numTracks
    
   if nargin<2 || isempty(traj)
        k=i;
   else
        k=traj(i);
   end
   %disp('minMaxPre');
   %disp(trajCoord(k).xMin);
   %disp(trajCoord(k).xMax);
   %disp(trajCoord(k).yMin);
   %disp(trajCoord(k).yMax);
   trajCoord(k).xMin=trajCoord(k).xMin-extension;
   trajCoord(k).yMin=trajCoord(k).yMin-extension;
   trajCoord(k).xMax=trajCoord(k).xMax+extension;
   trajCoord(k).yMax=trajCoord(k).yMax+extension;
   %disp('minMaxPre+extension');
   %disp(trajCoord(k).xMin);
   %disp(trajCoord(k).xMax);
   %disp(trajCoord(k).yMin);
   %disp(trajCoord(k).yMax);
   if trajCoord(k).xMin<1
       trajCoord(k).xMin=1;
   end
   if trajCoord(k).yMin<1
       trajCoord(k).yMin=1;
   end
   if trajCoord(k).xMax>512
       trajCoord(k).xMax=512;
   end
   if trajCoord(k).yMax>512
       trajCoord(k).yMax=512;
   end
   %disp('minMaxPost');
   %disp(trajCoord(k).xMin);
    %disp(trajCoord(k).xMax);
    %disp(trajCoord(k).yMin);
    %disp(trajCoord(k).yMax);
  
   %disp(imageRange);
   %disp(traj);
   %disp(k);
   %disp(traj(k));
   
   %sumY=0
   %for i=1:length(yC)
   %    if yC>0
   %        sumY=sumY+yC(i);
   %        sumX=sumX+xC(i);
   %    end
   %end
   
   %disp('stdXY');
   %disp(xStd);
   %disp(yStd);
   
       
           
   %%%if nargin<2 || isempty(traj)
   %%%     overlayTracksMovieNewMod(tracksFilter,imageRange,k,fName,dirName);
   %%%else
   %%%    overlayTracksMovieNewMod(tracksFilter,imageRange,k,fName,dirName);
       %overlayTracksMovieNewMod(tracksFilter,imageRange,traj(k),fName,dirName);
   %%%end
end


timelapse=kdata.pixdim(2)*kdata.sum(2)*1e-3;
pixsize=kdata.pixdim(1)*kdata.sum(1);
filterlength=4;
analysisPara=repmat(struct('timeLapse',timelapse,'pixelSize',pixsize,...
    'diffDim',1,'numTimeLags',3,'msdDispFlag',0,'trajFilterLength',4),1);
for i=1:length(trajectories)
    % find longest stretch:
    iok=trajectories(i).x;
    q=0; stretch=0;
    while (stretch<4)&(q<length(iok))
        q=q+1;
        stretch=stretch*iok(q)+iok(q);
    end
    if stretch>=4
%    if sum((trajectories(i).x(1:end-1)).*(trajectories(i).x(2:end)))>=3%(trajectories(i).y)>=4
        [ analysisData] = getCummOutTrajDNA( trajectories,i,analysisPara);
        msdanal(i)=analysisData;
    else
        msdanal(i)= repmat(struct('meanRsqrdSteps',[],'meanXsqrdSteps',[],'meanYsqrdSteps',[],...
                'RdiffConst',[],'XdiffConst',[],'YdiffConst',[],...
                'deltaRdiffConst',[],'deltaXdiffConst',[],'deltaYdiffConst',[],...
                'sigmaR',[],'sigmaX',[],'sigmaY',[],...
                'deltaSigmaR',[],'deltaSigmaX',[],'deltaSigmaY',[],...
                'cpdRsqrd',struct('displ',[]),'cpdXsqrd',struct('displ',[]),'cpdYsqrd',struct('displ',[]),...
                'RdiffConstSteps',[],'XdiffConstSteps',[],'YdiffConstSteps',[],'traj',[]),1);;
    end
end
kdata.msdanal=msdanal;
