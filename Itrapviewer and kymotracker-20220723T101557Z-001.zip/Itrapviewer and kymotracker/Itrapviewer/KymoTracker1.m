function varargout = KymoTracker1(varargin)

% KYMOTRACKER1 MATLAB code for KymoTracker1.fig
%      KYMOTRACKER1, by itself, creates a new KYMOTRACKER1 or raises the existing
%      singleton*.
%
%      H = KYMOTRACKER1 returns the handle to a new KYMOTRACKER1 or the handle to
%      the existing singleton*.
%
%      KYMOTRACKER1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in KYMOTRACKER1.M with the given input arguments.
%
%      KYMOTRACKER1('Property','Value',...) creates a new KYMOTRACKER1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before KymoTracker1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to KymoTracker1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help KymoTracker1

% Last Modified by GUIDE v2.5 03-Nov-2014 15:50:16

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @KymoTracker1_OpeningFcn, ...
                   'gui_OutputFcn',  @KymoTracker1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
if nargin && ischar(varargin{1})
    switch varargin{1}
        case 'restart'
            'restart'
            global data kdata
            kdata=data;
            handles=guidata(gcf);
            % modify third channel if 2 normsummed chans need tracking
            if isfield(kdata,'track2'), if kdata.track2, if sum(kdata.chdisp)==2
                        isum=find(kdata.chdisp==1); % two channels to be summed
                        i3rd=find(kdata.chdisp==0); % third channel to store sum
                        kdata.im(:,:,i3rd)=kdata.im(:,:,isum(1))*kdata.cst(isum(2))+...
                            kdata.im(:,:,isum(2))*kdata.cst(isum(1));
                        kdata.cst(i3rd)=2*prod(kdata.cst(isum));
                        kdata.chdisp=~kdata.chdisp;
            end, end, end
    switch kdata.exportformat
        case '.txt'
            set(handles.exportformattxt,'checked','on');
            set(handles.exportformatxls,'checked','off');
        case '.xls'
            set(handles.exportformatxls,'checked','on');
            set(handles.exportformattxt,'checked','off');
    end
            kdata.action='zoom';
            kdata.npixforI=7;
            kdata.handles=handles;
            set(handles.trackroibutton,'value',1);
            kdata.selecttrackingroi=1;
            kdata.tracktojoin=[];
            kdata.hchdisp=[handles.chdisp1,handles.chdisp2,handles.chdisp3];
            kdata.hcst=[handles.cst1,handles.cst2,handles.cst3];
            kdata.hautocst=[handles.autocst1,handles.autocst2,handles.autocst3];
            set(handles.aspectedit,'string',get(data.handles.aspectedit,'string'));
            set(handles.chdisp1,'value',kdata.chdisp(1));
            set(handles.chdisp2,'value',kdata.chdisp(2));
            set(handles.chdisp3,'value',kdata.chdisp(3));
            set(handles.cst1,'string',num2str(kdata.cst(1)));
            set(handles.cst2,'string',num2str(kdata.cst(2)));
            set(handles.cst3,'string',num2str(kdata.cst(3)));
            set(handles.autocst1,'value',get(data.hautocst(1),'value')); autocsttxt(handles.autocst1);
            set(handles.autocst2,'value',get(data.hautocst(2),'value')); autocsttxt(handles.autocst2);
            set(handles.autocst3,'value',get(data.hautocst(3),'value')); autocsttxt(handles.autocst3);
            set(handles.medianX,'value',kdata.med(1));
            set(handles.medianY,'value',kdata.med(2));
            set(handles.sumX,'value',kdata.sum(1));
            set(handles.sumY,'value',kdata.sum(2));
            set(handles.imparamtxt,'string',get(data.handles.imparamtxt,'string'));
            set(handles.dirtxt,'string',get(data.handles.dirtxt,'string'));
            set(handles.dir2txt,'string',get(data.handles.dir2txt,'string'));
            set(handles.curfile,'string',get(data.handles.curfile,'string'));
            set(handles.pixsizeedit,'string',num2str(kdata.pixdim(1)));
            analysis=get(handles.analysismenu,'string');
            analysis=[analysis;{'x'};{'y'};{'psf'};{'amp'};{'N=amp*sqrt(2pi)*s/dx'};...
                {'R count'};{'G count'};{'B count'};...
                {'R cnt-bg'};{'G cnt-bg'};{'B cnt-bg'}];
            set(handles.analysismenu,'string',analysis);
            displayfile(handles);
    end
end

%dirbutton_Callback([],2,handles)



% --- Executes just before KymoTracker1 is made visible.
function KymoTracker1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to KymoTracker1 (see VARARGIN)

% Choose default command line output for KymoTracker1
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);



% --- Outputs from this function are returned to the command line.
function varargout = KymoTracker1_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% Menu functions, unused-------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file = uigetfile('*.fig');
if ~isequal(file, 0)
    open(file);
end

function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.figure1)

function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figure1,'Name') '?'],...
                     ['Close ' get(handles.figure1,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end
delete(handles.figure1)



% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
global kdata
set(handles.loadtxt,'string','Loading...','backgroundcolor',[1,0.5,0]);
drawnow;
contents = cellstr(get(hObject,'String'));
newfile=contents{get(hObject,'Value')};
%[~,name]=fileparts(newfile);
[path,name,ext]=fileparts(newfile);
switch ext
    case '.txt' % possibly an Ftrap file
        set(handles.loadtxt,'string','txt file error','backgroundcolor','r');
        % test for array data and find number of columns
        fid=fopen(fullfile(kdata.curdir,newfile));%[path,name,ext]);
        line=fgetl(fid);
        fclose(fid);
        if isempty(line)
            return
        else
            l=sscanf(line,'%f')
            ncol=length(l);
            if ncol==0
                return
            end
        end
        % ok found columns, read this shit
        fid=fopen(fullfile(kdata.curdir,newfile));%[path,name,ext]);
        D=fscanf(fid,'%f',[ncol,Inf]);
        fclose(fid);
        if isempty(D)
            return
        end
        set(handles.loadtxt,'string','txt file ok','backgroundcolor','y');
        descr='kymo from text file';
        set(handles.descriptiontxt,'string',descr);
        set(handles.propnamemenu,'string',[]);
        kdata.dat=D;
        kdata.dim=size(D);
        im(:,:,1)=D;
        im(:,:,2)=D;
        im(:,:,3)=D;
        kdata.im=im;
        kdata.roiim=kdata.im;
        kdata.roi=[1,1,kdata.dim];        % reset ROI
        dx=get(handles.dxedit,'string');
        kdata.pixdim(1)=str2num(dx);
        kdata.pixunit(1)={'nm'};
        kdata.pixdim(2)=str2num(get(handles.dtedit,'string'));
        kdata.pixunit(2)={'ms'};
        time=repmat((1:kdata.dim(2))-1,kdata.dim(1),1)*kdata.pixdim(2);
        t=time(1,:); DT=t(2:end)-t(1:end-1);
        linetime=mean(DT);
        totaltime=t(end)-t(1);
        kdata.time=time;
        displayfile(handles);
        set(handles.curfile,'string',name);
        kdata.curfile=newfile;
        'found a txtkymo, sir!'
        kdata.imtype='txtkymo';
        dytxt=[];
        txt=['dx ',dx,' nm; ',dytxt,'<line time> ',num2str(linetime),' ms; acquisition time ',...
            num2str(totaltime/1000),' s'];
        set(handles.imparamtxt,'string',txt);
        set([handles.dttxt,handles.dtedit,handles.mstxt,...
            handles.dxtxt,handles.dxedit,handles.nmtxt],'visible','on');
        set(handles.loadtxt,'string','Done','backgroundcolor','g');
        
        
    case '.tdms'    % possibly a scanary file
        dat=TDMS_readTDMSFile(fullfile(kdata.curdir,newfile));
        pNames=dat.propNames{1};
        pValues=dat.propValues{1};
        set(handles.loadtxt,'string','Not a Scanary File','backgroundcolor','r');
        filetype=findproperty(pNames,pValues,'File format version');
        if strncmpi(filetype,'scanary',7)       % If it is a scanary file, we're good
            % switch dt and dx texts off
            set([handles.dttxt,handles.dtedit,handles.mstxt,...
                handles.dxtxt,handles.dxedit,handles.nmtxt],'visible','off');
            % init proplist and descriptives
            for i=1:length(pNames)
                propnamevalues(i)={[pNames{i},': ',num2str(pValues{i})]};
            end
            [descr,idesc]=findproperty(pNames,pValues,'Description');
            set(handles.descriptiontxt,'string',descr);
            set(handles.propnamemenu,'string',propnamevalues);
            % store kdata and dimensions
            kdata.dat=dat;
            kdata.dim=double([kdata.dat.propValues{1}{7},kdata.dat.propValues{1}{8}]);
            if rem(length(kdata.dat.data{3}),kdata.dim(1))==0 % set dimensions
                kdata.dim(2)=length(kdata.dat.data{3})/kdata.dim(1);
            elseif rem(length(kdata.dat.data{3}),kdata.dim(2))==0
                kdata.dim(1)=kdata.dim(2);
                kdata.dim(2)=length(kdata.dat.data{3})/kdata.dim(2);
            end
            im(:,:,1)=reshape(kdata.dat.data{3},kdata.dim(1),kdata.dim(2));
            im(:,:,2)=reshape(kdata.dat.data{4},kdata.dim(1),kdata.dim(2));
            im(:,:,3)=reshape(kdata.dat.data{5},kdata.dim(1),kdata.dim(2));
            kdata.im=im;
            kdata.roiim=kdata.im;
            kdata.roi=[1,1,kdata.dim];        % reset ROI
            time=reshape(kdata.dat.data{6},kdata.dim(1),kdata.dim(2));
            t=time(1,:); DT=t(2:end)-t(1:end-1);
            linetime=mean(DT);
            totaltime=t(end)-t(1);
            kdata.time=time;
            displayfile(handles);
            set(handles.curfile,'string',name);
            kdata.curfile=newfile;
            % Get all image properties and display these at random points on screen
            dt=rm0s(findproperty(pNames,pValues,'Scan Command.PI Fast Scan Command.pixel_dwell_time_ms'));
            os=rm0s(findproperty(pNames,pValues,'Scan Command.PI Fast Scan Command.overshoot_time_ms'));
            dtintfr=rm0s(findproperty(pNames,pValues,'Scan Command.PI Fast Scan Command.inter_frame_wait_time_ms'));
            dtline=rm0s(findproperty(pNames,pValues,'Scan Command.PI Fast Scan Command.line_rate_ms'));
            nprec=rm0s(findproperty(pNames,pValues,'Scan Command.PI Fast Scan Command.n_preconditioning_lines'));
            dx=rm0s(findproperty(pNames,pValues,'Scan Command.Scan Command.scanning_axes.0.pix_size_nm'));
            dy=rm0s(findproperty(pNames,pValues,'Scan Command.Scan Command.scanning_axes.1.pix_size_nm'));
            kdata.pixdim(1)=str2num(dx);
            kdata.pixunit(1)={'nm'};
            naxes=findproperty(pNames,pValues,'Scan Command.Scan Command.scanning_axes.count');
            switch naxes{1}         % check image type
                case '1'
                    'found a kymo, sir!'
                    kdata.imtype='kymo';
                    dytxt=[];
                    kdata.pixdim(2)=linetime;
                    kdata.pixunit(2)={'ms'};
                case '2'
                    'found an image, sir!'
                    kdata.imtype='image';
                    dytxt=['dy ',dy,' nm; '];
                    kdata.pixdim(2)=str2num(dy);
                    kdata.pixunit(2)={'nm'};
                otherwise
                    'found a weird image, sir!'
                    kdata.imtype='weird';
                    set(handles.loadtxt,'string','Weird image','backgroundcolor','r');
                    dytxt=['dy ',dy,' nm; '];
                    kdata.pixdim(2)=str2num(dy);
                    kdata.pixunit(2)={'nm'};
            end
            txt=['dx ',dx,' nm; ',dytxt,'<line time> ',num2str(linetime),' ms; acquisition time ',...
                num2str(totaltime/1000),' s; pixel dwell time ',dt,...
                ' ms; overshoot time ',os,' ms; set line time ',dtline,...
                ' ms; inter-frame time ',dtintfr,' ms; preconditioning lines ',nprec];
            set(handles.imparamtxt,'string',txt);
            set(handles.loadtxt,'string','Done','backgroundcolor','g');
        end%,end
end

function [value,index]=findproperty(propnames,propvalues,name)
% Helps to retrieve property name property value pairs by name only
value={};
index=[];
lst=strfind(propnames,name);
for i=1:length(lst)
    if any(lst{i})
        value=[value,propvalues{i}];
        index=[index,i];
    end
end

function str=rm0s(txt)
% Removes trailing zeros after punctuation and returs string
if length(txt)==0
    txt=[];
elseif length(txt)>1
    txt=txt(1);
else
    txt=txt{:};
    i=strfind(txt,'.');
    if any(i)
        i=i(end);
        i0=txt(i+1:end)=='0';
        inon0=find(txt~='0');
        if i0&i>1                               % Only zeros after punct
            txt=txt(1:i-1);
        elseif any(i0)&inon0(end)<length(txt)   % after punct, last are zero
            txt((inon0(end)+1):end)=[];
        end
        if i(1)==1
            txt=['0',txt];
        end
    end
end
str=txt;


function displayfile(handles)
% General display file called by all functions, handles contrast, roi's and
% filters
global kdata
set(handles.loadtxt,'string','Post-pocessing','backgroundcolor','y');
drawnow;
im=kdata.im;
% apply median filter
medx=kdata.med(1);
medy=kdata.med(2);
if medx>1           % median filter lines in x
    roiimx=zeros(size(im,1),size(im,2),size(im,3));
    for i=1:size(im,1);
        roiimx(i,:,:)=median(im(max(round(i-(medx-1)/2),1)...
            :min(round(i+(medx-1)/2),size(im,1)),:,:),1);
    end
else
    roiimx=im;
end
if medy>1           % median filter lines in x
    roiimxy=zeros(size(im,1),size(im,2),size(im,3));
    for i=1:size(im,2);
        roiimxy(:,i,:)=median(roiimx(:,max(round(i-(medy-1)/2),1)...
            :min(round(i+(medy-1)/2),size(im,2)),:),2);
    end
else
    roiimxy=roiimx;
end
medim=roiimxy; clear roiimxy roiimx
% Get region of interest
roiim=medim(kdata.roi(1):kdata.roi(3),kdata.roi(2):kdata.roi(4),:);
% Sum lines/rows if necessary
sumx=kdata.sum(1);       % Get sumparameters
sumy=kdata.sum(2);
if sumx>1           % sum lines in x
    roiimx=zeros(floor(size(roiim,1)/sumx),size(roiim,2),size(roiim,3));
    for i=1:floor(size(roiim,1)/sumx);
        roiimx(i,:,:)=sum(roiim(((i-1)*sumx+1):(i*sumx),:,:),1);
    end
else
    roiimx=roiim;
end
if sumy>1               % sum lines in y
    roiimxy=zeros(size(roiimx,1),floor(size(roiim,2)/sumy),size(roiimx,3));
    for i=1:floor(size(roiim,2)/sumy);
        roiimxy(:,i,:)=sum(roiimx(:,((i-1)*sumy+1):(i*sumy),:),2);
    end
else
    roiimxy=roiimx;
end
kdata.roiim=roiimxy;
kdata.roidim=size(kdata.roiim(:,:,1));
% Check auto/manual contrast
for i=1:3
    if get(kdata.hautocst(i),'value')        % if auto contrast
        roiimi=kdata.roiim(:,:,i);
        kdata.cst(i)=max(roiimi(:));
        set(kdata.hcst(i),'string',num2str(kdata.cst(i)));
    end
end
% Check if a metric window existed
replace=0;
if isfield(kdata,'hrect'), if ishandle(kdata.hrect)
        p1p2=get(kdata.hrect,'userdata');
        replace=1;
end,end
% Check if a tracking window existed
replacetr=0;
if isfield(kdata,'trrect'), if ishandle(kdata.trrect)
        p1p2tr=get(kdata.trrect,'userdata');
        replacetr=1;
end,end
% Check if a metric window existed
replacebg=0;
if isfield(kdata,'bgrect'), if ishandle(kdata.bgrect)
        p1p2bg=get(kdata.bgrect,'userdata');
        replacebg=1;
end,end
% Check if maxima were displayed
replacemax=0;
if isfield(kdata,'hmaxima'), if ishandle(kdata.hmaxima)
        replacemax=1;
end, end
% Check if trajectories were displayed
replacetraj=0;
if isfield(kdata,'htracks'), if ishandle(kdata.htracks)
        replacetraj=1;
end, end
kdata.imh=ImShow(handles.imaxes,imcst(kdata.roiim,kdata.cst,kdata.chdisp));
aspct=str2num(get(handles.aspectedit,'string'));
if aspct==0
    sizeax=get(handles.imaxes,'position');
    wax=sizeax(3);
    hax=sizeax(4);
    wim=size(kdata.roiim,2);
    him=size(kdata.roiim,1);
    aspct=1/(wax/hax*him/wim);
end
daspect(handles.imaxes,[aspct 1 1]);
if replace
    LL=(p1p2(1:2)-kdata.roi(1:2))./kdata.sum+1;    % index LL
    UR=(p1p2(3:4)-kdata.roi(1:2))./kdata.sum+1;    % index LL
%    LL=((llur(1:2)-1).*kdata.sum+kdata.roi(1:2));    % index LL
    OS=(UR-LL);                 % index UR
%    OS=(llur([4,3]).*kdata.sum);                 % index UR
    newpos=[LL([2,1]),OS([2,1])]-[0.5,0.5,0,0];
    kdata.hrect=rectangle('position',newpos,'edgecolor','m','linestyle',':','hittest','off');
    set(kdata.hrect,'userdata',p1p2);
    mettxt=getmetrics(newpos);
    set(handles.metrictxt,'string',mettxt);
    set(handles.metricspanel,'shadowcolor','m');
end
if replacetr
    LL=(p1p2tr(1:2)-kdata.roi(1:2))./kdata.sum+1;    % index LL
    UR=(p1p2tr(3:4)-kdata.roi(1:2))./kdata.sum+1;    % index LL
    OS=(UR-LL);                 % index UR
    newpos=[LL([2,1]),OS([2,1])]-[0.5,0.5,0,0];
    kdata.trrect=rectangle('position',newpos,'edgecolor','g','linestyle','--','hittest','off');
    set(kdata.trrect,'userdata',p1p2tr);
end
if replacebg
    LL=(p1p2bg(1:2)-kdata.roi(1:2))./kdata.sum+1;    % index LL
    UR=(p1p2bg(3:4)-kdata.roi(1:2))./kdata.sum+1;    % index LL
    OS=(UR-LL);                 % index UR
    newpos=[LL([2,1]),OS([2,1])]-[0.5,0.5,0,0];
    kdata.bgrect=rectangle('position',newpos,'edgecolor','c','linestyle','--','hittest','off');
    set(kdata.bgrect,'userdata',p1p2bg);
end
if replacemax
    plotmaxima(kdata.localMaxima);
    plotmovmax(kdata.movieInfo);
end
if replacetraj
    plottracks(kdata.trajectories);
end
analyze(handles);
set(handles.loadtxt,'string','Done','backgroundcolor','g');


function medianX_Callback(hObject, eventdata, handles)
global kdata
kdata.med(1)=get(hObject,'value');
displayfile(handles);

function medianY_Callback(hObject, eventdata, handles)
global kdata
kdata.med(2)=get(hObject,'value');
displayfile(handles);

function trackindexmenu_Callback(hObject, eventdata, handles)
analyze(handles);

function sumX_Callback(hObject, eventdata, handles)
global kdata
sumold=kdata.sum(1);
kdata.sum(1)=get(hObject,'value');
kdata.cst=kdata.cst*kdata.sum(1)/sumold;
set(handles.cst1,'string',kdata.cst(1));
set(handles.cst2,'string',kdata.cst(2));
set(handles.cst3,'string',kdata.cst(3));
pixsize=kdata.pixdim(1)*kdata.sum(1);
set(handles.pixsizeedit,'string',num2str(pixsize));
displayfile(handles);

function sumY_Callback(hObject, eventdata, handles)
global kdata
sumold=kdata.sum(2);
kdata.sum(2)=get(hObject,'value');
kdata.cst=kdata.cst*kdata.sum(2)/sumold;
set(handles.cst1,'string',kdata.cst(1));
set(handles.cst2,'string',kdata.cst(2));
set(handles.cst3,'string',kdata.cst(3));
displayfile(handles);

function imh=ImShow(axeshandles,im)
% Private imshow function that facilitates clicking the bloody axes.
axes(axeshandles);
imh=imshow(im);
set(imh,'buttondownfcn',@(hObject,eventdata)KymoTracker1...
 ('imaxes_ButtonDownFcn',hObject,eventdata,guidata(hObject)));
set(gcf,'windowbuttonmotionfcn',@(hObject,eventdata)KymoTracker1...
    ('MouseoverFcn',hObject, eventdata, guidata(hObject)));


    
function imout=imcst(im,cst,chd)
cst(cst==0)=1;
i=[1,2,3];
if sum(chd)==1;
    i=find(chd)*[1,1,1];
end
imout(:,:,1)=im(:,:,i(1))/cst(i(1))*chd(i(1));
imout(:,:,2)=im(:,:,i(2))/cst(i(2))*chd(i(2));
imout(:,:,3)=im(:,:,i(3))/cst(i(3))*chd(i(3));

%% FUNCTIONS FOR CHANGING DIRECTORIES
% --- Executes on button press in dir2button.
function dir2button_Callback(hObject, eventdata, handles)
global kdata
try
    cd(kdata.expdir)
end
newdir=uigetdir;
if newdir~=0
    try
        cd(newdir);
        kdata.expdir=newdir;
        set(handles.dir2txt,'string',newdir);
    end
end
cd(kdata.basedir);

% --- Executes on button press in dirbutton.
function dirbutton_Callback(hObject, eventdata, handles)
global kdata
if eventdata==2 % 2 is case given at startup
    newdir=kdata.curdir;
    kdata.expdir=newdir;
    set(handles.dir2txt,'string',newdir);
else
    try
        cd(kdata.curdir)
    end
    newdir=uigetdir;
end
if newdir~=0
    try
        cd(newdir);
        kdata.curdir=newdir;
        kdata.expdir=newdir;
        set(handles.dir2txt,'string',newdir);
        set(handles.dirtxt,'string',newdir);
        list=dir(get(handles.filtertxt,'string'));
        set(handles.listbox1,'string',{list.name},'value',1);
        cd(kdata.basedir);
        save('itrapviewer_config.mat','newdir');
        listbox1_Callback(kdata.handles.listbox1, [], handles)
    end
end
cd(kdata.basedir);


%% FUNCTIONS FOR CHANNEL CONTRAST SETTINGS
function cst_Callback(hObject, eventdata, handles)
global kdata
i=get(hObject,'UserData');
set(kdata.hautocst(i),'value',0)
autocsttxt(kdata.hautocst(i))
val=get(hObject,'string');
try 
    val=str2num(val);
    kdata.cst(i)=val;
    axes(handles.imaxes);
    displayfile(handles)
catch
    set(hObject,'string',num2str(kdata.cst(i)));
end

% --- Executes on button press in chdisp1.
function chdisp_Callback(hObject, eventdata, handles)
global kdata
val=get(hObject,'value');
i=get(hObject,'UserData');
kdata.chdisp(i)=val;
displayfile(handles)

% --- Executes on selection change
function equalbutton_Callback(hObject, eventdata, handles)
set(handles.aspectedit,'string','1');
displayfile(handles)

% --- Executes on selection change
function aspectedit_Callback(hObject, eventdata, handles)
displayfile(handles)

% --- Executes on selection change in autocst1.
function autocst1_Callback(hObject, eventdata, handles)
displayfile(handles)
autocsttxt(hObject)

function autocsttxt(handle)
if get(handle,'value')==1
    txt='Auto';
else
    txt='Manual';
end
set(handle,'string',txt);

%% FUNCTIONS FOR SAVING AND EXPORTING
% --- Executes on button press in exporttrackresultsbutton.
function exporttrackresultsbutton_Callback(hObject, eventdata, handles)
global kdata
traj=kdata.trajectories;
trackindex=(1:length(traj));
topbead=str2num(get(handles.topbeadedit,'string'));
botbead=str2num(get(handles.bottombeadedit,'string'));
meanx=mean([topbead,botbead])*kdata.pixdim(1);
for i=1:length(traj)
    traj(i).i=(traj(i).i*kdata.sum(2)+kdata.localMaximaOrig(2)-1);
    traj(i).y=(traj(i).y*kdata.sum(1)+kdata.localMaximaOrig(1)-1)*kdata.pixdim(1);
    iexist=traj(i).x~=0;
    iok=(traj(i).x~=0)&~isnan(traj(i).intens);
    trackngaps(i)=sum(~iexist);
    tracknpoints(i)=sum(iexist);
    trackistart(i)=traj(i).i(1);
    trackiend(i)=traj(i).i(end);
    tracktstart(i)=kdata.time(1,trackistart(i));
    tracktend(i)=kdata.time(1,trackiend(i)+1);
    trackdt(i)=tracktend(i)-tracktstart(i);
    trackxstart(i)=traj(i).y(1);
    trackxend(i)=traj(i).y(end);
    trackxmean(i)=mean(traj(i).y(iexist));
    trackxabsstart(i)=traj(i).y(1)-meanx;
    trackxabsend(i)=traj(i).y(end)-meanx;
    trackxabsmean(i)=mean(traj(i).y(iexist))-meanx;
    trackampstart(i)=kdata.kymonorm*traj(i).amp(1)/kdata.sum(2);
    iamp3start=1:3; iamp3start=iamp3start(iok(1:3));
    trackamp3start(i)=mean(kdata.kymonorm*traj(i).amp(iamp3start))/kdata.sum(2);
    trackampend(i)=kdata.kymonorm*traj(i).amp(end)/kdata.sum(2);
    iamp3end=(length(iok)-2):length(iok); iamp3end=iamp3end(iok(iamp3end));
    trackamp3end(i)=mean(kdata.kymonorm*traj(i).amp(iamp3end))/kdata.sum(2);
    trackampmean(i)=mean(kdata.kymonorm*traj(i).amp(find(iok)))/kdata.sum(2);
    D=kdata.msdanal(i).YdiffConst; if isempty(D), D=NaN; end
    trackdiffconst(i)=D;
end
T = table(trackindex',tracknpoints',trackngaps',trackistart',trackiend',tracktstart',tracktend',...
    trackdt',trackxstart',trackxend',trackxmean',trackxabsstart',trackxabsend',trackxabsmean',...
    trackampstart',trackamp3start',...
    trackampend',trackamp3end',trackampmean',trackdiffconst',...
    'VariableNames',{'trackIndex' 'Npoints' 'Ngaps' 'iLineStart' 'iLineEnd' 'tStart_ms'...
    'tEnd_ms' 'dt_ms' 'xStart_nm' 'xEnd_nm' 'xMean_nm' 'xAbsStart_nm' 'xAbsEnd_nm' 'xAbsMean_nm' ...
    'ampStart' 'amp3Start' 'ampEnd'...
    'amp3End' 'ampMean' 'DiffConst_nm2s'})
apptxt=get(handles.appendtext,'string');
file=[get(handles.curfile,'string'),apptxt];
expath=kdata.expdir;
savefile=fullfile(expath,file);
savef=[savefile,'_Tracking.txt']
if isfield(kdata,'track2'),if kdata.track2
    savef=[savefile,'_2Tracking.txt']
end,end        
writetable(T,savef);
savef=[savefile,'_trajectories.mat']
if isfield(kdata,'track2'),if kdata.track2
    savef=[savefile,'_2trajectories.mat']
end,end        
datslim=kdata;
datslim.dat=[];
save(savef,'datslim');
    % now prep one table per track
    % Ineke, this stuff below is for exporting tracks
traj=kdata.trajectories;
% % NEW hack for getting other channels
% [p1,p2,roi]=pos2p1p2(kdata.trackingpos);
% %                 % Relevant section modified from pos2p1p2
% %                 p1=round((kdata.trackingpos([2,1])-1).*kdata.sum+[1,1]);    % index LL
% %                 p2=round(p1+kdata.trackingpos([4,3]).*kdata.sum);                 % index UR
% %                 p1=max(p1,[1,1]);       % limit LL to image dim
% %                 p2=min(p2,kdata.dim);    % limit UR to image dim
%  
% I=kdata.im(p1(1):p2(1)-1,p1(2):p2(2)-1,:);
                % Get trackingroi
                troi=kdata.trackingroi;
                p1=troi(1:2);
                p2=troi(3:4);%[troi(3)-troi(1),troi(4)-troi(2)];
%                 [p1,p2,roi]=pos2p1p2([p1,p2])%trackingpos);
%                 % Relevant section modified from pos2p1p2
%                 p1=round((kdata.trackingpos([2,1])-1).*kdata.sum+[1,1]);    % index LL
%                 p2=round(p1+kdata.trackingpos([4,3]).*kdata.sum);                 % index UR
%                 p1=max(p1,[1,1]);       % limit LL to image dim
%                 p2=min(p2,kdata.dim);    % limit UR to image dim
                
                %I=kdata.im(p1(1):p2(1)-1,p1(2):p2(2)-1,:);
                I=kdata.im(p1(1):p2(1),p1(2):p2(2),:);

for i=1:length(traj)
    N=length(traj(i).y);
    TrackNo=i*ones(1,N);
    iPoint=1:N;
    iLineROI=traj(i).i; 
    iNaN=(iLineROI==0)|isnan(iLineROI);
    iLineROI(iNaN)=round(interp1(iPoint(~iNaN),iLineROI(~iNaN),iPoint(iNaN)));
    iLineKymo=(iLineROI*kdata.sum(2)+kdata.localMaximaOrig(2)-1);
    TimeReal=NaN*zeros(1,N);
    %TimeReal(~iNaN)=kdata.time(1,iLineKymo(~iNaN));
    TimeReal=kdata.time(1,iLineKymo);
    TimeAvEquidist=iLineKymo*kdata.pixdim(2);
    iPosROI=traj(i).y; 
    iPosROI(iNaN)=interp1(iPoint(~iNaN),iPosROI(~iNaN),iPoint(iNaN));
    iPosKymo=(iPosROI*kdata.sum(1)+kdata.localMaximaOrig(1)-1);
    iPosKymoRelCenter=iPosKymo-mean([topbead,botbead]);
    PosKymo=iPosKymo*kdata.pixdim(1);
    PosKymoRelCenter=PosKymo-meanx;
    IntensityPix=zeros(1,N);
    IntensityPix3=zeros(1,N,3);
    % Calculate number of pixels needed for 95% (2sd)
psf=kdata.trajectories(i).psf*kdata.pixdim(1);
meanpsf=mean(psf(find(psf~=0&~isnan(psf))))
npixforI=ceil(4*meanpsf/kdata.pixdim(1))
    NpixforI=zeros(1,N);
    %npixforI=kdata.npixforI;                 % INEKE,edit for box size for intensity calcualtion
    for j=1:length(IntensityPix)
        if ~isnan(iPosROI(j))&(iPosROI(j)~=0)
            ipix=(iPosROI(j)-(npixforI/2-0.5)):1:(iPosROI(j)+(npixforI/2-0.5));
            ipix=round(ipix);
            ipix=ipix((ipix>=1)&(ipix<=size(kdata.trroiim,1)));
            pix=kdata.trroiim(ipix,iLineROI(j));
            NpixforI(j)=length(pix);
            IntensityPix(j)=sum(pix(:));
            % Get RGB values
            IntensityPix3(1,j,1)=sum(I(ipix,iLineROI(j),1));
            IntensityPix3(1,j,2)=sum(I(ipix,iLineROI(j),2));
            IntensityPix3(1,j,3)=sum(I(ipix,iLineROI(j),3));
        else
            NpixforI(j)=0;
            IntensityPix(j)=NaN;
            IntensityPix3(1,j,:)=NaN;
        end
    end
    bg=kdata.bgParam.bgMean*kdata.kymonorm;
    IntPixBgCorrect=IntensityPix-NpixforI*bg;
    bg3=kdata.bgParam3.bgMeanAbs3'*NpixforI;    % get stuff for all channels
    IntensityPix3=squeeze(IntensityPix3)';
    IntPix3BgCorrect=IntensityPix3-bg3;
    GaussFitAmp=traj(i).amp*kdata.kymonorm;
    GaussFitPSF=traj(i).psf;
    BackGround=bg*ones(1,N);
    BackGround3=bg3/npixforI;
    
                sigma=kdata.trajectories(i).psf*kdata.pixdim(1);
                AmpInt=kdata.kymonorm*kdata.trajectories(i).amp/kdata.sum(2);
                AmpInt=AmpInt.*sigma*sqrt(2*pi)/kdata.pixdim(1);
                
    T = table(TrackNo',iPoint',iLineROI',iLineKymo',TimeReal',TimeAvEquidist',...
        iPosROI',iPosKymo',iPosKymoRelCenter',PosKymo',PosKymoRelCenter',NpixforI',...
        IntensityPix',IntPixBgCorrect',GaussFitAmp',GaussFitPSF',AmpInt',BackGround',...
        IntensityPix3(1,:)',IntensityPix3(2,:)',IntensityPix3(3,:)',...
        IntPix3BgCorrect(1,:)',IntPix3BgCorrect(2,:)',IntPix3BgCorrect(3,:)',...
        BackGround3(1,:)',BackGround3(2,:)',BackGround3(3,:)',...
        'VariableNames',{'trackIndex' 'iPoint' 'iLineROI' 'iLineKymo' 'TimeReal_ms'...
        'TimeAvEquidist_ms' 'iPosROI' 'iPosKymo' 'iPosKymoRelCenter' 'PosKymo_nm'...
        'PosKymoRelCenter_nm' 'NpixforI' 'IntensityPix' 'IntPixBgCorrect' ...
        'GaussFitAmp' 'GaussFitPSF_nm' 'IntensityIntegratedGauss' 'BackGroundPixIntens' ...
        'IntensityPixR','IntensityPixG','IntensityPixB',...
        'IntPixBgCorR','IntPixBgCorG','IntPixBgCorB',...
        'BackGroundPixIntR','BackGroundPixIntG','BackGroundPixIntB',})
    apptxt=['_track',num2str(i)];
if isfield(kdata,'track2'),if kdata.track2
    apptxt=['_2track',num2str(i)];
end,end        
    file=[get(handles.curfile,'string'),apptxt];
    expath=kdata.expdir;
    savefile=fullfile(expath,file);
    savef=[savefile,kdata.exportformat];            % Ineke, use '.txt' for delimited, use '.xls' for excel
    writetable(T,savef);
end

   
function showlinetimesbutton_Callback(hObject, eventdata, handles)
% Extracts time data from raw dataset and exports linetimes
global kdata
dt=kdata.time(1,2:end)-kdata.time(1,1:end-1);
axes(handles.analysisaxes); cla; hold off;
plot(1e-3*kdata.time(1,kdata.roi(2):min(kdata.roi(4),length(dt))),...
    dt(kdata.roi(2):min(kdata.roi(4),length(dt))),'ro');
hold on
plot(1e-3*kdata.time(1,1:end-1),dt); 
axis tight
set(handles.analysisaxes,'ylim',[0,1.1*max(dt)]);
xlabel('time (s)');
ylabel('line time (ms)');
set(handles.analysisaxes,'userdata',[get(handles.analysisaxes,'xlim'),get(handles.analysisaxes,'ylim')]);
set(handles.analysisaxes,'buttondownfcn',@(hObject,eventdata)KymoTracker1...
 ('analysisaxes_ButtonDownFcn',hObject,eventdata,guidata(hObject)));
set(get(handles.analysisaxes,'children'),'hittest','off');



% --- Executes on button press in savebutton.
function savebutton_Callback(hObject, eventdata, handles)
global kdata
apptxt=get(handles.appendtext,'string');
file=[get(handles.curfile,'string'),apptxt];
expath=kdata.expdir;
savefile=fullfile(expath,file);
type=get(handles.filetype,'string');
type=type{get(handles.filetype,'value')};
drawnow;
saveopt=get(handles.saveimagemenu,'string');
value=get(handles.saveimagemenu,'value');
% Check what to save
win=0;
im=0;
full=0;
switch saveopt{value}
    case 'window + current image'
        win=1;im=1;full=0;
    case 'window + full image'
        win=1;im=1;full=1;
    case 'window'
        win=1;im=0;full=0;
    case 'current image'
        win=0;im=1;full=0;
    case 'full image'
        win=0;im=1;full=1;
end
% save what to save
if win
    F=getframe(kdata.handles.figure1);
    [IM,map]=frame2im(F);
    savef=[savefile,'_window.',type]
    imwrite(IM,savef,type);
end
if im
    if full
        kdata.roi=[1,1,kdata.dim];    % reset ROI to full image
        displayfile(handles);
    end
    axes(kdata.handles.imaxes);% axis tight
    F=getframe(kdata.handles.imaxes);
    [IM,map]=frame2im(F);
    savef=[savefile,'_image.',type]
    imwrite(IM,savef,type);
end
drawnow;

% --- Executes on button press in saveallbutton.
function saveallbutton_Callback(hObject, eventdata, handles)
savebutton_Callback([],[],handles);
exporttrackresultsbutton_Callback([], [], handles);




%% UNUSED FUNCTIONS

% --- Executes during object creation, after setting all properties.




function medianY_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function sumX_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function sumY_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function listbox1_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function dir2txt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function filtertxt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function appendtext_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function autocst1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function dirtxt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function cst1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function cst2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function cst3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function medianX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function analysismenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function propnamemenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function analysistxt_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function fitmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function filetype_CreateFcn(hObject, eventdata, handles)

function dirtxt_ButtonDownFcn(hObject, eventdata, handles)

% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)

function dirtxt_Callback(hObject, eventdata, handles)

function dir2txt_Callback(hObject, eventdata, handles)

function appendtext_Callback(hObject, eventdata, handles)

function filtertxt_Callback(hObject, eventdata, handles)

function filetype_Callback(hObject, eventdata, handles)

function propnamemenu_Callback(hObject, eventdata, handles)

function analysistxt_Callback(hObject, eventdata, handles)



function analysisaxes_ButtonDownFcn(hObject, eventdata, handles)
% Activated when clicking image 
% Creates rectangle in kdata.hrect
global kdata
point1 = get(handles.analysisaxes,'CurrentPoint'); % button down detected
point1 = round(point1(1,1:2));           % extract x and y 
event.point1=point1;
pos=[point1,1,1];
set(gcf,'units','pixels');
        kdata.zrect=rectangle('position',pos,'edgecolor','k','linestyle',':');
set(gcf,'windowbuttonupfcn',@(hObject,eventdata)KymoTracker1...
    ('analysisaxes_WindowButtonUpFcn',hObject, event, guidata(hObject)));
set(gcf,'windowbuttonmotionfcn',@(hObject,eventdata)KymoTracker1...
    ('analysisaxes_WindowButtonMotionFcn',hObject, event, guidata(hObject)));


function analysisaxes_WindowButtonMotionFcn(hObject, event, handles)
% For area selection, works with fig1_WindowButtonUpFcn, set by imaxes_ButtonDownFcn
% rect - structure with rectangle object
global kdata
point2=get(handles.analysisaxes,'currentpoint');
point2=round(point2(1,1:2));
point1=event.point1;
p1 = min(point1,point2);           % calculate locations
offset = abs(point1-point2);       % and dimensions
pos=[p1,offset];
try
    set(kdata.zrect,'position',pos);
catch
    epsilon=1e-5*(pos==0);
    set(kdata.zrect,'position',pos+epsilon);
end

function analysisaxes_WindowButtonUpFcn(hObject, event, handles)
% For area selection, works with fig1_WindowButtonMotionFcn, set by imaxes_ButtonDownFcn
% rect - structure with rectangle object
global kdata
set(gcf,'windowbuttonupfcn',[]);
set(gcf,'windowbuttonmotionfcn',@(hObject,eventdata)KymoTracker1...
    ('MouseoverFcn',hObject, [], guidata(hObject)));
pos=get(kdata.zrect,'position');
p1=event.point1;
p2=get(gca,'currentpoint'); p2=round(p2(1,1:2));
delete(kdata.zrect);
if pos(3:4)==[1,1]              % zero area selected
    if kdata.area0==1 & kdata.curp==pos(1:2)   % there was a double-click, zoom out
        lims=get(handles.analysisaxes,'userdata')
        set(handles.analysisaxes,'xlim',lims(1:2),'ylim',lims(3:4));
    end
    kdata.area0=1;               % set single-click flag
    kdata.curp=pos(1:2);
    return
elseif any(round(pos(3:4))==0)  % zoom in and reset single-click flag
    kdata.area0=0;
else
    set(handles.analysisaxes,'xlim',[min([p1(1),p2(1)]),max([p1(1),p2(1)])],...
        'ylim',[min([p1(2),p2(2)]),max([p1(2),p2(2)])]);
end


function imaxes_ButtonDownFcn(hObject, eventdata, handles)
% Activated when clicking image 
% Creates rectangle in kdata.hrect
global kdata
switch get(gcf,'selectiontype');
    case 'normal'
        kdata.action='zoom';
    case 'alt'
        if isfield(kdata,'edittracks'), if kdata.edittracks
                tracks=undoredoshift('edit');
                point1 = get(handles.imaxes,'CurrentPoint'); % button down detected
                point1 = point1(1,1:2);
                createtrackpoint(point1,[]);
                plottracks(kdata.trajectories);
                return
        end, end              
        kdata.action='metrics';
end
point1 = get(handles.imaxes,'CurrentPoint'); % button down detected
point1 = round(point1(1,1:2));           % extract x and y 
pos=[point1,1,1];
set(gcf,'units','pixels');
try, if ishandle(kdata.hrect),   % Store old ROI in temprect during mouse dragging
        kdata.temprect=rectangle('position',get(kdata.hrect,'position'),'hittest','off'...
            ,'edgecolor','m','linestyle',':','userdata',get(kdata.hrect,'userdata'));
        delete(kdata.hrect);
end, end
switch kdata.action % Create rectangle for further processing
    case 'zoom'
        if kdata.selecttrackingroi, rclr='g'; else, rclr='y'; end
        kdata.hrect=rectangle('position',pos-[0.5,0.5,0,0],'edgecolor',rclr,'linestyle',':','hittest','off');
        set(handles.metricspanel,'shadowcolor',rclr);
    case 'metrics'
        if kdata.selecttrackingroi, rclr='c'; else, rclr='r'; end
        kdata.hrect=rectangle('position',pos-[0.5,0.5,0,0],'edgecolor',rclr,'linestyle',':','hittest','off');
        set(handles.metricspanel,'shadowcolor',rclr);
end
event.point1=point1;
event.action=kdata.action;
        [mettxt,curtxt,p1,p2]=getmetrics(pos);
        set(handles.metrictxt,'string',mettxt);
        set(handles.currenttxt,'string',curtxt);
        set(kdata.hrect,'userdata',[p1,p2]);
set(gcf,'windowbuttonupfcn',@(hObject,eventdata)KymoTracker1...
    ('fig1_WindowButtonUpFcn',hObject, event, guidata(hObject)));
set(gcf,'windowbuttonmotionfcn',@(hObject,eventdata)KymoTracker1...
    ('fig1_WindowButtonMotionFcn',hObject, event, guidata(hObject)));


function fig1_WindowButtonMotionFcn(hObject, event, handles)
% For area selection, works with fig1_WindowButtonUpFcn, set by imaxes_ButtonDownFcn
% rect - structure with rectangle object
global kdata
point2=get(handles.imaxes,'currentpoint');
point2=round(point2(1,1:2));
switch event.action
    case {'zoom','metrics','shaperect','moverect'}
        p1 = min(event.point1,point2);           % calculate locations
        offset = abs(event.point1-point2);       % and dimensions
        if strcmpi(event.action,'metrics');     % limit rect to roi
            p2=min(p1+offset,[size(kdata.roiim,2),size(kdata.roiim,1)]+1);
            p1=max(p1,[1,1]);
            offset=p2-p1;
        end
        switch event.action
            case {'zoom','metrics'}
                pos=[p1,offset];
                hrect=kdata.hrect;
            case{'shaperect'}
                hrect=kdata.hitrect;
                POS0=get(hrect,'position')+[0.5,0.5,0,0];  % get old position
                POS0=POS0+[0,0,POS0(1:2)];                      % old rectangle in LL, UR format
                POS1=[point2,point2];                           % new rectangle
                POS=POS0;
                POS(event.hit)=POS1(event.hit);
                %pos=[min(POS([1,3])),min(POS([2,4])),...
                %    max(POS([1,3]))-min(POS([1,3])),max(POS([2,4]))-min(POS([2,4]))];
                pos=[POS(1:2),POS(3:4)-POS(1:2)];
           case{'moverect'}
               hrect=kdata.hitrect;
                %pos=get(data.hrect,'position')+[0.5,0.5,0,0];  % get old position
                pos=event.oldpos;
                move=point2-event.point1;
                pos=pos+[move,0,0];
           end
        try 
            set(hrect,'position',pos-[0.5,0.5,0,0]);
        catch
            epsilon=1e-5*(pos==0);
            set(hrect,'position',pos+epsilon-[0.5,0.5,0,0]);
        end
        [mettxt,curtxt,p1,p2]=getmetrics(pos);
        set(handles.metrictxt,'string',mettxt);
        set(handles.currenttxt,'string',curtxt);
        set(hrect,'userdata',[p1,p2]);
end

function MouseoverFcn(hObject, event, handles)
% Metrics display without clicking image
global kdata
p=get(handles.imaxes,'currentpoint');
p=round(p(1,1:2));
if p>=[1,1] & p<=fliplr(kdata.roidim)
    [mettxt,curtxt]=getmetrics([p,1,1]);
    set(handles.currenttxt,'string',curtxt);
else
    set(handles.currenttxt,'string',['Double-click to zoom out']);
end


function fig1_WindowButtonUpFcn(hObject, event, handles)
% For area selection, works with fig1_WindowButtonMotionFcn, set by imaxes_ButtonDownFcn
% rect - structure with rectangle object
global kdata
set(gcf,'windowbuttonupfcn',[]);
%set(gcf,'windowbuttonmotionfcn',[]);
set(gcf,'windowbuttonmotionfcn',@(hObject,eventdata)KymoTracker1...
    ('MouseoverFcn',hObject, event, guidata(hObject)));
switch kdata.action,
    case 'zoom'
        pos=get(kdata.hrect,'position')+[0.5,0.5,0,0];
        [mettxt,curtxt,p1,p2,roi]=getmetrics(pos);
        delete(kdata.hrect);
        try, if ishandle(kdata.temprect),
                kdata.hrect=kdata.temprect;       % return metrics rect to hrect
                %delete(kdata.temprect);
            end, end
        if pos(3:4)==[1,1]              % zero area selected
            if kdata.area0==1 & kdata.curp==pos(1:2)   % there was a double-click, zoom out
                if kdata.selecttrackingroi
                    [mettxt,curtxt,p1,p2,roi]=getmetrics([0.5,0.5,fliplr(kdata.roidim)]);
                    kdata.trackingroi=[p1,p2]
                    kdata.trroiim=roi;
                    if isfield(kdata,'trrect'),if ishandle(kdata.trrect)
                            delete(kdata.trrect);
                        end,end
                    kdata.trrect=rectangle('position',[1,1,fliplr(kdata.roidim)]-[0.5,0.5,0,0],'edgecolor','g','linestyle','--','hittest','off');
                    set(kdata.trrect,'userdata',kdata.roi);
                    set(handles.trackingroitxt,'string',mettxt(1:7));
                else
                    kdata.roi=[1,1,kdata.dim];    % reset ROI to full image
                    if isfield(kdata,'trrect')
                        if ishandle(kdata.trrect)
                            displayfile(handles);
                            set(kdata.trrect,'hittest','on','Buttondownfcn',...
                                @(hObject,eventdata)KymoTracker1('hitrect',hObject,eventdata,guidata(hObject)));
                        else
                        displayfile(handles);
                        end
                    else
                        displayfile(handles);
                    end
                end
            end
            kdata.area0=1;               % set single-click flag
            kdata.curp=pos(1:2);
            return
        elseif any(round(pos(3:4))==0)  % zoom in and reset single-click flag
            kdata.area0=0;
        else
            if kdata.selecttrackingroi
                kdata.trackingroi=[p1,p2-1];
                kdata.trackingpos=pos;
                kdata.trroiim=roi;
                set(handles.trackingroitxt,'string',mettxt(1:7));
                if isfield(kdata,'trrect'),if ishandle(kdata.trrect)
                        delete(kdata.trrect);
                    end,end
                kdata.trrect=rectangle('position',pos-[0.5,0.5,0,0],'edgecolor','g','linestyle','--','hittest','off');
                set(kdata.trrect,'userdata',[p1,p2]);
                set(kdata.trrect,'hittest','on','Buttondownfcn',...
                    @(hObject,eventdata)KymoTracker1('hitrect',hObject,eventdata,guidata(hObject)));
            else
                    kdata.roi=[p1,p2-1];    % reset ROI to full image
                    if isfield(kdata,'trrect')
                        if ishandle(kdata.trrect)
                            displayfile(handles);
                            set(kdata.trrect,'hittest','on','Buttondownfcn',...
                                @(hObject,eventdata)KymoTracker1('hitrect',hObject,eventdata,guidata(hObject)));
                        else
                        displayfile(handles);
                        end
                    else
                        displayfile(handles);
                    end
            end
            kdata.area0=0;
        end
    case {'metrics'}
        pos=get(kdata.hrect,'position')+[0.5,0.5,0,0];
        [mettxt,curtxt,p1,p2,roi]=getmetrics(pos);
        
        try, if ishandle(kdata.temprect),
                delete(kdata.temprect);
            end, end
        if kdata.selecttrackingroi
        try, if ishandle(kdata.hrect),
                delete(kdata.hrect);
            end, end
            
            set(handles.bgroitxt,'string',[{'Background:'};mettxt(10:end)]);
            kdata.bgpos=pos;
            kdata.bg=roi;
            if isfield(kdata,'bgrect'),if ishandle(kdata.bgrect)
                    delete(kdata.bgrect);
                end,end
            kdata.bgrect=rectangle('position',pos-[0.5,0.5,0,0],'edgecolor','c','linestyle','--','hittest','off');
            set(kdata.bgrect,'userdata',[p1,p2]);
            set(kdata.bgrect,'hittest','on','Buttondownfcn',...
                @(hObject,eventdata)KymoTracker1('hitrect',hObject,eventdata,guidata(hObject)));
        else
            analyze(handles);
        end
    case {'shaperect','moverect'}
        try, if ishandle(kdata.temprect),
                delete(kdata.temprect);
            end, end
        if kdata.selecttrackingroi
           try, if ishandle(kdata.hrect),
                delete(kdata.hrect);
            end, end
 
            if isfield(kdata,'hittype');
                switch kdata.hittype
                    case 'bgrect'
                        pos=get(kdata.bgrect,'position')+[0.5,0.5,0,0];
                        [mettxt,curtxt,p1,p2,roi]=getmetrics(pos);
                        
                        set(handles.bgroitxt,'string',[{'Background:'};mettxt(10:end)]);
                        kdata.bgpos=pos;
                        kdata.bg=roi;
                        if isfield(kdata,'bgrect'),if ishandle(kdata.bgrect)
                                delete(kdata.bgrect);
                            end,end
                        kdata.bgrect=rectangle('position',pos-[0.5,0.5,0,0],'edgecolor','c','linestyle','--','hittest','off');
                        set(kdata.bgrect,'userdata',[p1,p2]);
                        set(kdata.bgrect,'hittest','on','Buttondownfcn',...
                            @(hObject,eventdata)KymoTracker1('hitrect',hObject,eventdata,guidata(hObject)));
                    case 'trrect'
                        pos=get(kdata.trrect,'position')+[0.5,0.5,0,0];
                        [mettxt,curtxt,p1,p2,roi]=getmetrics(pos);
                        
                        kdata.trackingroi=[p1,p2-1];
                        kdata.trackingpos=pos;
                        kdata.trroiim=roi;
                        set(handles.trackingroitxt,'string',mettxt(1:7));
                        if isfield(kdata,'trrect'),if ishandle(kdata.trrect)
                                delete(kdata.trrect);
                            end,end
                        kdata.trrect=rectangle('position',pos-[0.5,0.5,0,0],'edgecolor','g','linestyle','--','hittest','off');
                        set(kdata.trrect,'userdata',[p1,p2]);
                        set(kdata.trrect,'hittest','on','Buttondownfcn',...
                            @(hObject,eventdata)KymoTracker1('hitrect',hObject,eventdata,guidata(hObject)));
                    case 'other'
                end
            end
        else
            analyze(handles);
        end
end
if ishandle(kdata.hrect)
    pos=get(kdata.hrect,'position')+[0.5,0.5,0,0];
    [mettxt,curtxt,p1,p2]=getmetrics(pos);
    %if ishandle(kdata.hrect), set(kdata.hrect,'userdata',[p1,p2]); end
    set(handles.metrictxt,'string',mettxt);
    set(handles.currenttxt,'string',curtxt);
    %set(kdata.hrect,'hittest','off');
    set(kdata.hrect,'hittest','on','Buttondownfcn',...
        @(hObject,eventdata)KymoTracker1('hitrect',hObject,eventdata,guidata(hObject)));
end

function hitrect(hObject, event, handles)
global kdata
switch get(gcf,'selectiontype');
    case 'normal'
       kdata.action='shaperect'
    case 'alt'
        kdata.action='moverect'
end
clr=get(hObject,'edgecolor');
if ~kdata.selecttrackingroi&(clr==[0,1,0]|clr==[0,1,1])
    return
end
if clr==[0,1,1];
    kdata.hitrect=kdata.bgrect; kdata.hittype='bgrect'; 'cyan'
elseif clr==[0,1,0];
    kdata.hitrect=kdata.trrect; kdata.hittype='trrect'; 'green'
else
    kdata.hitrect=kdata.hrect; kdata.hittype='other';
end 
'hit it!'
point1 = get(handles.imaxes,'CurrentPoint'); % button down detected
point1 = (point1(1,1:2))           % extract x and y 
POS=get(gco,'position')+[0.5,0.5,0,0];
pos=POS+[0,0,POS(1:2)]
hit=[0,0,0,0];
wh=[];
d=2.05;
if abs(point1(1)-pos(1))<d,hit(1)=1; wh=[wh,'L']; end
if abs(point1(1)-pos(3))<d,hit(3)=1; hit(1)=0; wh=[wh,'R']; end
if abs(point1(2)-pos(2))<d,hit(2)=1; wh=[wh,'U']; end
if abs(point1(2)-pos(4))<d,hit(4)=1; hit(2)=0; wh=[wh,'D']; end
wh,hit
if sum(hit)>=3, return, end
clear event
event.point1=point1;
event.action=kdata.action;
event.hit=logical(hit);
event.oldpos=POS;
set(gcf,'windowbuttonupfcn',@(hObject,eventdata)KymoTracker1...
    ('fig1_WindowButtonUpFcn',hObject, event, guidata(hObject)));
set(gcf,'windowbuttonmotionfcn',@(hObject,eventdata)KymoTracker1...
    ('fig1_WindowButtonMotionFcn',hObject, event, guidata(hObject)));


function [p1,p2,roi]=pos2p1p2(pos)
% uses filtered data pos (ll, w,h) to calculate raw data p1 (LL) p2 (UR)
% and ROI
global kdata
    p1=round((pos([2,1])-1).*kdata.sum+kdata.roi(1:2));    % index LL
    p2=round(p1+pos([4,3]).*kdata.sum);                 % index UR
    p1=max(p1,[1,1]);       % limit LL to image dim
    p2=min(p2,kdata.dim);    % limit UR to image dim
    roi=round([p2(1)-p1(1),p2(2)-p1(2)]);

    
function [mettxt,curtxt,p1,p2,tmp]=getmetrics(pos)
% This function gets metrics from a selected rectangle position on the
% image. Output is metric text and LL and UR points in raw kdata space.
% type specifies metrics output or currentpoint output
global kdata
tmp=[];
[p1,p2,roi]=pos2p1p2(pos);
% Convert ROI range to absolute pixel values
pixLL=['pix: (',num2str(p1(1)),', ',num2str(p1(2)),')'];   % output txt for metrics
pixUR=[' => (',num2str(p2(1)-1),', ',num2str(p2(2)-1),')'];
try
    % Convert absolute pixel to actual SI units
    si1=(p1.*kdata.pixdim);
    si2=(p2-1).*kdata.pixdim;
    x1=[num2str(si1(1)),' ',kdata.pixunit{1}];   % output strings
    x2=[num2str(si2(1)),' ',kdata.pixunit{1}];
    switch kdata.imtype                      % lookup time kdata if needed
        case {'image','imimage','txtimage'}
            y1=[num2str(si1(2)),' ',kdata.pixunit{2}];
            y2=[num2str(si2(2)),' ',kdata.pixunit{2}];
        case {'kymo','txtkymo','imkymo'}
            y1=kdata.time(1,p1(2));
            y1=[num2str(y1),' ',kdata.pixunit{2}];
            y2=kdata.time(1,p2(2));
            y2=[num2str(y2),' ',kdata.pixunit{2}];
    end
    siLL=['SI:  (',x1,', ',y1,')'];
    siUR=[' => (',x2,', ',y2,')'];
    if roi==[1,1]|roi==[0,0]
        pix={[pixLL]};
        si={[siLL]};
    else
        pix={[pixLL,pixUR]};
        si={[siLL,siUR]};
    end
    % Get ROI size in pixel values and actual units
    roipix={['pix: (',num2str(roi(1)),', ',num2str(roi(2)),')']};  % output txt for metrics
    % Convert absolute pixel to actual units
    roixy=(roi.*kdata.pixdim);
    roix=[num2str(roixy(1)),' ',kdata.pixunit{1}];
    dt=kdata.time(1,(p2(2)))-kdata.time(1,(p1(2)));
    dt=[num2str(dt),' ms'];
    switch kdata.imtype                      % lookup time kdata if needed
        case {'image','imimage','txtimage'}
            roiy=[num2str(roixy(2)),' ',kdata.pixunit{2}];
        case {'kymo','txtkymo','imkymo'}
            roiy=dt;
    end
    roisi=['SI:  (',roix,', ',roiy,')'];
    % Get area and intensities for RAW kdata
    Npix=prod(roi);
    I=kdata.im(p1(1):p2(1)-1,p1(2):p2(2)-1,:);
    Ir=sum(sum(I(:,:,1)));
    Ig=sum(sum(I(:,:,2)));
    Ib=sum(sum(I(:,:,3)));
    if kdata.selecttrackingroi
        ich=find(kdata.chdisp);
        Ich=I(:,:,ich);
        Atxt={['- Mean intensity in ',num2str(Npix),' pixel area (raw) [filtered]']};
        Istd=['(',num2str(std(Ich(:))),')'];
        Imean=['(',num2str(sum(sum(Ich))/Npix),')'];
        % Now get area and intensities for FILTERED kdata
        proi1=round((pos([2,1])));    % index LL
        proi2=round(proi1+pos([4,3]));                 % index UR
        proi1=max(proi1,[1,1]);    % limit LL to image dim
        proi2=min(proi2,kdata.roidim);    % limit UR to image dim
        I=kdata.roiim(proi1(1):proi2(1)-1,proi1(2):proi2(2)-1,:);
        Ich=I(:,:,ich);
        bg.bgMean=sum(sum(Ich))/Npix;
        bg.bgStd=std(Ich(:));
        tmp=Ich;                % export background roi
        IMean={['Imean: ',Imean,' [',num2str(bg.bgMean),']']};
        IStd={['Istd: ',Istd,' [',num2str(bg.bgStd),']']};
        mettxt=[{'- ROI position (raw data)'};pix;si;{[]};{'- ROI size (raw data)'};...
            roipix;roisi;{[]};Atxt;IMean;IStd;];
        curtxt=[{'- Current point'};{[pixLL,' ',siLL,' line:',dt]};...
            {[IMean{1}]}];
    else
        Atxt={['- RGB intensity in ',num2str(Npix),' pixel area (raw) [filtered]']};
        Isum=['(',num2str(Ir),', ',num2str(Ig),', ',num2str(Ib),')'];
        Imean=['(',num2str(Ir/Npix),', ',num2str(Ig/Npix),', ',num2str(Ib/Npix),')'];
        % Now get area and intensities for FILTERED kdata
        proi1=round((pos([2,1])));    % index LL
        proi2=round(proi1+pos([4,3]));                 % index UR
        proi1=max(proi1,[1,1]);    % limit LL to image dim
        proi2=min(proi2,kdata.roidim);    % limit UR to image dim
        I=kdata.roiim(proi1(1):proi2(1)-1,proi1(2):proi2(2)-1,:);
        Ir=sum(sum(I(:,:,1)));
        Ig=sum(sum(I(:,:,2)));
        Ib=sum(sum(I(:,:,3)));
        ISum={['Isum: ',Isum,' [',num2str(Ir),', ',num2str(Ig),', ',num2str(Ib),']']};
        IMean={['I/pix: ',Imean,' [',num2str(Ir/Npix),', ',num2str(Ig/Npix),', ',num2str(Ib/Npix),']']};
        mettxt=[{'- ROI position (raw data)'};pix;si;{[]};{'- ROI size (raw data)'};...
            roipix;roisi;{[]};Atxt;ISum;IMean];
%         curtxt=[{'- Current point'};{[pixLL,' ',siLL,' line:',dt]};...
%             {['RGB intensity: ',Isum,' [',num2str(Ir),', ',num2str(Ig),', ',num2str(Ib),']']}];
    curtxt=[{'- Current point'};...
        {['RGB intensity: ',Isum,' [',num2str(Ir),', ',num2str(Ig),', ',num2str(Ib),']']};...
        {[pixLL,' ',siLL,' line:',dt]}];
    end
catch
    pix={[pixLL,pixUR]};
    dat={['DATA: [',num2str(kdata.dim(1)),', ',num2str(kdata.dim(2)),']']};
    mettxt=[{'- ROI position outside data'};pix;dat];
    curtxt=[];
end

function fitmenu_Callback(hObject, eventdata, handles)
analyze(handles);

function analysismenu_Callback(hObject, eventdata, handles)
global kdata
analysis=get(hObject,'string');
kdata.analysis=analysis{get(hObject,'value')};
analyze(handles);



function analyze(handles)
global kdata
exitflag=0;
set(handles.loadtxt,'string','Analyzing','backgroundcolor','y');
% Get photon distributions to analyze
try
    if ishandle(kdata.hrect)&sum(kdata.chdisp)==1         % Get roi coordinates
        roi=get(kdata.hrect,'userdata')-[0,0,1,1]
        dat=kdata.im(roi(1):roi(3),roi(2):roi(4),find(kdata.chdisp));
        switch kdata.analysis
            case 'Sum rows'
                profile=squeeze(sum(dat,2));
                Nsummed=size(dat,2);
                x=(0:(length(profile)-1))*kdata.pixdim(1);
                xtxt=['Position [',kdata.pixunit{1},']'];  
                ytxt=['Photon count'];
            case 'Sum columns'
                profile=squeeze(sum(dat,1));
                Nsummed=size(dat,1);
                ytxt=['Photon count'];
                switch kdata.imtype              % lookup time data if needed
                    case {'image','imimage','txtimage'}
                        x=(0:(length(profile)-1))*kdata.pixdim(2);
                        xtxt=['Position [',kdata.pixunit{2},']'];
                    case {'kymo','txtkymo','imkymo'}
                        x=kdata.time(1,(roi(2):roi(4)));
                        xtxt=['Time [',kdata.pixunit{2},']'];
                end
            case 'No analysis'
                exitflag=1;
        end
    else
        exitflag=1;
    end
          switch kdata.analysis      
            case {'R count' 'G count' 'B count' ...
                    'R cnt-bg' 'G cnt-bg' 'B cnt-bg'}
                exitflag=0;
                % Get trackindex
                tri=get(handles.trackindexmenu,'string');
                tri=tri{get(handles.trackindexmenu,'value')};
                tri=str2num(tri);
                % Get trackingroi
                troi=kdata.trackingroi;
                p1=troi(1:2);
                p2=troi(3:4);%[troi(3)-troi(1),troi(4)-troi(2)];
%                 [p1,p2,roi]=pos2p1p2([p1,p2])%trackingpos);
%                 % Relevant section modified from pos2p1p2
%                 p1=round((kdata.trackingpos([2,1])-1).*kdata.sum+[1,1]);    % index LL
%                 p2=round(p1+kdata.trackingpos([4,3]).*kdata.sum);                 % index UR
%                 p1=max(p1,[1,1]);       % limit LL to image dim
%                 p2=min(p2,kdata.dim);    % limit UR to image dim
                
                %I=kdata.im(p1(1):p2(1)-1,p1(2):p2(2)-1,:);
                I=kdata.im(p1(1):p2(1),p1(2):p2(2),:);
                i=tri;
                traj=kdata.trajectories;
                N=length(traj(i).y);
                %npixforI=kdata.npixforI;
                % Find number of pixels needed to get > 95% (2 sd) of PSF
                psf=kdata.trajectories(i).psf*kdata.pixdim(1);
                meanpsf=mean(psf(find(psf~=0&~isnan(psf))));
                npixforI=ceil(4*meanpsf/kdata.pixdim(1));

                NpixforI=ones(1,N)*npixforI;
                iLineROI=traj(i).i;
                iNaN=(iLineROI==0)|isnan(iLineROI);
                iPosROI=traj(i).y; iPosROI(iNaN)=NaN;
                IntensityPix3=zeros(1,N,3);
                for j=1:N
                    if ~isnan(iPosROI(j))&(iPosROI(j)~=0)
                        ipix=(iPosROI(j)-(npixforI/2-0.5)):1:(iPosROI(j)+(npixforI/2-0.5));
                        ipix=round(ipix);
                        ipix=ipix((ipix>=1)&(ipix<=size(kdata.trroiim,1)));
                        % Get RGB values
                        IntensityPix3(1,j,1)=sum(I(ipix,iLineROI(j),1));
                        IntensityPix3(1,j,2)=sum(I(ipix,iLineROI(j),2));
                        IntensityPix3(1,j,3)=sum(I(ipix,iLineROI(j),3));
                    else
                        IntensityPix3(1,j,:)=NaN;
                    end
                end
                bg3=kdata.bgParam3.bgMeanAbs3'*NpixforI;    % get stuff for all channels
                IntensityPix3=squeeze(IntensityPix3)';
                IntPix3BgCorrect=IntensityPix3-bg3;
                
                
                x=kdata.trajectories(tri).i;
                switch  kdata.analysis
                    case 'R count'
                profile=IntensityPix3(1,:);
                 ytxt=['Red Photon count'];
                    case 'G count'
                profile=IntensityPix3(2,:);
                 ytxt=['Grn Photon count'];
                    case 'B count'
                profile=IntensityPix3(3,:);
                 ytxt=['Blu Photon count'];
                case 'R cnt-bg'
                profile=IntPix3BgCorrect(1,:);
                 ytxt=['Red count-backgr'];
                case 'G cnt-bg'
                profile=IntPix3BgCorrect(2,:);
                 ytxt=['Gre count-backgr'];
                case 'B cnt-bg'
                profile=IntPix3BgCorrect(3,:);
                 ytxt=['Blu count-backgr'];
 
                end
%                prof0=find(profile~=0);
%                 profile=profile(prof0);
%                 x=x(prof0);
                Nsummed=1;
                xtxt=['Pixel index'];  

            case 'amp'
                exitflag=0;
                tri=get(handles.trackindexmenu,'string');
                tri=tri{get(handles.trackindexmenu,'value')};
                tri=str2num(tri);
                profile=kdata.kymonorm*kdata.trajectories(tri).amp/kdata.sum(2);
                x=kdata.trajectories(tri).i;
                prof0=find(profile~=0);
                profile=profile(prof0);
                x=x(prof0);
                Nsummed=1;
                xtxt=['Pixel index'];  
                ytxt=['Amplitude [photons]'];
            case 'N=amp*sqrt(2pi)*s/dx'
                exitflag=0;
                tri=get(handles.trackindexmenu,'string');
                tri=tri{get(handles.trackindexmenu,'value')};
                tri=str2num(tri);
                sigma=kdata.trajectories(tri).psf*kdata.pixdim(1);
                profile=kdata.kymonorm*kdata.trajectories(tri).amp/kdata.sum(2);
                profile=profile.*sigma*sqrt(2*pi)/kdata.pixdim(1);
                x=kdata.trajectories(tri).i;
                prof0=find(profile~=0);
                profile=profile(prof0);
                x=x(prof0);
                Nsummed=1;
                xtxt=['Pixel index'];  
                ytxt=['Integr Amplitude [photons]'];
            case 'x'
                exitflag=0;
                tri=get(handles.trackindexmenu,'string');
                tri=tri{get(handles.trackindexmenu,'value')};
                tri=str2num(tri);
                profile=kdata.trajectories(tri).x*kdata.pixdim(1);
                x=kdata.trajectories(tri).i;
                prof0=find(profile~=0);
                profile=profile(prof0);
                x=x(prof0);
                Nsummed=1;
                xtxt=['Pixel index'];  
                ytxt=['x [nm]'];
            case 'y'
                exitflag=0;
                tri=get(handles.trackindexmenu,'string');
                tri=tri{get(handles.trackindexmenu,'value')};
                tri=str2num(tri);
                profile=kdata.trajectories(tri).y*kdata.pixdim(2);
                x=kdata.trajectories(tri).i;
                prof0=find(profile~=0);
                profile=profile(prof0);
                x=x(prof0);
                Nsummed=1;
                xtxt=['Pixel index'];  
                ytxt=['y [nm]'];
            case 'psf'
                exitflag=0;
                tri=get(handles.trackindexmenu,'string');
                tri=tri{get(handles.trackindexmenu,'value')};
                tri=str2num(tri);
                profile=kdata.trajectories(tri).psf*kdata.pixdim(1);
                x=kdata.trajectories(tri).i;
                prof0=find(profile~=0);
                profile=profile(prof0);
                x=x(prof0);
                Nsummed=1;
                xtxt=['Pixel index'];  
                ytxt=['psf [nm]'];
        end
        if length(profile)<=1%|isempty(dat)
            exitflag=1;
        end
catch
    exitflag=1;
end
if exitflag         % exit because we will not analyze this crap
    axes(handles.analysisaxes), cla;
    set(handles.analysisaxes,'visible','on');
    set(handles.analysistxt,'visible','on');
    set(handles.loadtxt,'string','Done','backgroundcolor','g');
    return
end
% Plot photon distribution
axes(handles.analysisaxes), cla;    % switch on axes
set(handles.analysisaxes,'visible','on');
hscatter=plot(x,profile,'o-');
%hbar=bar(x,profile,'hist'); 
axis tight, hold on   
size(x), size(profile)% plot bar graph of raw data
set(handles.analysisaxes,'ylim',[0,1.1*max(profile)]);
set(handles.analysisaxes,'userdata',[min(x),max(x),0,1.1*max(profile)]);
%set(hbar,'facecolor','r','edgecolor',[0.7,0,0]);
set(hscatter,'markersize',2,'markeredgecolor','k','markerfacecolor','k','color','r');

c=uicontextmenu;
kdata.handles.analysisaxes.UIContextMenu=c;
uimenu(c,'Label','Save data to spreadsheet','Callback',...
    @(hObject,eventdata)KymoTracker1('saveplots_Callback',hObject,eventdata,guidata(hObject)));
uimenu(c,'Label','Open in new figure','Callback',...
    @(hObject,eventdata)KymoTracker1('openinnewfig_Callback',hObject,eventdata,guidata(hObject)));
uimenu(c,'Label','Add plots to last new figure','Callback',...
    @(hObject,eventdata)KymoTracker1('addplotstofig_Callback',hObject,eventdata,guidata(hObject)));

% Prepare fit functions
fitfunc = get(handles.fitmenu,'string');
fitfunc = fitfunc{get(handles.fitmenu,'value')};
fitflag=1;
switch fitfunc
    case 'No fitting'
        fitflag=0;
    case 'Gauss + offset'
        fitfnc=fittype('Amp*exp(-(x-x0)^2/(2*sd^2))+offset');   % equation object
        amp=max(profile)-min(profile);                  % estimate amplitude
        ctr=mean(x(find(profile==max(profile))));       % estimate center position
        sd=100;                                         % estimate standard deviation
        ofs=min(profile);                               % estimate offset
        startpoint=[amp,ofs,sd,ctr];
        lower=[0,0,0,min(x)];
        upper=[max(profile(:)),max(profile(:)),1000,max(x)];
        probl=[];
   case 'Gauss'
        fitfnc=fittype('Amp*exp(-(x-x0)^2/(2*sd^2))');   % equation object
        amp=max(profile)-min(profile);                  % estimate amplitude
        ctr=mean(x(find(profile==max(profile))));       % estimate center position
        sd=100;                                         % estimate standard deviation
        startpoint=[amp,sd,ctr];
        lower=[0,0,min(x)];
        upper=[max(profile(:)),1000,max(x)];
         probl=[];
   case 'Constant'
        fitfnc=fittype(@(mean, x) mean+0*x);   % equation object
        ofs=mean(profile);                  % estimate offsset
        startpoint=[ofs];
        lower=[0];
        upper=[max(profile(:))];
        probl=[];
    case '1 step'
        n=length(profile);
        fitfnc=fittype('fnc1step(x,mean1,mean2,step,dx)','problem','dx');   % equation object
        mean1=mean(profile(1:ceil(n/4)));                  % estimate offset1
        mean2=mean(profile(floor(n*3/4):end));                  % estimate offset1
        step=mean(x);
        startpoint=[mean1,mean2,step]
        lower=[0,0,min(x)];
        upper=[max(profile(:)),max(profile(:)),max(x)];
        dx=mean(x(2:end)-x(1:end-1));
        probl=3*dx
    case '2 steps'
        n=length(profile);
        fitfnc=fittype('fnc2step(x,mean1,mean2,mean3,step1,step2,dx)','problem','dx');   % equation object
        mean1=mean(profile(1:ceil(n/4)));                  % estimate offset1
        mean2=mean(profile(floor(3*n/8):ceil(5*n/8)));                  % estimate offset1
        mean3=mean(profile(floor(n*3/4):end));                  % estimate offset1
        step1=x(1)+(x(end)-x(1))/3;
        step2=x(end)-(x(end)-x(1))/3;
        startpoint=[mean1,mean2,mean3,step1,step2]
        lower=[0,0,0,min(x),min(x)];
        upper=[max(profile(:)),max(profile(:)),max(profile(:)),max(x),max(x)];
        dx=mean(x(2:end)-x(1:end-1));
        probl=3*dx
case 'exp + offset'
        fitfnc=fittype('I0*exp(-((x-t0)/tau))+Ioffset','problem','t0');   % equation object
        I0=max(profile)-min(profile);                  % estimate amplitude
        tau=max(x)-min(x);       % estimate center position
        ofs=min(profile);                               % estimate offset
        startpoint=[I0,ofs,tau];
        lower=[1,0,0];
        upper=[1e10*max(profile(:)),max(profile(:)),1e10*max(x)];
        probl=x(1);
case 'exp'
        fitfnc=fittype('I0*exp(-((x-t0)/tau))','problem','t0');   % equation object
        I0=max(profile)-min(profile);                  % estimate amplitude
        tau=max(x)-min(x);       % estimate center position
        ofs=min(profile);                               % estimate offset
        startpoint=[I0,tau];
        lower=[1,0];
        upper=[1e10*max(profile(:)),1e10*max(x)];
        probl=x(1);
case '2exp + offset'
        fitfnc=fittype('I1*exp(-((x-t0)/tau1))+I2*exp(-((x-t0)/tau2))+Ioffset','problem','t0');   % equation object
        I1=max(profile)-min(profile);                  % estimate amplitude
        I2=I1/2;                  % estimate amplitude
        tau1=max(x)-min(x);       % estimate center position
        tau2=tau1*2;       % estimate center position
        ofs=min(profile);                               % estimate offset
        startpoint=[I1,I2,ofs,tau1,tau2];
        lower=[1,1,0,0,0];
        upper=[1e10*max(profile(:)),1e10*max(profile(:)),max(profile(:)),1e10*max(x),1e10*max(x)];
        probl=x(1);
case '2exp'
        fitfnc=fittype('I1*exp(-((x-t0)/tau1))+I2*exp(-((x-t0)/tau2))','problem','t0');   % equation object
        I1=max(profile)-min(profile);                  % estimate amplitude
        I2=I1/2;                  % estimate amplitude
        tau1=max(x)-min(x);       % estimate center position
        tau2=tau1*2;       % estimate center position
        startpoint=[I1,I2,tau1,tau2];
        lower=[1,1,0,0];
        upper=[1e10*max(profile(:)),1e10*max(profile(:)),1e10*max(x),1e10*max(x)];
        probl=x(1);
end

if fitflag
    if isempty(probl)       % Fit
        cfit=fit(x(:),profile(:),fitfnc,'startpoint',startpoint,'lower',lower,...
            'upper',upper);  % fit
    else
        cfit=fit(x(:),profile(:),fitfnc,'startpoint',startpoint,'lower',lower,...
            'upper',upper,'problem',probl);  % fit with problem-dependent parameter
    end
    % post process fit
    axes(handles.analysisaxes)
    hfit=plot(cfit,'b');                 % plot and post-processing
    set(hfit,'linewidth',2);
    axes(handles.analysisaxes), plot(x,predint(cfit,x),'c:')
    legend off
    xlabel(xtxt);
    ylabel(ytxt);
    names=coeffnames(cfit);
    vals=coeffvalues(cfit);
    int=confint(cfit,0.682);
    int=(int(2,:)-int(1,:))/2;
end
switch fitfunc      % prepare output texts
    case 'No fitting'
        fittxt={'No fit'};
    case 'Gauss + offset'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
    [names{3},' = ',num2str(vals(3)),' +/- ',num2str(int(3))];...
    [names{4},' = ',num2str(vals(4)),' +/- ',num2str(int(4))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    kdata.xgauss=roi(1)+(vals(4))/kdata.pixdim(1)      % save x0 for bead location
    case 'exp'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)),' +/- ',num2str(int(2))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    case 'exp + offset'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
    [names{3},' = ',num2str(vals(3)),' +/- ',num2str(int(3))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    case '2exp + offset'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
    [names{3},' = ',num2str(vals(3)/Nsummed),' +/- ',num2str(int(3)/Nsummed)];...
    [names{4},' = ',num2str(vals(4)),' +/- ',num2str(int(4))];...
    [names{5},' = ',num2str(vals(5)),' +/- ',num2str(int(5))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    case '2exp'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
    [names{3},' = ',num2str(vals(3)),' +/- ',num2str(int(3))];...
    [names{4},' = ',num2str(vals(4)),' +/- ',num2str(int(4))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
 
    case 'Gauss'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)),' +/- ',num2str(int(2))];...
    [names{3},' = ',num2str(vals(3)),' +/- ',num2str(int(3))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    kdata.xgauss=roi(1)+(vals(3))/kdata.pixdim(1)      % save x0 for bead location
    
    case 'Constant'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    case '1 step'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
    [names{3},' = ',num2str(vals(3)),' +/- ',num2str(int(3))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    case '2 steps'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
    [names{3},' = ',num2str(vals(3)/Nsummed),' +/- ',num2str(int(3)/Nsummed)];...
    [names{4},' = ',num2str(vals(4)),' +/- ',num2str(int(4))];...
    [names{5},' = ',num2str(vals(5)),' +/- ',num2str(int(5))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
end
set(handles.analysistxt,'visible','on','string',fittxt,'value',10);
set(handles.loadtxt,'string','Done','backgroundcolor','g');
set(handles.analysisaxes,'buttondownfcn',@(hObject,eventdata)KymoTracker1...
 ('analysisaxes_ButtonDownFcn',hObject,eventdata,guidata(hObject)));
set(get(handles.analysisaxes,'children'),'hittest','off');

% Prepare fit functions OLD CODE
% fitfunc = get(handles.fitmenu,'string');
% fitfunc = fitfunc{get(handles.fitmenu,'value')};
% fitflag=1;
% switch fitfunc
%     case 'No fitting'
%         fitflag=0;
%     case 'Gauss + offset'
%         fitfnc=fittype('Amp*exp(-(x-x0)^2/(2*sd^2))+offset');   % equation object
%         amp=max(profile)-min(profile);                  % estimate amplitude
%         ctr=mean(x(find(profile==max(profile))));       % estimate center position
%         sd=100;                                         % estimate standard deviation
%         ofs=min(profile);                               % estimate offset
%         startpoint=[amp,ofs,sd,ctr];
%         lower=[0,0,0,min(x)];
%         upper=[max(profile(:)),max(profile(:)),1000,max(x)];
%         probl=[];
%    case 'Gauss'
%         fitfnc=fittype('Amp*exp(-(x-x0)^2/(2*sd^2))');   % equation object
%         amp=max(profile)-min(profile);                  % estimate amplitude
%         ctr=mean(x(find(profile==max(profile))));       % estimate center position
%         sd=100;                                         % estimate standard deviation
%         startpoint=[amp,sd,ctr];
%         lower=[0,0,min(x)];
%         upper=[max(profile(:)),1000,max(x)];
%          probl=[];
%    case 'Constant'
%         fitfnc=fittype(@(mean, x) mean+0*x);   % equation object
%         ofs=mean(profile);                  % estimate offsset
%         startpoint=[ofs];
%         lower=[0];
%         upper=[max(profile(:))];
%         probl=[];
%     case '1 step'
%         n=length(profile);
%         fitfnc=fittype('fnc1step(x,mean1,mean2,step,dx)','problem','dx');   % equation object
%         mean1=mean(profile(1:ceil(n/4)));                  % estimate offset1
%         mean2=mean(profile(floor(n*3/4):end));                  % estimate offset1
%         step=mean(x);
%         startpoint=[mean1,mean2,step]
%         lower=[0,0,min(x)];
%         upper=[max(profile(:)),max(profile(:)),max(x)];
%         dx=mean(x(2:end)-x(1:end-1));
%         probl=3*dx
%     case '2 steps'
%         n=length(profile);
%         fitfnc=fittype('fnc2step(x,mean1,mean2,mean3,step1,step2,dx)','problem','dx');   % equation object
%         mean1=mean(profile(1:ceil(n/4)));                  % estimate offset1
%         mean2=mean(profile(floor(3*n/8):ceil(5*n/8)));                  % estimate offset1
%         mean3=mean(profile(floor(n*3/4):end));                  % estimate offset1
%         step1=x(1)+(x(end)-x(1))/3;
%         step2=x(end)-(x(end)-x(1))/3;
%         startpoint=[mean1,mean2,mean3,step1,step2]
%         lower=[0,0,0,min(x),min(x)];
%         upper=[max(profile(:)),max(profile(:)),max(profile(:)),max(x),max(x)];
%         dx=mean(x(2:end)-x(1:end-1));
%         probl=3*dx
% end
% if fitflag
%     if isempty(probl)       % Fit
%         cfit=fit(x(:),profile(:),fitfnc,'startpoint',startpoint,'lower',lower,...
%             'upper',upper);  % fit
%     else
%         cfit=fit(x(:),profile(:),fitfnc,'startpoint',startpoint,'lower',lower,...
%             'upper',upper,'problem',probl);  % fit with problem-dependent parameter
%     end
%     % post process fit
%     axes(handles.analysisaxes)
%     hfit=plot(cfit,'b');                 % plot and post-processing
%     set(hfit,'linewidth',2);
%     axes(handles.analysisaxes), plot(x,predint(cfit,x),'c:')
%     legend off
%     xlabel(xtxt);
%     ylabel(ytxt);
%     names=coeffnames(cfit);
%     vals=coeffvalues(cfit);
%     int=confint(cfit,0.682);
%     int=(int(2,:)-int(1,:))/2;
% end
% 
% switch fitfunc      % prepare output texts
%     case 'No fitting'
%         fittxt={'No fit'};
%     case 'Gauss + offset'
%     fittxt={...
%     [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
%     [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
%     [names{3},' = ',num2str(vals(3)),' +/- ',num2str(int(3))];...
%     [names{4},' = ',num2str(vals(4)),' +/- ',num2str(int(4))];...
%     ['# raw data lines: ',num2str(Nsummed)];...
%     ['Equation: ',formula(cfit)]}
%     kdata.xgauss=roi(1)+(vals(4))/kdata.pixdim(1)      % save x0 for bead location
%     case 'Gauss'
%     fittxt={...
%     [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
%     [names{2},' = ',num2str(vals(2)),' +/- ',num2str(int(2))];...
%     [names{3},' = ',num2str(vals(3)),' +/- ',num2str(int(3))];...
%     ['# raw data lines: ',num2str(Nsummed)];...
%     ['Equation: ',formula(cfit)]}
%     kdata.xgauss=roi(1)+(vals(3))/kdata.pixdim(1)      % save x0 for bead location
%     case 'Constant'
%     fittxt={...
%     [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
%     ['# raw data lines: ',num2str(Nsummed)];...
%     ['Equation: ',formula(cfit)]}
%     case '1 step'
%     fittxt={...
%     [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
%     [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
%     [names{3},' = ',num2str(vals(3)),' +/- ',num2str(int(3))];...
%     ['# raw data lines: ',num2str(Nsummed)];...
%     ['Equation: ',formula(cfit)]}
%     case '2 steps'
%     fittxt={...
%     [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
%     [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
%     [names{3},' = ',num2str(vals(3)/Nsummed),' +/- ',num2str(int(3)/Nsummed)];...
%     [names{4},' = ',num2str(vals(4)),' +/- ',num2str(int(4))];...
%     [names{5},' = ',num2str(vals(5)),' +/- ',num2str(int(5))];...
%     ['# raw data lines: ',num2str(Nsummed)];...
%     ['Equation: ',formula(cfit)]}
% end
% 
% set(handles.analysistxt,'visible','on','string',fittxt,'value',10);
% set(handles.loadtxt,'string','Done','backgroundcolor','g');
% set(handles.analysisaxes,'buttondownfcn',@(hObject,eventdata)KymoTracker1...
%  ('analysisaxes_ButtonDownFcn',hObject,eventdata,guidata(hObject)));
% set(get(handles.analysisaxes,'children'),'hittest','off');


% --- Executes on button press in trackroibutton.
function trackroibutton_Callback(hObject, eventdata, handles)
% hObject    handle to trackroibutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global kdata
val=get(hObject,'value');
if val  %Select == ON
    kdata.selecttrackingroi=1;
    kdata.edittracks=0;
    set(handles.edittracksbutton,'value',0);
else
    kdata.selecttrackingroi=0;
end


function trackingroitxt_Callback(hObject, eventdata, handles)
function trackingroitxt_CreateFcn(hObject, eventdata, handles)
function bgroitxt_Callback(hObject, eventdata, handles)
function bgroitxt_CreateFcn(hObject, eventdata, handles)


% --- Executes on button press in findmaxbutton.
function findmaxbutton_Callback(hObject, eventdata, handles)
% hObject    handle to findmaxbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global kdata
% Get tracking roi
% kdata.roi=kdata.trackingroi
% displayfile(handles);
set(handles.loadtxt,'string','Detecting maxima','backgroundcolor',[1,0.5,0]);
drawnow;
% kymo=kdata.trroiim;%kdata.roiim(:,:,find(kdata.chdisp));
% % Normalize tracking roi and get background parameters
% kymonorm=max(kymo(:));
% kdata.kymonorm=kymonorm;
% kymo=kymo/kymonorm;
% kdata.kymo=kymo;
% bgMean=mean(kdata.bg(:))/kymonorm;
% bgStd=std(kdata.bg(:))/kymonorm;
% bgParam.bgMean=bgMean;
% bgParam.bgStd=bgStd;
% kdata.bgParam=bgParam;
% % Now repeat for all channels:
% [p1,p2,roi]=pos2p1p2(kdata.bgpos);
% Ibg=kdata.im(p1(1):p2(1)-1,p1(2):p2(2)-1,:);
% IbgR=Ibg(:,:,1);
% IbgG=Ibg(:,:,2);
% IbgB=Ibg(:,:,3);
% bgMeanAbs3=[mean(IbgR(:)),mean(IbgG(:)),mean(IbgB(:))];
% bgStdAbs3=[std(IbgR(:)),std(IbgG(:)),std(IbgB(:))];
% bgParam3.bgMeanAbs3=bgMeanAbs3;
% bgParam3.bgStdAbs3=bgStdAbs3;
% kdata.bgParam3=bgParam3;
[kymo,bgParam]=inittracking;
% Init other necessary parameters
alpha.L=str2num(get(handles.alphalocmaxedit,'string'));
alpha.R=str2num(get(handles.alphaRedit,'string'));
alpha.A=str2num(get(handles.alphaAedit,'string'));
alpha.D=str2num(get(handles.alphaDedit,'string'));
alpha.F=str2num(get(handles.alphaFedit,'string'));
pixsize=kdata.pixdim(1);
exclambda=str2num(get(handles.excedit,'string'));
global hdisp
hdisp=handles.metrictxt;
% Find local maxima
[ movieInfo,exceptions,localMaxima,background,psfSigma ] = ...
    detectGeneralDNA_kymotracker( kymo,bgParam,pixsize,exclambda,alpha )
kdata.localMaxima=localMaxima;
kdata.localMaximaOrig=kdata.trackingroi(1:2);
kdata.locmaxsum=kdata.sum;
kdata.movieInfo=movieInfo;
% Plot local maxima
set(kdata.handles.showmaxbutton,'value',1);
set(kdata.handles.showmovmaxbutton,'value',1);
plotmaxima(localMaxima);
plotmovmax(movieInfo);
set(handles.loadtxt,'string','Done','backgroundcolor','g');

function hmovmax=plotmovmax(movieInfo)
% local function used to plot maxima on main panel
global kdata
maxX=[];
maxY=[];
for i=1:length(movieInfo)
    for j=1:size(movieInfo(i).yCoord,1);
        maxX=[maxX,movieInfo(i).yCoord(j,1)];
        maxY=[maxY,i];
    end
end
maxX=(maxX*kdata.locmaxsum(1)+kdata.localMaximaOrig(1)-kdata.roi(1))./kdata.sum(1);
maxY=(maxY*kdata.locmaxsum(2)+kdata.localMaximaOrig(2)-kdata.roi(2))./kdata.sum(2);
if isfield(kdata,'hmovmax'), if ishandle(kdata.hmovmax)
        delete(kdata.hmovmax);
end, end
axes(kdata.handles.imaxes); hold on;
hmovmax=plot(maxY,maxX,'yo'); hold off;
kdata.hmovmax=hmovmax;
showmovmaxbutton_Callback

function hmaxima=plotmaxima(localMaxima)
% local function used to plot maxima on main panel
global kdata
maxX=[];
maxY=[];
for i=1:length(localMaxima)
    for j=1:length(localMaxima(i).cands);
        maxX=[maxX,localMaxima(i).cands(j).Lmax(1)];
        maxY=[maxY,i];
    end
end
maxX=(maxX*kdata.locmaxsum(1)+kdata.localMaximaOrig(1)-kdata.roi(1))./kdata.sum(1);
maxY=(maxY*kdata.locmaxsum(2)+kdata.localMaximaOrig(2)-kdata.roi(2))./kdata.sum(2);
if isfield(kdata,'hmaxima'), if ishandle(kdata.hmaxima)
        delete(kdata.hmaxima);
end, end
axes(kdata.handles.imaxes); hold on;
hmaxima=plot(maxY,maxX,'co'); hold off;
kdata.hmaxima=hmaxima;
showmaxbutton_Callback

% --- Executes on button press in showmaxbutton.
function showmaxbutton_Callback(hObject, eventdata, handles)
global kdata
if isfield(kdata,'hmaxima'), if ishandle(kdata.hmaxima)
        if get(kdata.handles.showmaxbutton,'value')
            set(kdata.hmaxima,'visible','on');
        else
            set(kdata.hmaxima,'visible','off');
        end
end, end

% --- Executes on button press in showmovmaxbutton.
function showmovmaxbutton_Callback(hObject, eventdata, handles)
global kdata
if isfield(kdata,'hmovmax'), if ishandle(kdata.hmovmax)
        if get(kdata.handles.showmovmaxbutton,'value')
            set(kdata.hmovmax,'visible','on');
        else
            set(kdata.hmovmax,'visible','off');
        end
end, end

% --- Executes on button press in trackbutton.
function trackbutton_Callback(hObject, eventdata, handles)
global kdata
%This file was part of u-track. it calls the tracking functions to link
%maxima
%% Cost functions
%Frame-to-frame linking
set(handles.loadtxt,'string','tracking tracks','backgroundcolor',[1,0.5,0]);
drawnow;
costMatrices(1).funcName = 'costMatLinearMotionLink2';
%Gap closing, merging and splitting
costMatrices(2).funcName = 'costMatLinearMotionCloseGaps2PsfBgr';
%% Kalman filter functions
%Memory reservation
kalmanFunctions.reserveMem = 'kalmanResMemLM';
%Filter initialization
kalmanFunctions.initialize = 'kalmanInitLinearMotion';
%Gain calculation based on linking history
kalmanFunctions.calcGain = 'kalmanGainLinearMotion';
%Time reversal for second and third rounds of linking
kalmanFunctions.timeReverse = 'kalmanReverseLinearMotion';
%% General tracking parameters
%Gap closing time window (was 3)
gapCloseParam.timeWindow = str2num(get(handles.mintrajlengthedit,'string'));
%Flag for merging and splitting (was 0)
gapCloseParam.mergeSplit = get(handles.mergesplitbutton,'value');
%Minimum track segment length used in the gap closing, merging and
%splitting step (was 1)
gapCloseParam.minTrackLen = str2num(get(handles.minsegmentedit,'string'));
%Time window diagnostics: 1 to plot a histogram of gap lengths in
%the end of tracking, 0 or empty otherwise
gapCloseParam.diagnostics = 0;
%% Cost function specific parameters: Frame-to-frame linking
%Flag for linear motion
parameters.linearMotion = 1;
%Search radius lower limit (was 2)
parameters.minSearchRadius = str2num(get(handles.minsearchradedit,'string'));
%Search radius upper limit (was 10)
parameters.maxSearchRadius = str2num(get(handles.maxsearchradedit,'string'));
%Standard deviation multiplication factor (was 5)
parameters.brownStdMult = str2num(get(handles.brownstdmultedit,'string'));
%Flag for using local density in search radius estimation
parameters.useLocalDensity = get(handles.uselocaldensitybutton,'value');
%Number of past frames used in nearest neighbor calculation
parameters.nnWindow = gapCloseParam.timeWindow;
%Optional input for diagnostics: To plot the histogram of linking distances
%up to certain frames. For example, if parameters.diagnostics = [2 35],
%then the histogram of linking distance between frames 1 and 2 will be
%plotted, as well as the overall histogram of linking distance for frames
%1->2, 2->3, ..., 34->35. The histogram can be plotted at any frame except
%for the first and last frame of a movie.
%To not plot, enter 0 or empty
parameters.diagnostics = [];
%Store parameters for function call
costMatrices(1).parameters = parameters;
clear parameters
%% Cost function specific parameters: Gap closing, merging and splitting
%Same parameters as for the frame-to-frame linking cost function
parameters.linearMotion = costMatrices(1).parameters.linearMotion;
parameters.useLocalDensity = costMatrices(1).parameters.useLocalDensity;
parameters.minSearchRadius = costMatrices(1).parameters.minSearchRadius;
parameters.maxSearchRadius = costMatrices(1).parameters.maxSearchRadius;
parameters.brownStdMult = costMatrices(1).parameters.brownStdMult*ones(gapCloseParam.timeWindow,1);
parameters.nnWindow = costMatrices(1).parameters.nnWindow;
%Gap length (frames) at which f(gap) (in search radius definition) reaches its
%plateau
parameters.timeReachConfB = gapCloseParam.timeWindow;
%Amplitude ratio lower and upper limits (was [0.7 4])
parameters.ampRatioLimit = [str2num(get(handles.minamplratioedit,'string')),...
    str2num(get(handles.maxamplratioedit,'string'))];
%Minimum length (frames) for track segment analysis
parameters.lenForClassify = str2num(get(handles.lengthforclassifyedit,'string'));
%Standard deviation multiplication factor along preferred direction of
%motion
parameters.linStdMult = 3*ones(gapCloseParam.timeWindow,1);
%Gap length (frames) at which f'(gap) (in definition of search radius
%parallel to preferred direction of motion) reaches its plateau
parameters.timeReachConfL = gapCloseParam.timeWindow;
%Maximum angle between the directions of motion of two linear track
%segments that are allowed to get linked (was 45)
parameters.maxAngleVV = str2num(get(handles.maxangleedit,'string'));
%Gap length penalty (disappearing for n frames gets a penalty of
%gapPenalty^n)
%Note that a penalty = 1 implies no penalty, while a penalty < 1 implies
%that longer gaps are favored (was 1.1)
parameters.gapPenalty = str2num(get(handles.gappenaltyedit,'string'));
%Resolution limit in pixels, to be used in calculating the merge/split search radius
%Generally, this is the Airy disk radius, but it can be smaller when
%iterative Gaussian mixture-model fitting is used for detection (was 2.7)
parameters.resLimit = str2num(get(handles.resolutionlimitedit,'string'));
%Store parameters for function call
costMatrices(2).parameters = parameters;
clear parameters
%% additional input
%disp('exist(expPath))');
%disp(exist('expPath'));
%saveResults
if exist('expPath')==0 || exist('expPath')==2 || isempty(expPath)
    saveResults.dir ='C:\Users\Fos\Documents\MATLAB\utrack\';
    disp('No Path selected');
    disp(['Actual path:' saveResults.dir]);
else
    saveResults.dir=expPath;
end
%saveResults.dir = 'C:/Users/Felix/Documents/MATLAB/u-track/11_02_04/1500_60_58_3/'; %directory where to save input and output
saveResults.filename = 'testTracking.mat'; %name of file where input and output are saved
% saveResults = 0; %don't save results
%verbose
verbose = 1;
%problem dimension
probDim = 2;
% redo background in case someone edited it
bgMean=mean(kdata.bg(:))/kdata.kymonorm;
bgStd=std(kdata.bg(:))/kdata.kymonorm;
bgParam.bgMean=bgMean;
bgParam.bgStd=bgStd;
kdata.bgParam=bgParam;
bgparam=[bgMean,bgStd]
movieInfo=kdata.movieInfo;
for m=1:length(movieInfo)
    if ~isempty(movieInfo(m).bgAmp),
        for n=1:size(movieInfo(m).bgAmp,1)
            movieInfo(m).bgAmp(n,:)=bgparam;
        end
    end
end
kdata.movieInfo=movieInfo;
% Call tracking function
[tracksFinal,kalmanInfoLink,errFlag] = trackCloseGapsKalmanSparse_kymotracker(kdata.movieInfo,...
    costMatrices,gapCloseParam,kalmanFunctions,probDim,saveResults,verbose);
kdata.tracksFinal=tracksFinal;
trajFilterLength=str2num(get(handles.mintrajlengthedit,'string'));
%filter for obtained trajectories
[tracksFinalFiltered]=filterTrajLengthPsfBgr(tracksFinal,trajFilterLength,[0 900],[0 900],[0],[900],[0 2000]);%filters for trajectories with certain properties
kdata.tracksFinalFiltered=tracksFinalFiltered;
%parameters: 1. name of output-variable, 2. minimal trajectory length, 3. window for trajectory start, 4. window for trajectory end
%5. minimal meanRsquared(pixel), 6. maximalSegmentLength, 7. startCoordinate x 
%[trajectories_filtered_all]=getTraj_DNA(tracksFinalFiltered,[],[]);% transforms data structure in a more digestible form
[trajectories]=getTrajIntAmpPsfBgr_kymotracker(tracksFinalFiltered,[],[]);% transforms data structure in a more digestible form
% Plot tracks
kdata.trajectories=trajectories;
set(kdata.handles.showtracksbutton,'value',1);      % tracks on
set(kdata.handles.showtracklabelbutton,'value',1);      % tracks on
set(kdata.handles.trackroibutton,'value',0);        % set to zooming action
set(kdata.handles.edittracksbutton,'value',0);        % set to zooming action
kdata.edittracks=0;
kdata.selecttrackingroi=0;
set(kdata.handles.showmaxbutton,'value',0); showmaxbutton_Callback
set(kdata.handles.showmovmaxbutton,'value',0); showmovmaxbutton_Callback
plottracks(trajectories);
tracks=kdata.tracksFinalFiltered;
undo.tracksFinalFiltered=tracks;
kdata.undoall=undo;
undoredoshift('reset');
set(handles.loadtxt,'string','Done','backgroundcolor','g');
% Add track display to analysis options
tri=[];
for i=1:length(trajectories)
    tri=[tri,{num2str(i)}];
end
set(handles.trackindexmenu,'string',tri,'value',i,'visible','on');
c=uicontextmenu;
kdata.handles.analysisaxes.UIContextMenu=c;
uimenu(c,'Label','Save data to spreadsheet','Callback',...
    @(hObject,eventdata)KymoTracker1('saveplots_Callback',hObject,eventdata,guidata(hObject)));
uimenu(c,'Label','Open in new figure','Callback',...
    @(hObject,eventdata)KymoTracker1('openinnewfig_Callback',hObject,eventdata,guidata(hObject)));
uimenu(c,'Label','Add plots to last new figure','Callback',...
    @(hObject,eventdata)KymoTracker1('addplotstofig_Callback',hObject,eventdata,guidata(hObject)));


% --------------------------------------------------------------------
function openinnewfig_Callback(hObject, eventdata, handles)
% hObject    handle to showlinetimes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global kdata
fig=figure;
kdata.newfig=fig;
hnew=copyobj(handles.analysisaxes,fig);
kdata.newaxes=hnew;
% outpos=get(hnew,'OuterPosition');
% set(fig,'position',outpos);
% set(hnew,'OuterPosition',[0,0,outpos(3:4)]);
set(hnew,'units','normalized','outerposition',[0,0,1,1]);

% --------------------------------------------------------------------
function addplotstofig_Callback(hObject, eventdata, handles)
% hObject    handle to showlinetimes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global kdata
if isfield(kdata,'newaxes'), if ishandle(kdata.newaxes)
hnew=copyobj(findobj(handles.analysisaxes,'type','line'),...
    kdata.newaxes);
axes(kdata.newaxes), axis tight
end, end


function saveplots_Callback(hObject, eventdata, handles)
% hObject    handle to showlinetimes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global kdata
lines=findobj(handles.analysisaxes,'type','line');
if length(lines)==1
    Xdat=get(lines,'xdata');
    Ydat=get(lines,'ydata');
    T=table(Xdat',Ydat','VariableNames',{'Xdata','Ydata'})
   no=0;
    file=[get(handles.curfile,'string'),'_',num2str(no,'%0.3i')];
    expath=kdata.expdir;
    savefile=fullfile(expath,file);
    savef=[savefile,kdata.exportformat];            % Ineke, use '.txt' for delimited, use '.xls' for excel
    incr=exist(savef,'file');
    while incr==2
        no=no+1;
        file=[get(handles.curfile,'string'),'_',num2str(no,'%0.3i')];
        savefile=fullfile(expath,file);
        savef=[savefile,kdata.exportformat];            % Ineke, use '.txt' for delimited, use '.xls' for excel
        incr=exist(savef,'file');
    end
    writetable(T,savef);
    elseif length(lines)==4
    Xdat=get(lines(4),'xdata'); Ydat=get(lines(4),'ydata');
    Xfit=get(lines(3),'xdata'); Yfit=get(lines(3),'ydata');
    Xfitint=Xdat; Yfitint=interp1(Xfit,Yfit,Xfitint);
    Xpred1=get(lines(2),'xdata'); Ypred1=get(lines(2),'ydata');
    Xpred2=get(lines(1),'xdata'); Ypred2=get(lines(1),'ydata');
    T=table(Xdat',Ydat',Xfitint',Yfitint',Xpred1',Ypred1',Xpred2',Ypred2','VariableNames',{...
        'Xdata','Ydata','Xfit','Yfit','Xpredict1','Ypredict1','Xpredict2','Ypredict2'});
    no=0;
    file=[get(handles.curfile,'string'),'_',num2str(no,'%0.3i')];
    expath=kdata.expdir;
    savefile=fullfile(expath,file);
    savef=[savefile,kdata.exportformat];            % Ineke, use '.txt' for delimited, use '.xls' for excel
    incr=exist(savef,'file');
    while incr==2
        no=no+1;
        file=[get(handles.curfile,'string'),'_',num2str(no,'%0.3i')];
        savefile=fullfile(expath,file);
        savef=[savefile,kdata.exportformat];            % Ineke, use '.txt' for delimited, use '.xls' for excel
        incr=exist(savef,'file');
    end
    writetable(T,savef);
    % Now write raw fit as well (not interpolated)
    T=table(Xfit',Yfit','VariableNames',{'Xfit','Yfit'});
    savefile=fullfile(expath,[file,'_N1000fit']);
    savef=[savefile,kdata.exportformat];            % Ineke, use '.txt' for delimited, use '.xls' for excel
    writetable(T,savef);
end

function htracks=plottracks(trajectories)
% local function used to plot tracks on main panel
global kdata
if isfield(kdata,'htracks'), if ishandle(kdata.htracks)
        delete(kdata.htracks);
        delete(kdata.hmiss);
        delete(kdata.htracklabels);
end, end
htracks=zeros(length(trajectories),1);
hmiss=[];
C=[];       % 'contour matrix' for labeling with clabel
axes(kdata.handles.imaxes);  hold on;
for i=1:length(trajectories)
    iexist=trajectories(i).x==1;
    imiss=~iexist;
    x=(trajectories(i).i(iexist)*kdata.locmaxsum(2)+kdata.localMaximaOrig(2)-kdata.roi(2))./kdata.sum(2);
    y=(trajectories(i).y(iexist)*kdata.locmaxsum(1)+kdata.localMaximaOrig(1)-kdata.roi(1))./kdata.sum(1);
    htracks(i)=plot(x,y,'y-','linewidth',1.5,'markersize',5,'userdata',i);
    set(htracks(i),'buttondownfcn',@(hObject,eventdata)KymoTracker1...
           ('edittrack_ButtonDownFcn',hObject,eventdata,guidata(hObject),'hit a track!'));
    if length(x)==1
        set(htracks(i),'marker','x');
        C=[C,[i;2],[x,x;y,y]];
    else
        C=[C,[i;length(x)],[x;y]];      % Append contourmatrix
    end
    
    for j=find(imiss)
        jst=j;
        jend=j;
       while imiss(jst),jst=jst-1; end
       while imiss(jend),jend=jend+1; end
%        ixmiss=(mean(trajectories(i).i([j-1,j+1]))+kdata.localMaximaOrig(2)-kdata.roi(2))./kdata.sum(2);
%        ymiss=(mean(trajectories(i).y([j-1,j+1]))+kdata.localMaximaOrig(1)-kdata.roi(1))./kdata.sum(1);
       ixmiss=(interp1([jst,jend],trajectories(i).i([jst,jend]),j)*kdata.locmaxsum(2)+kdata.localMaximaOrig(2)-kdata.roi(2))./kdata.sum(2);
       ymiss=(interp1([jst,jend],trajectories(i).y([jst,jend]),j)*kdata.locmaxsum(1)+kdata.localMaximaOrig(1)-kdata.roi(1))./kdata.sum(1);
       hmissj=plot(ixmiss,ymiss,'rx','markersize',5,'userdata',[i,j]);
       set(hmissj,'buttondownfcn',@(hObject,eventdata)KymoTracker1...
           ('edittrack_ButtonDownFcn',hObject,eventdata,guidata(hObject),'hit a red cross!'));
       hmiss=[hmiss,hmissj];
       
    end
end
kdata.htracks=htracks;
kdata.hmiss=hmiss;
v=1:length(trajectories);
if ~isempty(v),h=clabel(C,v,'color','g'); else h=[]; end
for i=(1:length(v))*2
    set(h(i-1),'Marker','none');
    set(h(i),'ButtonDownFcn',@(hObject,eventdata)KymoTracker1...
           ('edittrack_ButtonDownFcn',hObject,eventdata,guidata(hObject),...
           'hit a track label!'));
       set(h(i),'UserData',str2num(get(h(i),'String')));
end
kdata.htracklabels=h;
showtracksbutton_Callback;
showtracklabelbutton_Callback;
axes(kdata.handles.imaxes); hold off;

function edittrack_ButtonDownFcn(hObject, eventdata, handles,whatup)
global kdata
% Get currentpoint
point1 = get(handles.imaxes,'CurrentPoint'); % button down detected
point1 = (point1(1,1:2));                    % extract x and y
% Set load text
% Function to edit tracks
disp(whatup)          % diplay event
% Collect data for furhter event processing
event.userdata=get(hObject,'UserData');
event.type=whatup;
switch get(gcf,'selectiontype')
    case 'normal'
        event.button='left click';
    case 'alt'
        event.button='right click';
    otherwise
        event.button='wtf?'
        return
end
% switch eventdata.Button
%     case 1
%         event.button='left click';
%     case 3
%         event.button='right click';
%     otherwise
%         event.button='wtf?';
% end
if kdata.edittracks==0,return, end
% Set load text
set(handles.loadtxt,'string','tracking tracks','backgroundcolor',[1,0.5,0]);
drawnow;
% tracks=kdata.tracksFinalFiltered;
% undo.tracksFinalFiltered=tracks;
% kdata.undolastedit=undo;
tracks=undoredoshift('edit');
itr=event.userdata(1);
minsize=str2num(get(handles.minsegmentedit,'string'));
switch event.button
    case 'left click'       % Split tracks
        switch whatup
            case 'hit a red cross!'
                disp('will edit')
                ix=event.userdata(2);
                curtr=tracks(itr);
                imax=length(curtr.tracksFeatIndxCG);
                i1end=ix;       % find end of first half (cannot be gapx)
                while (curtr.tracksFeatIndxCG(i1end)==0)&(i1end>0),i1end=i1end-1; end
                i2st=ix;        % find start of second half (cannot be gapx)
                while (curtr.tracksFeatIndxCG(i2st)==0)&(i2st<imax),i2st=i2st+1; end
                % Prepare first half
                tr1.tracksFeatIndxCG=curtr.tracksFeatIndxCG(1:i1end);
                tr1.tracksCoordAmpCG=curtr.tracksCoordAmpCG(1:i1end*12);
                tr1.seqOfEvents=[curtr.seqOfEvents(1,:);...
                    curtr.seqOfEvents(1,1)+i1end-1 curtr.seqOfEvents(2,2:end)];
                % Prepare second half
                tr2.tracksFeatIndxCG=curtr.tracksFeatIndxCG(i2st:end);
                tr2.tracksCoordAmpCG=curtr.tracksCoordAmpCG((((i2st-1)*12)+1):end);
                tr2.seqOfEvents=[curtr.seqOfEvents(1,1)+i2st-1 curtr.seqOfEvents(1,2:end);...
                    curtr.seqOfEvents(2,:)];
                tracks(itr,1)=tr1;
                tracks(end+1)=tr2;
                % Process and plot
                kdata.tracksFinalFiltered=tracks;
                [trajectories]=getTrajIntAmpPsfBgr_kymotracker(tracks,[],[]);% transforms data structure in a more digestible form
                % Plot tracks
                kdata.trajectories=trajectories;
                plottracks(trajectories);
                set(handles.loadtxt,'string','Done','backgroundcolor','g');
            case 'hit a track label!'
                disp('will edit')
                tracks(itr)=[];
                % Process and plot
                kdata.tracksFinalFiltered=tracks;
                [trajectories]=getTrajIntAmpPsfBgr_kymotracker(tracks,[],[]);% transforms data structure in a more digestible form
                % Plot tracks
                kdata.trajectories=trajectories;
                plottracks(trajectories);
                set(handles.loadtxt,'string','Done','backgroundcolor','g');
            case 'hit a track!'
                disp('will edit')
                ix=point1(1);
                curtr=tracks(itr);
                traject=getTrajIntAmpPsfBgr_kymotracker(curtr,[],[]);
                if length(traject.i)==1     % delete singular point
                    tracks(itr)=[];
                else                        % split longer track
                    iexist=traject.x==1;
                    icurtr=double(iexist);
                    iiexist=(traject.i(iexist)*kdata.locmaxsum(2)+...
                        kdata.localMaximaOrig(2)-kdata.roi(2))./kdata.sum(2);
                    icurtr(iexist)=iiexist;
                    imax=length(curtr.tracksFeatIndxCG);
                    % find end of first half (cannot be gapx)
                    nearestlow=max(find(icurtr(iexist)<ix));
                    if isempty(nearestlow)
                        tr1=[];
                    else
                        i1end=find(icurtr==iiexist(nearestlow));
                        while (curtr.tracksFeatIndxCG(floor(i1end))==0)&(i1end>0),i1end=i1end-1; end
                        % Prepare first half
                        tr1.tracksFeatIndxCG=curtr.tracksFeatIndxCG(1:i1end);
                        tr1.tracksCoordAmpCG=curtr.tracksCoordAmpCG(1:i1end*12);
                        tr1.seqOfEvents=[curtr.seqOfEvents(1,:);...
                            curtr.seqOfEvents(1,1)+i1end-1 curtr.seqOfEvents(2,2:end)];
                    end
                    nearesthi=min(find(icurtr(iexist)>ix));
                    if isempty(nearesthi)
                        tr2=[];
                    else
                        i2st=find(icurtr==iiexist(nearesthi));
                        % find start of second half (cannot be gapx)
                        while (curtr.tracksFeatIndxCG(i2st)==0)&(i2st<imax),i2st=i2st+1; end
                        % Prepare second half
                        tr2.tracksFeatIndxCG=curtr.tracksFeatIndxCG(i2st:end);
                        tr2.tracksCoordAmpCG=curtr.tracksCoordAmpCG((((i2st-1)*12)+1):end);
                        tr2.seqOfEvents=[curtr.seqOfEvents(1,1)+i2st-1 curtr.seqOfEvents(1,2:end);...
                            curtr.seqOfEvents(2,:)];
                    end
                    tracks(itr,1)=tr1;
                    if ~isempty(tr2), tracks(end+1,1)=tr2; end
                end
                % Process and plot
                kdata.tracksFinalFiltered=tracks;
                [trajectories]=getTrajIntAmpPsfBgr_kymotracker(tracks,[],[]);% transforms data structure in a more digestible form
                % Plot tracks
                kdata.trajectories=trajectories;
                plottracks(trajectories);
        end
    case 'right click'  % join tracks
        %hObject
        hObject=handle(kdata.htracks(itr));
        if get(hObject,'Color')==[0,1,0]       % was green, clear it
            set(hObject,'Color',[1,1,0]);
            kdata.tracktojoin=[];
        elseif get(hObject,'Color')==[1,1,0]   % was yellow, make it green
            if ishandle(kdata.tracktojoin)  % join join join
                tr1=tracks(itr);
                tr2=tracks(get(kdata.tracktojoin,'userdata'));
                traj=getTrajIntAmpPsfBgr_kymotracker([tr1;tr2],[],[]);
                if (traj(1).i([1,end])<traj(2).i(1))
                    ngap=traj(2).i(1)-traj(1).i(end)-1; %gap between tracks
                    tr1.tracksFeatIndxCG=[tr1.tracksFeatIndxCG,zeros(1,ngap),tr2.tracksFeatIndxCG];
                    tr1.tracksCoordAmpCG=[tr1.tracksCoordAmpCG,NaN*zeros(1,12*ngap),tr2.tracksCoordAmpCG];
                    tr1.seqOfEvents=[tr1.seqOfEvents(1,:);tr2.seqOfEvents(2,:)];
                    tracks(itr,1)=tr1;
                    tracks(get(kdata.tracktojoin,'userdata'))=[];
                    plotflag=1;
                elseif (traj(2).i([1,end])<traj(1).i(1))
                    ngap=traj(1).i(1)-traj(2).i(end)-1;
                    tr2.tracksFeatIndxCG=[tr2.tracksFeatIndxCG,zeros(1,ngap),tr1.tracksFeatIndxCG];
                    tr2.tracksCoordAmpCG=[tr2.tracksCoordAmpCG,NaN*zeros(1,12*ngap),tr1.tracksCoordAmpCG];
                    tr2.seqOfEvents=[tr2.seqOfEvents(1,:);tr1.seqOfEvents(2,:)];
                    tracks(get(kdata.tracktojoin,'userdata'))=tr2;
                    tracks(itr)=[];
                    plotflag=1;
                else    % They overlap, abort
                    set(hObject,'Color',[1,1,0]);
                    set(kdata.tracktojoin,'Color',[1,1,0]);
                    kdata.tracktojoin=[];
                    plotflag=0;
                end
                if plotflag
                    kdata.tracksFinalFiltered=tracks;
                    [trajectories]=getTrajIntAmpPsfBgr_kymotracker(tracks,[],[]);% transforms data structure in a more digestible form
                    % Plot tracks
                    kdata.trajectories=trajectories;
                    plottracks(trajectories);
                end
            else                        % green green green
                set(hObject,'Color',[0,1,0]);
                kdata.tracktojoin=hObject;
            end
        end
end              
set(handles.loadtxt,'string','Done','backgroundcolor','g');
% Add track display to analysis options
tri=[];
for i=1:length(kdata.trajectories)
    tri=[tri,{num2str(i)}];
end
set(handles.trackindexmenu,'string',tri,'value',i,'visible','on');


% --- Executes on button press in fitgapsbutton.
function fitgapsbutton_Callback(hObject, eventdata, handles)
% hObject    handle to fitgapsbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global kdata
if ~isfield(kdata,'trajectories')
return
end
tr=undoredoshift('edit');
traj=kdata.trajectories;
for i=1:length(tr)
    imiss=(tr(i).tracksFeatIndxCG==0);
    for j=find(imiss);
        jst=j;
        jend=j;
        while imiss(jst),jst=jst-1; end
        while imiss(jend),jend=jend+1; end
        jst
        ixmiss=(interp1([jst,jend],traj(i).i([jst,jend]),j)*kdata.locmaxsum(2)+kdata.localMaximaOrig(2)-kdata.roi(2))./kdata.sum(2);
        ymiss=(interp1([jst,jend],traj(i).y([jst,jend]),j)*kdata.locmaxsum(1)+kdata.localMaximaOrig(1)-kdata.roi(1))./kdata.sum(1);
        createtrackpoint([ixmiss,ymiss],[i,j]);
        imiss(j)=0;
        traj=kdata.trajectories;
        if get(handles.showgapfitbutton,'value')
            plottracks(traj);
            drawnow;
        end
    end
end
plottracks(kdata.trajectories);

function [kymo,bgParam]=inittracking
% Subfunction for init kymo and bgParam etc. for find maxima
global kdata
kymo=kdata.trroiim;%kdata.roiim(:,:,find(kdata.chdisp));
% Normalize tracking roi and get background parameters
kymonorm=max(kymo(:));
kdata.kymonorm=kymonorm;
kymo=kymo/kymonorm;
kdata.kymo=kymo;
bgMean=mean(kdata.bg(:))/kymonorm;
bgStd=std(kdata.bg(:))/kymonorm;
bgParam.bgMean=bgMean;
bgParam.bgStd=bgStd;
kdata.bgParam=bgParam;
kdata.localMaximaOrig=kdata.trackingroi(1:2);
kdata.locmaxsum=kdata.sum;
% Now repeat for all channels:
[p1,p2,roi]=pos2p1p2(kdata.bgpos);
Ibg=kdata.im(p1(1):p2(1)-1,p1(2):p2(2)-1,:);
IbgR=Ibg(:,:,1);
IbgG=Ibg(:,:,2);
IbgB=Ibg(:,:,3);
bgMeanAbs3=[mean(IbgR(:)),mean(IbgG(:)),mean(IbgB(:))];
bgStdAbs3=[std(IbgR(:)),std(IbgG(:)),std(IbgB(:))];
bgParam3.bgMeanAbs3=bgMeanAbs3;
bgParam3.bgStdAbs3=bgStdAbs3;
kdata.bgParam3=bgParam3;

function createtrackpoint(point,ijtrack)
global kdata
point
p1=((point([2,1])).*kdata.sum+kdata.roi(1:2));
if ~isfield(kdata,'localMaximaOrig') % first trackpoint is manual
    inittracking;
    set(kdata.handles.showtracksbutton,'value',1);      % tracks on
    set(kdata.handles.showtracklabelbutton,'value',1);      % tracks on
end
p1n=(p1-kdata.localMaximaOrig)./kdata.locmaxsum;
i=round(p1n(2));
x=p1n(1);
alpha.L=.99;%str2num(get(handles.alphalocmaxedit,'string'));
alpha.R=.99;%str2num(get(handles.alphaRedit,'string'));
alpha.A=.99;%str2num(get(handles.alphaAedit,'string'));
alpha.D=.99;%str2num(get(handles.alphaDedit,'string'));
alpha.F=0;%str2num(get(handles.alphaFedit,'string'));
pixsize=kdata.pixdim(1);
exclambda=str2num(get(kdata.handles.excedit,'string'));
kymo=kdata.kymo;
srcrad=5;    % search radius
kymo=kymo(max([1,round(x)-srcrad]):min([size(kymo,1),round(x)+srcrad]),i);
%kymo=kymo(max([1,round(x)-3]):min([size(kymo,1),round(x)+3]),i);
% Find local maxima
[ mi,exceptions,localMaxima,background,psfSigma ] = ...
    detectGeneralDNA_kymotracker( kymo,kdata.bgParam,pixsize,exclambda,alpha )
%tr.tracksCoordAmpCG=[1,x,intens,amp,dy,dx,dintens,damp,psf,dpsf,kdata.bgMean,kdata.bgStd]
bgMean=kdata.bgParam.bgMean;
bgStd=kdata.bgParam.bgStd;
% Create new tracks structure
tr.tracksFeatIndxCG=2;
if length(mi.intens)==1
    X=mi.yCoord(1)+max([round(x)-1-srcrad,0]);
    tr.tracksCoordAmpCG=[1,X,mi.intens,mi.amp(1),...
        mi.xCoord(2),mi.yCoord(2),0,mi.amp(2),...
        mi.psf(1),mi.psf(2),bgMean,bgStd];
elseif length(mi.intens)>1  % more than one max found
    X=mi.yCoord(:,1);
    Xr=X-(1+srcrad-min([round(x)-1-srcrad,0]));
    ix=find(abs(Xr)==min(abs(Xr)));
    X=mi.yCoord(ix,1)+max([round(x)-4,0]);
    tr.tracksCoordAmpCG=[1,X,mi.intens(ix),mi.amp(ix,1),...
        mi.xCoord(ix,2),mi.yCoord(ix,2),0,mi.amp(ix,2),...
        mi.psf(ix,1),mi.psf(ix,2),bgMean,bgStd];
else
    x;
    tr.tracksCoordAmpCG=[1,x,NaN,NaN,...
        NaN,NaN,0,NaN,...
        NaN,NaN,bgMean,bgStd];
end
tr.seqOfEvents=[i,1,1,NaN;i,2,1,NaN];

if isempty(ijtrack),
    mode='new';
elseif length(ijtrack)==2
    mode='fitgap'
end
tracks=kdata.tracksFinalFiltered;
switch mode
    case 'new'
        tracks=[tracks;tr];
        kdata.tracksFinalFiltered=tracks;
    case 'fitgap'
        'fitgap'
        i=ijtrack(1);
        j=ijtrack(2);
        TR=tracks(i);
        TR.tracksFeatIndxCG(j)=3;
        TR.tracksCoordAmpCG((12*(j-1)+1):(12*(j)))=tr.tracksCoordAmpCG;
        kdata.tracksFinalFiltered(i)=TR;
end
[kdata.trajectories]=getTrajIntAmpPsfBgr_kymotracker(kdata.tracksFinalFiltered,[],[]);% transforms data structure in a more digestible form

% --- Executes on button press in filtertracksbutton.
function filtertracksbutton_Callback(hObject, eventdata, handles)
global kdata
undoredoshift('edit');
minsize=str2num(get(handles.mintrajlengthedit,'string'));
[tracksFinalFiltered]=filterTrajLengthPsfBgr(kdata.tracksFinalFiltered,...
    minsize,[0 900],[0 900],[0],[900],[0 2000]);%filters for trajectories with certain properties
kdata.tracksFinalFiltered=tracksFinalFiltered;
[trajectories]=getTrajIntAmpPsfBgr_kymotracker(tracksFinalFiltered,[],[]);% transforms data structure in a more digestible form
% Plot tracks
kdata.trajectories=trajectories;
plottracks(trajectories);

% --- Executes on button press in edittracksbutton.
function edittracksbutton_Callback(hObject, eventdata, handles)
global kdata
val=get(hObject,'value');
if val  %Select == ON
    kdata.edittracks=1;
else
    kdata.edittracks=0;
end

% --- Executes on button press in undoeditsessionbutton.
function undoeditsessionbutton_Callback(hObject, eventdata, handles)
global kdata
% undo=kdata.undoall;
% tracks=undo.tracksFinalFiltered;
tracks=undoredoshift('undo all');
kdata.tracksFinalFiltered=tracks;
[trajectories]=getTrajIntAmpPsfBgr_kymotracker(tracks,[],[]);% transforms data structure in a more digestible form
% Plot tracks
kdata.trajectories=trajectories;
plottracks(trajectories);

% --- Executes on button press in undolasteditbutton.
function undolasteditbutton_Callback(hObject, eventdata, handles)
global kdata
% undo=kdata.undolastedit;
% redo=kdata.tracksFinalFiltered
% tracks=undo.tracksFinalFiltered;
tracks=undoredoshift('undo');
kdata.tracksFinalFiltered=tracks;
[trajectories]=getTrajIntAmpPsfBgr_kymotracker(tracks,[],[]);% transforms data structure in a more digestible form
% Plot tracks
kdata.trajectories=trajectories;
plottracks(trajectories);

function tracks=undoredoshift(mode)
global kdata
switch mode
    case 'reset'
        kdata.redo={};
        kdata.undo={};
    case 'edit'
        % Reset redo
        kdata.redo={};
        if isfield(kdata,'tracksFinalFiltered')
            % Shift undo memory
            if isfield(kdata,'undo')
                kdata.undo{length(kdata.undo)+1}=kdata.tracksFinalFiltered;
            else
                kdata.undo={kdata.tracksFinalFiltered};
            end
            tracks=kdata.tracksFinalFiltered;
        else
            kdata.tracksFinalFiltered=[];
            tracks=[];
        end
    case 'undo'
        % Shift undo memory
        if length(kdata.undo)>1
            tracks=kdata.undo{end};
            kdata.undo=kdata.undo(1:end-1);
        elseif length(kdata.undo)==1
            tracks=kdata.undo{end};
            kdata.undo={};
        else
            tracks=kdata.tracksFinalFiltered;
            return
        end
        % Shift redo memory
        if isfield(kdata,'redo')
            kdata.redo{length(kdata.redo)+1}=kdata.tracksFinalFiltered;
        else
            kdata.redo={kdata.tracksFinalFiltered};
        end
    case 'undo all'
        % Shift undo memory
        if length(kdata.undo)>=1
            tracks=kdata.undo{1};
            kdata.undo{length(kdata.undo)+1}=kdata.tracksFinalFiltered;
            kdata.redo=fliplr(kdata.undo(2:end));
            kdata.undo={};
        else
            tracks=kdata.tracksFinalFiltered;
            return
        end
    case 'redo'
        % Shift undo memory
        if length(kdata.redo)>1
            tracks=kdata.redo{end};
            kdata.redo=kdata.redo(1:end-1);
        elseif length(kdata.redo)==1
            tracks=kdata.redo{end};
            kdata.redo={};
        else
            tracks=kdata.tracksFinalFiltered;
            return
        end
        % Shift undo memory
        kdata.undo{length(kdata.undo)+1}=kdata.tracksFinalFiltered;
end
        
        
        
        

% --- Executes on button press in redobutton.
function redobutton_Callback(hObject, eventdata, handles)
% hObject    handle to redobutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global kdata
% undo=kdata.undolastedit;
% redo=kdata.tracksFinalFiltered
% tracks=undo.tracksFinalFiltered;
tracks=undoredoshift('redo');
kdata.tracksFinalFiltered=tracks;
[trajectories]=getTrajIntAmpPsfBgr_kymotracker(tracks,[],[]);% transforms data structure in a more digestible form
% Plot tracks
kdata.trajectories=trajectories;
plottracks(trajectories);

function showtracksbutton_Callback(hObject, eventdata, handles)
% hObject    handle to showmaxbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global kdata
if isfield(kdata,'htracks'), if ishandle(kdata.htracks)
        if get(kdata.handles.showtracksbutton,'value')
            set(kdata.htracks,'visible','on');
            set(kdata.hmiss,'visible','on');
        else
            set(kdata.htracks,'visible','off');
            set(kdata.hmiss,'visible','off');
        end
end, end

% --- Executes on button press in showtracklabelbutton.
function showtracklabelbutton_Callback(hObject, eventdata, handles)
global kdata
if isfield(kdata,'htracklabels'), if ishandle(kdata.htracklabels)
        if get(kdata.handles.showtracklabelbutton,'value')
            set(kdata.htracklabels,'visible','on');
        else
            set(kdata.htracklabels,'visible','off');
        end
end, end

function alphalocmaxedit_Callback(hObject, eventdata, handles)
function alphalocmaxedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function alphaRedit_Callback(hObject, eventdata, handles)
function alphaRedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function alphaAedit_Callback(hObject, eventdata, handles)
function alphaAedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function alphaDedit_Callback(hObject, eventdata, handles)
function alphaDedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function alphaFedit_Callback(hObject, eventdata, handles)
function alphaFedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function pixsizeedit_Callback(hObject, eventdata, handles)
function pixsizeedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function excedit_Callback(hObject, eventdata, handles)
function excedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function mintrajlengthedit_Callback(hObject, eventdata, handles)
function mintrajlengthedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function maxgaplengthedit_Callback(hObject, eventdata, handles)
function maxgaplengthedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function brownstdmultedit_Callback(hObject, eventdata, handles)
function brownstdmultedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function minsegmentedit_Callback(hObject, eventdata, handles)
function minsegmentedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function gappenaltyedit_Callback(hObject, eventdata, handles)
function gappenaltyedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function minsearchradedit_Callback(hObject, eventdata, handles)
function minsearchradedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function minamplratioedit_Callback(hObject, eventdata, handles)
function minamplratioedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function lengthforclassifyedit_Callback(hObject, eventdata, handles)
function lengthforclassifyedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function maxangleedit_Callback(hObject, eventdata, handles)
function maxangleedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function resolutionlimitedit_Callback(hObject, eventdata, handles)
function resolutionlimitedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function mergesplitbutton_Callback(hObject, eventdata, handles)
function uselocaldensitybutton_Callback(hObject, eventdata, handles)
function maxsearchradedit_Callback(hObject, eventdata, handles)
function maxsearchradedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function maxamplratioedit_Callback(hObject, eventdata, handles)
function maxamplratioedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in saveimagemenu.
function saveimagemenu_Callback(hObject, eventdata, handles)
% hObject    handle to saveimagemenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns saveimagemenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from saveimagemenu


% --- Executes during object creation, after setting all properties.
function saveimagemenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to saveimagemenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in topbeadbutton.
function topbeadbutton_Callback(hObject, eventdata, handles)
% hObject    handle to topbeadbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global kdata
if isfield(kdata,'xgauss'), if isnumeric(kdata.xgauss);
        set(kdata.handles.topbeadedit,'string',num2str(kdata.xgauss));
        kdata.xtopbead=kdata.xgauss;
end, end

% --- Executes on button press in bottombeadbutton.
function bottombeadbutton_Callback(hObject, eventdata, handles)
% hObject    handle to bottombeadbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global kdata
if isfield(kdata,'xgauss'), if isnumeric(kdata.xgauss);
        set(kdata.handles.bottombeadedit,'string',num2str(kdata.xgauss));
        kdata.xbottombead=kdata.xgauss;
end, end


function topbeadedit_Callback(hObject, eventdata, handles)
% hObject    handle to topbeadedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of topbeadedit as text
%        str2double(get(hObject,'String')) returns contents of topbeadedit as a double


% --- Executes during object creation, after setting all properties.
function topbeadedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to topbeadedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bottombeadedit_Callback(hObject, eventdata, handles)
% hObject    handle to bottombeadedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bottombeadedit as text
%        str2double(get(hObject,'String')) returns contents of bottombeadedit as a double


% --- Executes during object creation, after setting all properties.
function bottombeadedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bottombeadedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function exportformatxls_menuitem_Callback(hObject, eventdata, handles)
% hObject    handle to showlinetimesmenuitem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
'xls'
global kdata
kdata.exportformat='.xls';
set(handles.exportformatxls,'checked','on');
set(handles.exportformattxt,'checked','off');

% --------------------------------------------------------------------
function exportformattxt_menuitem_Callback(hObject, eventdata, handles)
% hObject    handle to showlinetimesmenuitem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
'txt'
global kdata
kdata.exportformat='.txt';
set(handles.exportformattxt,'checked','on');
set(handles.exportformatxls,'checked','off');


% --- Executes on button press in showgapfitbutton.
function showgapfitbutton_Callback(hObject, eventdata, handles)
% hObject    handle to showgapfitbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of showgapfitbutton
