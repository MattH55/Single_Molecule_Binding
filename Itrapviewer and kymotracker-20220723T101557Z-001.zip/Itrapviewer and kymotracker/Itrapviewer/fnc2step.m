function I = fnc2step(x,mean1,mean2,mean3,step1,step2,dx)
% step function for fitting bleaching steps
I = zeros(size(x));
I(x<(step1-dx/2))=mean1;
I((x>(step1+dx/2))&(x<(step2-dx/2)))=mean2;
I(x>(step2+dx/2))=mean3;
i=(x>=(step1-dx/2))&(x<=(step1+dx/2));
if any(i)
    I(i)=interp1([step1-dx/2,step1+dx/2],[mean1,mean2],x(i));
end
i=(x>=(step2-dx/2))&(x<=(step2+dx/2));
if any(i)
    I(i)=interp1([step2-dx/2,step2+dx/2],[mean2,mean3],x(i));
end
end
