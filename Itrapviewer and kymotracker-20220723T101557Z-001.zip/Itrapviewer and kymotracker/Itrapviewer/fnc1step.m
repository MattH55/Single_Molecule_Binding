function I = fnc1step(x,mean1,mean2,step,dx)
% step function for fitting bleaching steps
I = zeros(size(x));
I(x<(step-dx/2))=mean1;
I(x>(step+dx/2))=mean2;
i=(x>=(step-dx/2))&(x<=(step+dx/2));
if any(i)
    I(i)=interp1([step-dx/2,step+dx/2],[mean1,mean2],x(i));
end
end
