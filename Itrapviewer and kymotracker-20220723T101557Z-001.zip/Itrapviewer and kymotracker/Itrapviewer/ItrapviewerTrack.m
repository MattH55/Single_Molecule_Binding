function varargout = ItrapviewerTrack(varargin)

% ITRAPVIEWERTRACK MATLAB code for ItrapviewerTrack.fig
%      ITRAPVIEWERTRACK, by itself, creates a new ITRAPVIEWERTRACK or raises the existing
%      singleton*.
%
%      H = ITRAPVIEWERTRACK returns the handle to a new ITRAPVIEWERTRACK or the handle to
%      the existing singleton*.
%
%      ITRAPVIEWERTRACK('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ITRAPVIEWERTRACK.M with the given input arguments.
%
%      ITRAPVIEWERTRACK('Property','Value',...) creates a new ITRAPVIEWERTRACK or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ItrapviewerTrack_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ItrapviewerTrack_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ItrapviewerTrack

% Last Modified by GUIDE v2.5 18-Nov-2014 17:26:56

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ItrapviewerTrack_OpeningFcn, ...
                   'gui_OutputFcn',  @ItrapviewerTrack_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before ItrapviewerTrack is made visible.
function ItrapviewerTrack_OpeningFcn(hObject, eventdata, handles, varargin)
global data
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ItrapviewerTrack (see VARARGIN)

% Choose default command line output for ItrapviewerTrack
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% This sets up the initial plot - only do when we are invisible
% so window can get raised using ItrapviewerTrack.
if strcmp(get(hObject,'Visible'),'off')
    %plot(rand(5));
    data.action='zoom';
    data.analysis='None';
    data.area0=0;
    data.curp=[1,1];
    data.basedir=cd;
    data.chdisp=[1,1,1];
    data.cst=[1,1,1];
    data.sum=[1,1];
    data.med=[1,1];
    data.handles=handles;
    data.exportformat='.txt';
    set(handles.figure1,'name','Ctrapviewer 1.05')
    set(handles.text30,'string','Ctrap Viewer');
    set(handles.trackbutton,'visible','off');
    set(handles.exportkymobutton,'visible','off');

    % If the program does not work because it complains that it cannot open
    % TDMS files, you can use Onno's functions that come with his FDFIT
    % package. To do this, replace the path in the first line below this text 
    % by the path on your computer that contains Onno's FDFIT package 
    % (should contain a file called init.m), then uncomment the two lines 
    % below (i.e. remove the '%'-sign at the beginning of the lines), and 
    % run the program again. If it worked once, you can comment the lines again.
%     cd 'C:\Iddo\Matlab\FDFIT';
%     init;
    
    itxt=regexpi(cd,'/itrapviewer');
    if (itxt>1)
        dr=cd;
        dr=dr(1:itxt(end-1)-1);
        if isdir(dr)
            addpath(genpath(dr))
        end
    end
       
    cd(data.basedir);
    data.hchdisp=[handles.chdisp1,handles.chdisp2,handles.chdisp3];
    data.hcst=[handles.cst1,handles.cst2,handles.cst3];
    data.hautocst=[handles.autocst1,handles.autocst2,handles.autocst3];
    try
        dat=load('itrapviewer_config.mat','newdir');
        data.curdir=dat.newdir;
        dirbutton_Callback([],2,handles)
    catch
        data.curdir=data.basedir;
    end
end

% --- Outputs from this function are returned to the command line.
function varargout = ItrapviewerTrack_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% Menu functions, unused-------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file = uigetfile('*.fig');
if ~isequal(file, 0)
    open(file);
end

function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.figure1)

function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figure1,'Name') '?'],...
                     ['Close ' get(handles.figure1,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end
delete(handles.figure1)


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
global data
set(handles.loadtxt,'string','Loading...','backgroundcolor',[1,0.5,0]);
drawnow;
contents = cellstr(get(handles.listbox1,'String'));
if isempty(contents)
    set(handles.loadtxt,'string','No files found','backgroundcolor',[1,0.5,0]);
    return
end
newfile=contents{get(handles.listbox1,'Value')};
[path,name,ext]=fileparts(newfile);
switch ext
    case '.txt' % possibly an Ftrap file
        set(handles.loadtxt,'string','txt file error','backgroundcolor','r');
        % test for array data and find number of columns
        fid=fopen(fullfile(data.curdir,newfile));%[path,name,ext]);
        line=fgetl(fid);
        fclose(fid);
        if isempty(line)
            return
        else
            l=sscanf(line,'%f')
            ncol=length(l);
            if ncol==0
                return
            end
        end
        % ok found columns, read this shit
        fid=fopen(fullfile(data.curdir,newfile));%[path,name,ext]);
        D=fscanf(fid,'%f',[ncol,Inf]);
        fclose(fid);
        if isempty(D)
            return
        end
        set(handles.loadtxt,'string','txt file ok','backgroundcolor','y');
        set(handles.propnamemenu,'string',[]);
        data.dat=D;
        data.dim=size(D);
        im(:,:,1)=D;
        im(:,:,2)=D;
        im(:,:,3)=D;
        data.im=im;
        data.roiim=data.im;
        data.roi=[1,1,data.dim];        % reset ROI
        data.extension=ext;
        prepimageorkymo
        displayfile(handles);
        set(handles.curfile,'string',name);
        data.curfile=newfile;
        set([handles.dytxt,handles.dyedit,handles.dymenu,...
            handles.dxtxt,handles.dxedit,handles.nmtxt],'visible','on');
        set(handles.loadtxt,'string','Done','backgroundcolor','g');
        
    case {'.tif','.jpg','.png','.bmp'} % possibly an Ftrap image
        set(handles.loadtxt,'string','image file error','backgroundcolor','r');
        % test for array data and find number of columns
        try
            D=double(imread(fullfile(data.curdir,newfile)));%[path,name,ext]);
        catch
            return
        end
        % ok found columns, read this shit
        set(handles.loadtxt,'string','image file ok','backgroundcolor','y');
        set(handles.propnamemenu,'string',[]);
        data.dat=D;
        dim=size(D);
        data.dim=dim(1:2);
        if length(size(D))==2
            im(:,:,1)=D;
            im(:,:,2)=D;
            im(:,:,3)=D;
        elseif length(size(D))==3
            im=D(:,:,1:3);
        end
        data.im=im;
        data.roiim=data.im;
        data.roi=[1,1,data.dim];        % reset ROI
        data.extension=ext;
        
        prepimageorkymo;
        displayfile(handles);
        set(handles.curfile,'string',name);
        data.curfile=newfile;
        set([handles.dytxt,handles.dyedit,handles.dymenu,...
            handles.dxtxt,handles.dxedit,handles.nmtxt],'visible','on');
        set(handles.loadtxt,'string','Done','backgroundcolor','g');
        
    case '.tdms'    % possibly a scanary file
        dat=TDMS_readTDMSFile(fullfile(data.curdir,newfile));
        pNames=dat.propNames{1};
        pValues=dat.propValues{1};
        set(handles.loadtxt,'string','Not a Scanary File','backgroundcolor','r');
        filetype=findproperty(pNames,pValues,'File format version');
        if strncmpi(filetype,'scanary',7)       % If it is a scanary file, we're good
            % switch dt and dx texts off
            set([handles.dytxt,handles.dyedit,handles.dymenu,...
                handles.dxtxt,handles.dxedit,handles.nmtxt],'visible','off');
            % init proplist and descriptives
            for i=1:length(pNames)
                propnamevalues(i)={[pNames{i},': ',num2str(pValues{i})]};
            end
            [descr,idesc]=findproperty(pNames,pValues,'Description');
            set(handles.descriptiontxt,'string',descr);
            set(handles.propnamemenu,'string',propnamevalues);
            % store data and dimensions
            data.dat=dat;
            pixels=findproperty(pNames,pValues,'Pixels per line')
            lines=findproperty(pNames,pValues,'Lines per plane')
            data.dim=double([pixels{1},lines{1}]);
            if rem(length(data.dat.data{3}),data.dim(1))==0 % set dimensions
                data.dim(2)=length(data.dat.data{3})/data.dim(1);
            elseif rem(length(data.dat.data{3}),data.dim(2))==0
                data.dim(1)=data.dim(2);
                data.dim(2)=length(data.dat.data{3})/data.dim(2);
            end
            im(:,:,1)=reshape(data.dat.data{3},data.dim(1),data.dim(2));
            im(:,:,2)=reshape(data.dat.data{4},data.dim(1),data.dim(2));
            im(:,:,3)=reshape(data.dat.data{5},data.dim(1),data.dim(2));
            data.im=im;
            data.roiim=data.im;
            data.roi=[1,1,data.dim];        % reset ROI
            time=reshape(data.dat.data{6},data.dim(1),data.dim(2));
            t=time(1,:); DT=t(2:end)-t(1:end-1);
            linetime=mean(DT);
            totaltime=t(end)-t(1);
            data.time=time;
            set(handles.curfile,'string',name);
            data.curfile=newfile;
            % Get all image properties and display these at random points on screen
            dt=rm0s(findproperty(pNames,pValues,'Scan Command.PI Fast Scan Command.pixel_dwell_time_ms'));
            os=rm0s(findproperty(pNames,pValues,'Scan Command.PI Fast Scan Command.overshoot_time_ms'));
            dtintfr=rm0s(findproperty(pNames,pValues,'Scan Command.PI Fast Scan Command.inter_frame_wait_time_ms'));
            dtline=rm0s(findproperty(pNames,pValues,'Scan Command.PI Fast Scan Command.line_rate_ms'));
            nprec=rm0s(findproperty(pNames,pValues,'Scan Command.PI Fast Scan Command.n_preconditioning_lines'));
            dx=rm0s(findproperty(pNames,pValues,'Scan Command.Scan Command.scanning_axes.0.pix_size_nm'));
            dy=rm0s(findproperty(pNames,pValues,'Scan Command.Scan Command.scanning_axes.1.pix_size_nm'));
            data.pixdim(1)=str2num(dx);
            data.pixunit(1)={'nm'};
            naxes=findproperty(pNames,pValues,'Scan Command.Scan Command.scanning_axes.count');
            switch naxes{1}         % check image type
                case '1'
                    if sum(data.dim==1)==1
                        'found a linescan, sir!'
                        data.imtype='linescan';
                        pixdwell=(findproperty(pNames,pValues,'pixel_dwell_time_ms'))
                        pixdwell=str2num(pixdwell{1});
                        data.pixdim(2)=pixdwell;
                        linetime=data.dim(1)*pixdwell;
                        totaltime=linetime;
                    else
                        'found a kymo, sir!'
                        data.imtype='kymo';
                        data.pixdim(2)=linetime;
                    end
                    dytxt=[];
                    data.pixunit(2)={'ms'};
                case '2'
                    'found an image, sir!'
                    data.imtype='image';
                    dytxt=['dy ',dy,' nm; '];
                    data.pixdim(2)=str2num(dy);
                    data.pixunit(2)={'nm'};
                otherwise
                    'found a weird image, sir!'
                    data.imtype='weird';
                    set(handles.loadtxt,'string','Weird image','backgroundcolor','r');
                    dytxt=['dy ',dy,' nm; '];
                    data.pixdim(2)=str2num(dy);
                    data.pixunit(2)={'nm'};
            end
            txt=['dx ',dx,' nm; ',dytxt,'<line time> ',num2str(linetime),' ms; acquisition time ',...
                num2str(totaltime/1000),' s; pixel dwell time ',dt,...
                ' ms; overshoot time ',os,' ms; set line time ',dtline,...
                ' ms; inter-frame time ',dtintfr,' ms; preconditioning lines ',nprec];
            set(handles.imparamtxt,'string',txt);
            set(handles.loadtxt,'string','Done','backgroundcolor','g');
            displayfile(handles);
        end%,end
end


function prepimageorkymo
global data
handles=data.handles;
dx=get(handles.dxedit,'string');
data.pixdim(1)=str2num(dx);
data.pixunit(1)={'nm'};
dy=get(handles.dyedit,'string')
data.pixdim(2)=str2num(dy);
dyunit=get(handles.dymenu,'string');
data.pixunit(2)=dyunit(get(handles.dymenu,'value'));
switch get(handles.dymenu,'value')
    case 1 % ms, so prepare kymo
        descr=['kymo file (',data.extension,')'];
        time=repmat((1:data.dim(2))-1,data.dim(1),1)*data.pixdim(2);
        t=time(1,:); DT=t(2:end)-t(1:end-1);
        linetime=mean(DT);
        totaltime=t(end)-t(1);
        data.time=time;
        data.imtype='imkymo';
        dytxt=[];
        txt=['dx ',dx,' nm; ',dytxt,'<line time> ',num2str(linetime),' ms; acquisition time ',...
            num2str(totaltime/1000),' s'];
    case 2 % nm, so prepare image
        descr=['image file (',data.extension,')'];
        data.imtype='imimage';
        dytxt=['dy ',dy,' nm; '];
        txt=['dx ',dx,' nm; ',dytxt,' acquisition time ',...
            '?',' s'];
end
set(handles.descriptiontxt,'string',descr);
set(handles.imparamtxt,'string',txt);

function [value,index]=findproperty(propnames,propvalues,name)
% Helps to retrieve property name property value pairs by name only
value={};
index=[];
lst=strfind(propnames,name);
for i=1:length(lst)
    if any(lst{i})
        value=[value,propvalues{i}];
        index=[index,i];
    end
end

function str=rm0s(txt)
% Removes trailing zeros after punctuation and returs string
if length(txt)==0
    txt=[];
elseif length(txt)>1
    txt=txt(1);
else
    txt=txt{:};
    i=strfind(txt,'.');
    if any(i)
        i=i(end);
        i0=txt(i+1:end)=='0';
        inon0=find(txt~='0');
        if i0&i>1                               % Only zeros after punct
            txt=txt(1:i-1);
        elseif any(i0)&inon0(end)<length(txt)   % after punct, last are zero
            txt((inon0(end)+1):end)=[];
        end
        if i(1)==1
            txt=['0',txt];
        end
    end
end
str=txt;


function displayfile(handles)
% General display file called by all functions, handles contrast, roi's and
% filters
global data
set(handles.loadtxt,'string','Post-pocessing','backgroundcolor','y');
drawnow;
im=data.im;
% apply median filter
medx=data.med(1);
medy=data.med(2);
if medx>1           % median filter lines in x
    roiimx=zeros(size(im,1),size(im,2),size(im,3));
    for i=1:size(im,1);
        roiimx(i,:,:)=median(im(max(round(i-(medx-1)/2),1)...
            :min(round(i+(medx-1)/2),size(im,1)),:,:),1);
    end
else
    roiimx=im;
end
if medy>1           % median filter lines in x
    roiimxy=zeros(size(im,1),size(im,2),size(im,3));
    for i=1:size(im,2);
        roiimxy(:,i,:)=median(roiimx(:,max(round(i-(medy-1)/2),1)...
            :min(round(i+(medy-1)/2),size(im,2)),:),2);
    end
else
    roiimxy=roiimx;
end
medim=roiimxy; clear roiimxy roiimx
% Get region of interest
roiim=medim(data.roi(1):data.roi(3),data.roi(2):data.roi(4),:);
% Sum lines/rows if necessary
sumx=data.sum(1);       % Get sumparameters
sumy=data.sum(2);
if sumx>1           % sum lines in x
    roiimx=zeros(floor(size(roiim,1)/sumx),size(roiim,2),size(roiim,3));
    for i=1:floor(size(roiim,1)/sumx);
        roiimx(i,:,:)=sum(roiim(((i-1)*sumx+1):(i*sumx),:,:),1);
    end
else
    roiimx=roiim;
end
if sumy>1               % sum lines in y
    roiimxy=zeros(size(roiimx,1),floor(size(roiim,2)/sumy),size(roiimx,3));
    for i=1:floor(size(roiim,2)/sumy);
        roiimxy(:,i,:)=sum(roiimx(:,((i-1)*sumy+1):(i*sumy),:),2);
    end
else
    roiimxy=roiimx;
end
data.roiim=roiimxy;
data.roidim=size(data.roiim(:,:,1));
% Check auto/manual contrast
for i=1:3
    if get(data.hautocst(i),'value')        % if auto contrast
        roiimi=data.roiim(:,:,i);
        data.cst(i)=max(roiimi(:));
        set(data.hcst(i),'string',num2str(data.cst(i)));
    end
end
% Check if a metric window existed
replace=0;
if isfield(data,'hrect'), if ishandle(data.hrect)
        p1p2=get(data.hrect,'userdata');
        replace=1;
end,end
data.imh=ImShow(handles.imaxes,imcst(data.roiim,data.cst,data.chdisp));
aspct=str2num(get(handles.aspectedit,'string'));
if aspct==0
    sizeax=get(handles.imaxes,'position');
    wax=sizeax(3);
    hax=sizeax(4);
    wim=size(data.roiim,2);
    him=size(data.roiim,1);
    aspct=1/(wax/hax*him/wim);
end
daspect(handles.imaxes,[aspct 1 1]);
%%% linescan hack dd 20160116
switch data.imtype
    case 'linescan'        
        replace=1;
        p1p2=([1,1,data.dim+1])
end
if replace
    LL=(p1p2(1:2)-data.roi(1:2))./data.sum+1;    % index LL
    UR=(p1p2(3:4)-data.roi(1:2))./data.sum+1;    % index LL
%    LL=((llur(1:2)-1).*data.sum+data.roi(1:2));    % index LL
    OS=(UR-LL);                 % index UR
%    OS=(llur([4,3]).*data.sum);                 % index UR
    newpos=[LL([2,1]),OS([2,1])]-[0.5,0.5,0,0];
    data.hrect=rectangle('position',newpos,'edgecolor','m','linestyle',':','hittest','off');
    set(data.hrect,'userdata',p1p2);
    set(data.hrect,'hittest','on');
    set(data.hrect,'Buttondownfcn',@(hObject,eventdata)ItrapviewerTrack...
        ('hitrect',hObject,eventdata,guidata(hObject)));
    mettxt=getmetrics(newpos);
    set(handles.metrictxt,'string',mettxt);
    set(handles.metricspanel,'shadowcolor','m');
end
analyze(handles);
set(handles.loadtxt,'string','Done','backgroundcolor','g');

        

function medianX_Callback(hObject, eventdata, handles)
global data
data.med(1)=get(hObject,'value');
displayfile(handles);

function medianY_Callback(hObject, eventdata, handles)
global data
data.med(2)=get(hObject,'value');
displayfile(handles);

function sumX_Callback(hObject, eventdata, handles)
global data
sumold=data.sum(1);
data.sum(1)=get(hObject,'value');
data.cst=data.cst*data.sum(1)/sumold;
set(handles.cst1,'string',data.cst(1));
set(handles.cst2,'string',data.cst(2));
set(handles.cst3,'string',data.cst(3));
displayfile(handles);

function sumY_Callback(hObject, eventdata, handles)
global data
sumold=data.sum(2);
data.sum(2)=get(hObject,'value');
data.cst=data.cst*data.sum(2)/sumold;
set(handles.cst1,'string',data.cst(1));
set(handles.cst2,'string',data.cst(2));
set(handles.cst3,'string',data.cst(3));
if data.sum(2)<=1
    set(handles.usesumbox,'value',0,'visible','off');
elseif data.sum(2)>1&get(handles.fitmenu,'value')>3
    set(handles.usesumbox,'visible','on');
end
displayfile(handles);

function imh=ImShow(axeshandles,im)
% Private imshow function that facilitates clicking the bloody axes.
axes(axeshandles);
imh=imshow(im);
set(imh,'buttondownfcn',@(hObject,eventdata)ItrapviewerTrack...
 ('imaxes_ButtonDownFcn',hObject,eventdata,guidata(hObject)));
set(gcf,'windowbuttonmotionfcn',@(hObject,eventdata)ItrapviewerTrack...
    ('MouseoverFcn',hObject, eventdata, guidata(hObject)));


    
function imout=imcst(im,cst,chd)
cst(cst==0)=1;
i=[1,2,3];
if sum(chd)==1;
    i=find(chd)*[1,1,1];
end
imout(:,:,1)=im(:,:,i(1))/cst(i(1))*chd(i(1));
imout(:,:,2)=im(:,:,i(2))/cst(i(2))*chd(i(2));
imout(:,:,3)=im(:,:,i(3))/cst(i(3))*chd(i(3));

%% FUNCTIONS FOR CHANGING DIRECTORIES
% --- Executes on button press in dir2button.
function dir2button_Callback(hObject, eventdata, handles)
global data
try
    cd(data.expdir)
end
newdir=uigetdir;
if newdir~=0
    try
        cd(newdir);
        data.expdir=newdir;
        set(handles.dir2txt,'string',newdir);
    end
end
cd(data.basedir);

% --- Executes on button press in dirbutton.
function dirbutton_Callback(hObject, eventdata, handles)
global data
if eventdata==2 % 2 is case given at startup
    newdir=data.curdir;
    data.expdir=newdir;
    set(handles.dir2txt,'string',newdir);
else
    try
        cd(data.curdir)
    end
    newdir=uigetdir;
end
if newdir~=0
    try
        cd(newdir);
        data.curdir=newdir;
        data.expdir=newdir;
        set(handles.dir2txt,'string',newdir);
        set(handles.dirtxt,'string',newdir);
        list=dir(get(handles.filtertxt,'string'));
        set(handles.listbox1,'string',{list.name},'value',1);
        cd(data.basedir);
        save('itrapviewer_config.mat','newdir');
        listbox1_Callback(data.handles.listbox1, [], handles)
    end
end
cd(data.basedir);


%% FUNCTIONS FOR CHANNEL CONTRAST SETTINGS
function cst_Callback(hObject, eventdata, handles)
global data
i=get(hObject,'UserData');
set(data.hautocst(i),'value',0)
autocsttxt(data.hautocst(i))
val=get(hObject,'string');
try 
    val=str2num(val);
    data.cst(i)=val;
    axes(handles.imaxes);
    displayfile(handles)
catch
    set(hObject,'string',num2str(data.cst(i)));
end

% --- Executes on button press in chdisp1.
function chdisp_Callback(hObject, eventdata, handles)
global data
val=get(hObject,'value');
i=get(hObject,'UserData');
data.chdisp(i)=val;
if sum(data.chdisp)==1
    set(handles.trackbutton,'visible','on');
    set(handles.trackbutton,'string','Track!');
%    set(handles.trackbutton,'visible','off');
elseif sum(data.chdisp)==2
    set(handles.trackbutton,'visible','on');
    set(handles.trackbutton,'string','Track2');
%    set(handles.trackbutton,'visible','off');
else
    set(handles.trackbutton,'visible','off');
end
displayfile(handles)

% --- Executes on selection change in autocst1.
function autocst1_Callback(hObject, eventdata, handles)
displayfile(handles)
autocsttxt(hObject)

% --- Executes on selection change
function equalbutton_Callback(hObject, eventdata, handles)
set(handles.aspectedit,'string','1');
displayfile(handles)

% --- Executes on selection change
function aspectedit_Callback(hObject, eventdata, handles)
displayfile(handles)

function autocsttxt(handle)
if get(handle,'value')==1
    txt='Auto';
else
    txt='Manual';
end
set(handle,'string',txt);

%% FUNCTIONS FOR SAVING AND EXPORTING
% --- Executes on button press in exportkymobutton.
function exportkymobutton_Callback(hObject, eventdata, handles)
global data
klfig=figure;               % Line display 
if sum(data.chdisp)>1       % Check for grayscale image
    title('ERROR, PLEASE SELECT ONLY 1 COLOR CHANNEL','color','r'); 
    gca, axis off
    return                      % end function
end
ch=find(data.chdisp);           % color channel to be used

figure(klfig);                  % open figure for ROI selection
imshow(imcst(data.im,data.cst,data.chdisp))
title('Draw TRACKING ROI and double-click to continue.')
h = imrect;
roi = wait(h);
xroi=[max(roi(2),1),min(roi(2)+roi(4),data.dim(1))];
yroi=[max(roi(1),1),min(roi(1)+roi(3),data.dim(2))];
im=data.im(xroi(1):xroi(2),yroi(1):yroi(2),:);

figure(klfig);                  % open figure for background selection
imshow(imcst(data.im,data.cst,data.chdisp));
rectangle('position',roi,'edgecolor','y');
title('Now draw BACKGROUND ROI and double-click to continue.','color','r')
h = imrect;
roi = wait(h);
xroi=[max(roi(2),1),min(roi(2)+roi(4),data.dim(1))];
yroi=[max(roi(1),1),min(roi(1)+roi(3),data.dim(2))];
bg=data.im(xroi(1):xroi(2),yroi(1):yroi(2),:);
figure(klfig); hold off, imshow(imcst(bg,data.cst,data.chdisp));

file=get(handles.curfile,'string');         % Prepare export filename
if length(file)>15, file=file(1:15); end    % Set file to timestamp
if strcmp(data.expdir,data.curdir)          % Create new directory if needed
    expath=[data.expdir,'\',file,' kymo export'];
    mkdir(expath)
else
    expath=data.expdir;
end
type='tif';                                 % image format for saving
file=[file,'_kymoline_'];
savefile=fullfile(expath,file);

cst(ch)=max(data.dat.data{2+ch}(:))   % Get kymo contrast
kymo=imcst(im,cst,data.chdisp);                % Get raw kymo
bg=imcst(bg,cst,data.chdisp); bg=bg(:,:,ch);
bgpath=[expath,'\backgroundImage'];
bgfile=fullfile(bgpath,'backgroundImage.tif');
mkdir(bgpath);
imwrite(bg,bgfile,type);                   % save backgroundimage

% for i=1:size(im,2)
%     line=kymo(:,i,ch);                               % Prepare line-image
%     lineim(:,1)=datasample(bg(:),size(im,1))';
%     lineim(:,2)=mean([datasample(bg(:),size(im,1))';line']);
%     lineim(:,3)=line;
%     lineim(:,4)=mean([datasample(bg(:),size(im,1))';line']);
%     lineim(:,5)=datasample(bg(:),size(im,1))';
%     lineim=line;    %%% delete to get 5-line image
%     figure(klfig), imshow(lineim);                  % Show kymoline
%     title(['line ',num2str(i),'/',num2str(size(im,2))]);
%     drawnow;
%     curfile=[savefile,num2str(i,'%04u'),'.',type];  % filename
%     imwrite(lineim,curfile,type);                   % save
% end
imwrite(kymo(:,:,ch),[savefile,'.',type],type);
close(klfig)


   
function showlinetimesbutton_Callback(hObject, eventdata, handles)
% Extracts time data from raw dataset and exports linetimes
global data
dt=data.time(1,2:end)-data.time(1,1:end-1);
axes(handles.analysisaxes); cla; hold off;
plot(1e-3*data.time(1,data.roi(2):min(data.roi(4),length(dt))),...
    dt(data.roi(2):min(data.roi(4),length(dt))),'o','markersize',2,'markerfacecolor','k');
hold on
plot(1e-3*data.time(1,1:end-1),dt,'color','r'); 
axis tight
set(handles.analysisaxes,'ylim',[0,1.1*max(dt)]);
xlabel('time (s)');
ylabel('line time (ms)');
set(handles.analysisaxes,'userdata',[get(handles.analysisaxes,'xlim'),get(handles.analysisaxes,'ylim')]);
set(handles.analysisaxes,'buttondownfcn',@(hObject,eventdata)ItrapviewerTrack...
 ('analysisaxes_ButtonDownFcn',hObject,eventdata,guidata(hObject)));
set(get(handles.analysisaxes,'children'),'hittest','off');



% --- Executes on button press in savebutton.
function savebutton_Callback(hObject, eventdata, handles)
global data
apptxt=get(handles.appendtext,'string');
file=[get(handles.curfile,'string'),apptxt];
expath=data.expdir;
savefile=fullfile(expath,file);
if get(handles.filetype,'value')==1;
    cd(expath);
    [file,expath]=uiputfile({'*.png';'*.jpg';'*.tif';'*.bmp';'*.gif'},...
        'Save as',file);
    cd(data.basedir);
    if file~=0
        savefile=fullfile(expath,file)
        [PATHSTR,NAME,EXT] = fileparts(file);
        type=EXT(2:end);
    end
else
    type=get(handles.filetype,'string');
    type=type{get(handles.filetype,'value')};
    savefile=[savefile,'.',type(1:3)]
end
switch type
    case 'tif - raw photon counts 16bit'
        imwrite(uint16(data.roiim),savefile,type(1:3));
    otherwise
        imwrite(imcst(data.roiim,data.cst,data.chdisp),savefile,type);
end


% --- Executes on button press in saveallbutton.
function saveallbutton_Callback(hObject, eventdata, handles)
for i=1:length(get(handles.listbox1,'string'));
    set(handles.listbox1,'value',i);
    listbox1_Callback(handles.listbox1,[],handles); drawnow;
    savebutton_Callback([],[],handles);
end



%% UNUSED FUNCTIONS

% --- Executes during object creation, after setting all properties.




function medianY_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function sumX_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function sumY_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function listbox1_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function dir2txt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function filtertxt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function appendtext_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function autocst1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function dirtxt_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function cst1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function cst2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function cst3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function medianX_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function analysismenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function propnamemenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function analysistxt_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function fitmenu_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function dymenu_Callback(hObject, eventdata, handles)
global data
if get(handles.dymenu,'value')==2       % nm chosen
    dx=get(handles.dxedit,'string');
    set(handles.dyedit,'string',dx);
    set(handles.dytxt,'string','dy');
else
    set(handles.dytxt,'string','dt');
end
prepimageorkymo

function filetype_CreateFcn(hObject, eventdata, handles)

function dirtxt_ButtonDownFcn(hObject, eventdata, handles)

% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)

function dirtxt_Callback(hObject, eventdata, handles)

function dir2txt_Callback(hObject, eventdata, handles)

function appendtext_Callback(hObject, eventdata, handles)

function filtertxt_Callback(hObject, eventdata, handles)
global data
cd(data.curdir);
list=dir(get(handles.filtertxt,'string'));
set(handles.listbox1,'string',{list.name},'value',1);
cd(data.basedir);
listbox1_Callback(handles.listbox1, [], handles)


function filetype_Callback(hObject, eventdata, handles)

function propnamemenu_Callback(hObject, eventdata, handles)

function analysistxt_Callback(hObject, eventdata, handles)



function analysisaxes_ButtonDownFcn(hObject, eventdata, handles)
% Activated when clicking image 
% Creates rectangle in data.hrect
global data
point1 = get(handles.analysisaxes,'CurrentPoint'); % button down detected
point1 = round(point1(1,1:2));           % extract x and y 
event.point1=point1;
pos=[point1,1,1];
set(gcf,'units','pixels');
        data.zrect=rectangle('position',pos,'edgecolor','k','linestyle',':');
set(gcf,'windowbuttonupfcn',@(hObject,eventdata)ItrapviewerTrack...
    ('analysisaxes_WindowButtonUpFcn',hObject, event, guidata(hObject)));
set(gcf,'windowbuttonmotionfcn',@(hObject,eventdata)ItrapviewerTrack...
    ('analysisaxes_WindowButtonMotionFcn',hObject, event, guidata(hObject)));


function analysisaxes_WindowButtonMotionFcn(hObject, event, handles)
% For area selection, works with fig1_WindowButtonUpFcn, set by imaxes_ButtonDownFcn
% rect - structure with rectangle object
global data
point2=get(handles.analysisaxes,'currentpoint');
point2=round(point2(1,1:2));
point1=event.point1;
p1 = min(point1,point2);           % calculate locations
offset = abs(point1-point2);       % and dimensions
pos=[p1,offset];
try
    set(data.zrect,'position',pos);
catch
    epsilon=1e-5*(pos==0);
    set(data.zrect,'position',pos+epsilon);
end

function analysisaxes_WindowButtonUpFcn(hObject, event, handles)
% For area selection, works with fig1_WindowButtonMotionFcn, set by imaxes_ButtonDownFcn
% rect - structure with rectangle object
global data
set(gcf,'windowbuttonupfcn',[]);
set(gcf,'windowbuttonmotionfcn',@(hObject,eventdata)ItrapviewerTrack...
    ('MouseoverFcn',hObject, [], guidata(hObject)));
pos=get(data.zrect,'position');
p1=event.point1;
p2=get(gca,'currentpoint'); p2=round(p2(1,1:2));
delete(data.zrect);
if pos(3:4)==[1,1]              % zero area selected
    if data.area0==1 & data.curp==pos(1:2)   % there was a double-click, zoom out
        lims=get(handles.analysisaxes,'userdata')
        set(handles.analysisaxes,'xlim',lims(1:2),'ylim',lims(3:4));
    end
    data.area0=1;               % set single-click flag
    data.curp=pos(1:2);
    return
elseif any(round(pos(3:4))==0)  % zoom in and reset single-click flag
    data.area0=0;
else
    set(handles.analysisaxes,'xlim',[min([p1(1),p2(1)]),max([p1(1),p2(1)])],...
        'ylim',[min([p1(2),p2(2)]),max([p1(2),p2(2)])]);
end


function imaxes_ButtonDownFcn(hObject, eventdata, handles)
% Activated when clicking image 
% Creates rectangle in data.hrect
global data
switch get(gcf,'selectiontype');
    case 'normal'
        data.action='zoom'
    case 'alt'
        data.action='metrics'
end
point1 = get(handles.imaxes,'CurrentPoint'); % button down detected
point1 = round(point1(1,1:2));           % extract x and y 
pos=[point1,1,1];
set(gcf,'units','pixels');
try, if ishandle(data.hrect),   % Store old ROI in temprect during mouse dragging
        data.temprect=rectangle('position',get(data.hrect,'position'),'hittest','off'...
            ,'edgecolor','m','linestyle',':','userdata',get(data.hrect,'userdata'));
        delete(data.hrect);
end, end
switch data.action % Create rectangle for further processing
    case 'zoom'
        data.hrect=rectangle('position',pos-[0.5,0.5,0,0],'edgecolor','y','linestyle',':','hittest','off');
        set(handles.metricspanel,'shadowcolor','y');
    case 'metrics'
        data.hrect=rectangle('position',pos-[0.5,0.5,0,0],'edgecolor','r','linestyle',':','hittest','off');
        set(handles.metricspanel,'shadowcolor','r');
end
event.point1=point1;
event.action=data.action;
        [mettxt,curtxt,p1,p2]=getmetrics(pos);
        set(handles.metrictxt,'string',mettxt);
        set(handles.currenttxt,'string',curtxt);
        set(data.hrect,'userdata',[p1,p2]);
set(gcf,'windowbuttonupfcn',@(hObject,eventdata)ItrapviewerTrack...
    ('fig1_WindowButtonUpFcn',hObject, event, guidata(hObject)));
set(gcf,'windowbuttonmotionfcn',@(hObject,eventdata)ItrapviewerTrack...
    ('fig1_WindowButtonMotionFcn',hObject, event, guidata(hObject)));

function fig1_WindowButtonMotionFcn(hObject, event, handles)
% For area selection, works with fig1_WindowButtonUpFcn, set by imaxes_ButtonDownFcn
% rect - structure with rectangle object
global data
point2=get(handles.imaxes,'currentpoint');
point2=round(point2(1,1:2));
switch event.action
    case {'zoom','metrics','shaperect','moverect'}
        p1 = min(event.point1,point2);           % calculate locations
        offset = abs(event.point1-point2);       % and dimensions
        if strcmpi(event.action,'metrics');     % limit rect to roi
            p2=min(p1+offset,[size(data.roiim,2),size(data.roiim,1)]+1);
            p1=max(p1,[1,1]);
            offset=p2-p1;
        end
        switch event.action
            case {'zoom','metrics'}
                pos=[p1,offset];
            case{'shaperect'}
                POS0=get(data.hrect,'position')+[0.5,0.5,0,0];  % get old position
                POS0=POS0+[0,0,POS0(1:2)];                      % old rectangle in LL, UR format
                POS1=[point2,point2];                           % new rectangle
                POS=POS0;
                POS(event.hit)=POS1(event.hit);
                %pos=[min(POS([1,3])),min(POS([2,4])),...
                %    max(POS([1,3]))-min(POS([1,3])),max(POS([2,4]))-min(POS([2,4]))];
                pos=[POS(1:2),POS(3:4)-POS(1:2)];
           case{'moverect'}
                %pos=get(data.hrect,'position')+[0.5,0.5,0,0];  % get old position
                pos=event.oldpos;
                move=point2-event.point1;
                pos=pos+[move,0,0];
           end
        try
            set(data.hrect,'position',pos-[0.5,0.5,0,0]);
        catch
            epsilon=1e-5*(pos==0);
            try, set(data.hrect,'position',pos+epsilon-[0.5,0.5,0,0]); end
        end
        [mettxt,curtxt,p1,p2]=getmetrics(pos);
        set(handles.metrictxt,'string',mettxt);
        set(handles.currenttxt,'string',curtxt);
        set(data.hrect,'userdata',[p1,p2]);
end

function MouseoverFcn(hObject, event, handles)
% Metrics display without clicking image
global data
p=get(handles.imaxes,'currentpoint');
p=round(p(1,1:2));
if p>=[1,1] & p<=fliplr(data.roidim)
    [mettxt,curtxt]=getmetrics([p,1,1]);
    set(handles.currenttxt,'string',curtxt);
else
    set(handles.currenttxt,'string',['Double-click to zoom out']);
end

function fig1_WindowButtonUpFcn(hObject, event, handles)
% For area selection, works with fig1_WindowButtonMotionFcn, set by imaxes_ButtonDownFcn
% rect - structure with rectangle object
global data
set(gcf,'windowbuttonupfcn',[]);
%set(gcf,'windowbuttonmotionfcn',[]);
set(gcf,'windowbuttonmotionfcn',@(hObject,eventdata)ItrapviewerTrack...
    ('MouseoverFcn',hObject, event, guidata(hObject)));
pos=get(data.hrect,'position')+[0.5,0.5,0,0];
[mettxt,curtxt,p1,p2]=getmetrics(pos);
switch data.action,
    case 'zoom'
        delete(data.hrect);
        try, if ishandle(data.temprect),
            data.hrect=data.temprect;       % return metrics rect to hrect
            %delete(data.temprect);
        end, end
        if pos(3:4)==[1,1]              % zero area selected
            if data.area0==1 & data.curp==pos(1:2)   % there was a double-click, zoom out
                data.roi=[1,1,data.dim];    % reset ROI to full image
                displayfile(handles);
            end
            data.area0=1;               % set single-click flag
            data.curp=pos(1:2);
            return
        elseif any(round(pos(3:4))==0)  % zoom in and reset single-click flag
            data.area0=0;
        else
            data.roi=[p1,p2-1];
            data.area0=0;
            displayfile(handles);
        end
    case {'metrics','shaperect','moverect'}
        try, if ishandle(data.temprect),
            delete(data.temprect);
        end, end
        analyze(handles);
end
if ishandle(data.hrect)
    pos=get(data.hrect,'position')+[0.5,0.5,0,0];
    [mettxt,curtxt,p1,p2]=getmetrics(pos);
    %if ishandle(data.hrect), set(data.hrect,'userdata',[p1,p2]); end
    set(handles.metrictxt,'string',mettxt);
    set(handles.currenttxt,'string',curtxt);
%    set(data.hrect,'hittest','off');
     set(data.hrect,'hittest','on','Buttondownfcn',...
         @(hObject,eventdata)ItrapviewerTrack('hitrect',hObject,eventdata,guidata(hObject)));
end

function hitrect(hObject, event, handles)
global data
switch get(gcf,'selectiontype');
    case 'normal'
       data.action='shaperect'
    case 'alt'
        data.action='moverect'
end
'hit it!'
point1 = get(handles.imaxes,'CurrentPoint'); % button down detected
point1 = (point1(1,1:2))           % extract x and y 
POS=get(data.hrect,'position')+[0.5,0.5,0,0];
pos=POS+[0,0,POS(1:2)]
hit=[0,0,0,0];
wh=[];
d1=max([2.05,data.roidim(2)/30]);
d2=max([2.05,data.roidim(1)/30]);
if abs(point1(1)-pos(1))<d1,hit(1)=1; wh=[wh,'L']; end
if abs(point1(1)-pos(3))<d1,hit(3)=1; hit(1)=0; wh=[wh,'R']; end
if abs(point1(2)-pos(2))<d2,hit(2)=1; wh=[wh,'U']; end
if abs(point1(2)-pos(4))<d2,hit(4)=1; hit(2)=0; wh=[wh,'D']; end
wh,hit
if sum(hit)>=3, return, end
clear event
event.point1=point1;
event.action=data.action;
event.hit=logical(hit);
event.oldpos=POS;
set(gcf,'windowbuttonupfcn',@(hObject,eventdata)ItrapviewerTrack...
    ('fig1_WindowButtonUpFcn',hObject, event, guidata(hObject)));
set(gcf,'windowbuttonmotionfcn',@(hObject,eventdata)ItrapviewerTrack...
    ('fig1_WindowButtonMotionFcn',hObject, event, guidata(hObject)));


function [mettxt,curtxt,p1,p2]=getmetrics(pos)
% This function g ets metrics from a selected rectangle position on the
% image. Output is metric text and LL and UR points in raw data space.
% type specifies metrics output or currentpoint output
global data
p1=round((pos([2,1])-1).*data.sum+data.roi(1:2));    % index LL
p2=round(p1+pos([4,3]).*data.sum);                 % index UR
p1=max(p1,[1,1]);       % limit LL to image dim
p2=min(p2,data.dim+1);    % limit UR to image dim
roi=round([p2(1)-p1(1),p2(2)-p1(2)]);
% Convert ROI range to absolute pixel values
pixLL=['pix: (',num2str(p1(1)),', ',num2str(p1(2)),')'];   % output txt for metrics
pixUR=[' => (',num2str(p2(1)-1),', ',num2str(p2(2)-1),')'];
try
    % Convert absolute pixel to actual SI units
    si1=(p1.*data.pixdim);
    si2=(p2-1).*data.pixdim;
    x1=[num2str(si1(1)),' ',data.pixunit{1}];   % output strings
    x2=[num2str(si2(1)),' ',data.pixunit{1}];
    switch data.imtype                      % lookup time data if needed
        case {'image','imimage','txtimage'}
            y1=[num2str(si1(2)),' ',data.pixunit{2}];
            y2=[num2str(si2(2)),' ',data.pixunit{2}];
        case {'kymo','txtkymo','imkymo'}
            y1=data.time(1,p1(2));
            y1=[num2str(y1),' ',data.pixunit{2}];
            y2=data.time(1,p2(2));
            y2=[num2str(y2),' ',data.pixunit{2}];
        case 'linescan'
            y1=0;
            y2=data.dim(1)*data.pixdim(2);
            y2=[num2str(y2),' ',data.pixunit{2}];
    end
    siLL=['SI:  (',x1,', ',y1,')'];
    siUR=[' => (',x2,', ',y2,')'];
    if roi==[1,1]|roi==[0,0]
        pix={[pixLL]};
        si={[siLL]};
    else
        pix={[pixLL,pixUR]};
        si={[siLL,siUR]};
    end
    % Get ROI size in pixel values and actual units
    roipix={['pix: (',num2str(roi(1)),', ',num2str(roi(2)),')']};  % output txt for metrics
    % Convert absolute pixel to actual units
    roixy=(roi.*data.pixdim);
    roix=[num2str(roixy(1)),' ',data.pixunit{1}];
    switch data.imtype
        case 'linescan'
            dt=y2;
        otherwise
            dt=data.time(1,(p2(2)))-data.time(1,(p1(2)));
    end            
    dt=[num2str(dt),' ms'];
    switch data.imtype                      % lookup time data if needed
        case {'image','imimage','txtimage'}
            roiy=[num2str(roixy(2)),' ',data.pixunit{2}];
        case {'kymo','txtkymo','imkymo'}
            roiy=dt;
        case 'linescan'
            roiy=dt;
    end
    roisi=['SI:  (',roix,', ',roiy,')'];
    % Get area and intensities for RAW DATA
    Npix=prod(roi);
    I=data.im(p1(1):p2(1)-1,p1(2):p2(2)-1,:);
    Ir=sum(sum(I(:,:,1)));
    Ig=sum(sum(I(:,:,2)));
    Ib=sum(sum(I(:,:,3)));
    Atxt={['- RGB intensity in ',num2str(Npix),' pixel area (raw) [filtered]']};
    Isum=['(',num2str(Ir),', ',num2str(Ig),', ',num2str(Ib),')'];
    Imean=['(',num2str(Ir/Npix),', ',num2str(Ig/Npix),', ',num2str(Ib/Npix),')'];
    % Now get area and intensities for FILTERED DATA
    proi1=round((pos([2,1])));    % index LL
    proi2=round(proi1+pos([4,3]));                 % index UR
    proi1=max(proi1,[1,1]);    % limit LL to image dim
    proi2=min(proi2,data.roidim);    % limit UR to image dim
    I=data.roiim(proi1(1):proi2(1)-1,proi1(2):proi2(2)-1,:);
    Ir=sum(sum(I(:,:,1)));
    Ig=sum(sum(I(:,:,2)));
    Ib=sum(sum(I(:,:,3)));
    ISum={['Isum: ',Isum,' [',num2str(Ir),', ',num2str(Ig),', ',num2str(Ib),']']};
    IMean={['I/pix: ',Imean,' [',num2str(Ir/Npix),', ',num2str(Ig/Npix),', ',num2str(Ib/Npix),']']};
    mettxt=[{'- ROI position (raw data)'};pix;si;{[]};{'- ROI size (raw data)'};...
        roipix;roisi;{[]};Atxt;ISum;IMean];
    curtxt=[{'- Current point'};...
        {['RGB intensity: ',Isum,' [',num2str(Ir),', ',num2str(Ig),', ',num2str(Ib),']']};...
        {[pixLL,' ',siLL,' line:',dt]}];
catch
    pix={[pixLL,pixUR]};
    dat={['DATA: [',num2str(data.dim(1)),', ',num2str(data.dim(2)),']']};
    mettxt=[{'- ROI position outside data'};pix;dat];
    curtxt=[];
end

function fitmenu_Callback(hObject, eventdata, handles)
global data
if data.sum(2)>1&get(handles.fitmenu,'value')>3
    set(handles.usesumbox,'visible','on');
else
    set(handles.usesumbox,'visible','off');
end
analyze(handles);

function analysismenu_Callback(hObject, eventdata, handles)
global data
analysis=get(hObject,'string');
data.analysis=analysis{get(hObject,'value')};
analyze(handles);

function checkbarplot_Callback(hObject, eventdata, handles)
if get(handles.checkbarplot,'value')
    set(handles.checklogplot,'value',0,'enable','off');
else
    set(handles.checklogplot,'enable','on');
end
analyze(handles);

function checklogplot_Callback(hObject, eventdata, handles)
analyze(handles);

function usesumbox_Callback(hObject, eventdata, handles)
analyze(handles);


function analyze(handles)
global data
exitflag=0;
set(handles.loadtxt,'string','Analyzing','backgroundcolor','y');
% Get photon distributions to analyze
try
    if ishandle(data.hrect)&sum(data.chdisp)==1         % Get roi coordinates
        roi=get(data.hrect,'userdata')-[0,0,1,1];
        dat=data.im(roi(1):roi(3),roi(2):roi(4),find(data.chdisp));
        
        
        %%% hack iddo 15012016
        fitfunc = get(handles.fitmenu,'string');
        fitfunc = fitfunc{get(handles.fitmenu,'value')};
        if strncmpi(fitfunc,'Gauss',5)|strncmpi(data.analysis,'Sum rows',8)
            set(handles.usesumbox,'value',0)
        end

        if get(handles.usesumbox,'value')
            % sum lines if needed
            roiim=dat;
            sumx=data.sum(1);       % Get sumparameters
            sumy=data.sum(2);
            if sumx>1           % sum lines in x
                roiimx=zeros(floor(size(roiim,1)/sumx),size(roiim,2),size(roiim,3));
                for i=1:floor(size(roiim,1)/sumx);
                    roiimx(i,:,:)=sum(roiim(((i-1)*sumx+1):(i*sumx),:,:),1);
                end
            else
                roiimx=roiim;
            end
            if sumy>1               % sum lines in y
                roiimxy=zeros(size(roiimx,1),floor(size(roiim,2)/sumy),size(roiimx,3));
                for i=1:floor(size(roiim,2)/sumy);
                    roiimxy(:,i,:)=sum(roiimx(:,((i-1)*sumy+1):(i*sumy),:),2);
                end
                ysummed=0*(1:i);
                for i=1:floor(size(roiim,2)/sumy);
                    ysummed(i)=sum(data.time(1,(((i-1)*sumy+1):(i*sumy))),2)/sumy;
                end
            else
                roiimxy=roiimx;
            end
            dat=roiimxy;
            
        end
        
        switch data.analysis
            case 'Sum rows'
                profile=squeeze(sum(dat,2));
                Nsummed=size(dat,2)
                x=(0:(length(profile)-1))*data.pixdim(1);
                xtxt=['Position [',data.pixunit{1},']'];  
                ytxt=['Photon count'];
            case 'Sum columns'
                profile=squeeze(sum(dat,1));
                Nsummed=size(dat,1);
                ytxt=['Photon count'];
                switch data.imtype              % lookup time data if needed
                    case {'image','imimage','txtimage'}
                        x=(0:(length(profile)-1))*data.pixdim(2);
                        xtxt=['Position [',data.pixunit{2},']'];
                    case {'kymo','txtkymo','imkymo'}
                        if get(handles.usesumbox,'value')
                            x=ysummed;
                            Nsummed=Nsummed*sumy;
                        else                          
                        x=data.time(1,(roi(2):roi(4)));
                        end
                        xtxt=['Time [',data.pixunit{2},']'];
                end
            case 'No analysis'
                exitflag=1;
        end
        if length(profile)<=1|isempty(dat)
            exitflag=1;
        end
    else
        exitflag=1;
    end
catch
    exitflag=1;
end
if exitflag         % exit because we will not analyze this crap
    axes(handles.analysisaxes), cla;
    set(handles.analysisaxes,'visible','off');
    set(handles.analysistxt,'visible','off');
    set(handles.checkbarplot,'visible','off');
    set(handles.checklogplot,'visible','off');
    set(handles.usesumbox,'visible','off');
    set(handles.loadtxt,'string','Done','backgroundcolor','g');
    return
end
% Plot photon distribution
axes(handles.analysisaxes), cla;    % switch on axes
set(handles.analysisaxes,'visible','on');
    set(handles.checkbarplot,'visible','on');
    set(handles.checklogplot,'visible','on');
hold off;
if get(handles.checkbarplot,'value')
    hbar=bar(x,profile,'hist');
    set(hbar,'facecolor','r','edgecolor',[0.7,0,0]);
else
    if get(handles.checklogplot,'value')
        hold off
        hscatter=semilogy(x,profile,'o-');
    else
         hscatter=plot(x,profile,'o-');
    end
    set(hscatter,'markersize',2,'markeredgecolor','k','markerfacecolor','k','color','r');
end
data.profile.profile=profile(:);
data.profile.x=x(:);
axis tight, hold on
    xlabel(xtxt);
    ylabel(ytxt);
set(handles.analysisaxes,'ylim',[0,1.1*max(profile)]);
set(handles.analysisaxes,'userdata',[min(x),max(x),0,1.1*max(profile)]);
% Prepare fit functions
fitfunc = get(handles.fitmenu,'string');
fitfunc = fitfunc{get(handles.fitmenu,'value')};
fitflag=1;
switch fitfunc
    case 'No fitting'
        fitflag=0;
    case 'Gauss + offset'
        fitfnc=fittype('Amp*exp(-(x-x0)^2/(2*sd^2))+offset');   % equation object
        amp=max(profile)-min(profile);                  % estimate amplitude
        ctr=mean(x(find(profile==max(profile))));       % estimate center position
        sd=100;                                         % estimate standard deviation
        ofs=min(profile);                               % estimate offset
        startpoint=[amp,ofs,sd,ctr];
        lower=[0,0,0,min(x)];
        upper=[max(profile(:)),max(profile(:)),1000,max(x)];
        probl=[];
   case 'Gauss'
        fitfnc=fittype('Amp*exp(-(x-x0)^2/(2*sd^2))');   % equation object
        amp=max(profile)-min(profile);                  % estimate amplitude
        ctr=mean(x(find(profile==max(profile))));       % estimate center position
        sd=100;                                         % estimate standard deviation
        startpoint=[amp,sd,ctr];
        lower=[0,0,min(x)];
        upper=[max(profile(:)),1000,max(x)];
         probl=[];
   case 'Constant'
        fitfnc=fittype(@(mean, x) mean+0*x);   % equation object
        ofs=mean(profile);                  % estimate offsset
        startpoint=[ofs];
        lower=[0];
        upper=[max(profile(:))];
        probl=[];
    case '1 step'
        n=length(profile);
        fitfnc=fittype('fnc1step(x,mean1,mean2,step,dx)','problem','dx');   % equation object
        mean1=mean(profile(1:ceil(n/4)));                  % estimate offset1
        mean2=mean(profile(floor(n*3/4):end));                  % estimate offset1
        step=mean(x);
        startpoint=[mean1,mean2,step]
        lower=[0,0,min(x)];
        upper=[max(profile(:)),max(profile(:)),max(x)];
        dx=mean(x(2:end)-x(1:end-1));
        probl=3*dx
    case '2 steps'
        n=length(profile);
        fitfnc=fittype('fnc2step(x,mean1,mean2,mean3,step1,step2,dx)','problem','dx');   % equation object
        mean1=mean(profile(1:ceil(n/4)));                  % estimate offset1
        mean2=mean(profile(floor(3*n/8):ceil(5*n/8)));                  % estimate offset1
        mean3=mean(profile(floor(n*3/4):end));                  % estimate offset1
        step1=x(1)+(x(end)-x(1))/3;
        step2=x(end)-(x(end)-x(1))/3;
        startpoint=[mean1,mean2,mean3,step1,step2]
        lower=[0,0,0,min(x),min(x)];
        upper=[max(profile(:)),max(profile(:)),max(profile(:)),max(x),max(x)];
        dx=mean(x(2:end)-x(1:end-1));
        probl=3*dx
case 'exp + offset'
        fitfnc=fittype('I0*exp(-((x-t0)/tau))+Ioffset','problem','t0');   % equation object
        I0=max(profile)-min(profile);                  % estimate amplitude
        tau=max(x)-min(x);       % estimate center position
        ofs=min(profile);                               % estimate offset
        startpoint=[I0,ofs,tau];
        lower=[1,0,0];
        upper=[1e10*max(profile(:)),max(profile(:)),1e10*max(x)];
        probl=x(1);
case 'exp'
        fitfnc=fittype('I0*exp(-((x-t0)/tau))','problem','t0');   % equation object
        I0=max(profile)-min(profile);                  % estimate amplitude
        tau=max(x)-min(x);       % estimate center position
        ofs=min(profile);                               % estimate offset
        startpoint=[I0,tau];
        lower=[1,0];
        upper=[1e10*max(profile(:)),1e10*max(x)];
        probl=x(1);
case '2exp + offset'
        fitfnc=fittype('I1*exp(-((x-t0)/tau1))+I2*exp(-((x-t0)/tau2))+Ioffset','problem','t0');   % equation object
        I1=max(profile)-min(profile);                  % estimate amplitude
        I2=I1/2;                  % estimate amplitude
        tau1=max(x)-min(x);       % estimate center position
        tau2=tau1*2;       % estimate center position
        ofs=min(profile);                               % estimate offset
        startpoint=[I1,I2,ofs,tau1,tau2];
        lower=[1,1,0,0,0];
        upper=[1e10*max(profile(:)),1e10*max(profile(:)),max(profile(:)),1e10*max(x),1e10*max(x)];
        probl=x(1);
case '2exp'
        fitfnc=fittype('I1*exp(-((x-t0)/tau1))+I2*exp(-((x-t0)/tau2))','problem','t0');   % equation object
        I1=max(profile)-min(profile);                  % estimate amplitude
        I2=I1/2;                  % estimate amplitude
        tau1=max(x)-min(x);       % estimate center position
        tau2=tau1*2;       % estimate center position
        startpoint=[I1,I2,tau1,tau2];
        lower=[1,1,0,0];
        upper=[1e10*max(profile(:)),1e10*max(profile(:)),1e10*max(x),1e10*max(x)];
        probl=x(1);
end

if fitflag
    if isempty(probl)       % Fit
        cfit=fit(x(:),profile(:),fitfnc,'startpoint',startpoint,'lower',lower,...
            'upper',upper);  % fit
    else
        cfit=fit(x(:),profile(:),fitfnc,'startpoint',startpoint,'lower',lower,...
            'upper',upper,'problem',probl);  % fit with problem-dependent parameter
    end
    % post process fit
    axes(handles.analysisaxes)
    hfit=plot(cfit,'b');                 % plot and post-processing
    set(hfit,'linewidth',2);
    axes(handles.analysisaxes), plot(x,predint(cfit,x),'c:')
    legend off
    xlabel(xtxt);
    ylabel(ytxt);
    names=coeffnames(cfit);
    vals=coeffvalues(cfit);
    int=confint(cfit,0.682);
    int=(int(2,:)-int(1,:))/2;
    data.profile.cfit=cfit;
else
    data.profile.cfit=[];
end
switch fitfunc      % prepare output texts
    case 'No fitting'
        fittxt={'No fit'};
    case 'Gauss + offset'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
    [names{3},' = ',num2str(vals(3)),' +/- ',num2str(int(3))];...
    [names{4},' = ',num2str(vals(4)),' +/- ',num2str(int(4))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    case 'exp'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)),' +/- ',num2str(int(2))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    case 'exp + offset'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
    [names{3},' = ',num2str(vals(3)),' +/- ',num2str(int(3))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    case '2exp + offset'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
    [names{3},' = ',num2str(vals(3)/Nsummed),' +/- ',num2str(int(3)/Nsummed)];...
    [names{4},' = ',num2str(vals(4)),' +/- ',num2str(int(4))];...
    [names{5},' = ',num2str(vals(5)),' +/- ',num2str(int(5))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    case '2exp'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
    [names{3},' = ',num2str(vals(3)),' +/- ',num2str(int(3))];...
    [names{4},' = ',num2str(vals(4)),' +/- ',num2str(int(4))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    case 'Gauss'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)),' +/- ',num2str(int(2))];...
    [names{3},' = ',num2str(vals(3)),' +/- ',num2str(int(3))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    case 'Constant'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    case '1 step'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
    [names{3},' = ',num2str(vals(3)),' +/- ',num2str(int(3))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
    case '2 steps'
    fittxt={...
    [names{1},' = ',num2str(vals(1)/Nsummed),' +/- ',num2str(int(1)/Nsummed)];...
    [names{2},' = ',num2str(vals(2)/Nsummed),' +/- ',num2str(int(2)/Nsummed)];...
    [names{3},' = ',num2str(vals(3)/Nsummed),' +/- ',num2str(int(3)/Nsummed)];...
    [names{4},' = ',num2str(vals(4)),' +/- ',num2str(int(4))];...
    [names{5},' = ',num2str(vals(5)),' +/- ',num2str(int(5))];...
    ['# raw data lines: ',num2str(Nsummed)];...
    ['Equation: ',formula(cfit)]}
end
set(handles.analysistxt,'visible','on','string',fittxt,'value',10);
set(handles.loadtxt,'string','Done','backgroundcolor','g');
set(handles.analysisaxes,'buttondownfcn',@(hObject,eventdata)ItrapviewerTrack...
 ('analysisaxes_ButtonDownFcn',hObject,eventdata,guidata(hObject)));
set(get(handles.analysisaxes,'children'),'hittest','off');


% --- Executes on button press in trackbutton.
function trackbutton_Callback(hObject, eventdata, handles)
% hObject    handle to trackbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global data
if sum(data.chdisp)==1  % do normal track on one channel
    data.track2=0;
elseif sum(data.chdisp)==2  % track 2 normalized&summed channels in 3rd
    data.track2=1;
else
    data.track2=0;
    return
end
KymoTracker1('restart')



% --------------------------------------------------------------------
function Toolsmenu_Callback(hObject, eventdata, handles)
% hObject    handle to Toolsmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function analysisaxiscontextmenu_Callback(hObject, eventdata, handles)
% hObject    handle to analysisaxiscontextmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function showlinetimes_Callback(hObject, eventdata, handles)
% hObject    handle to showlinetimes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
showlinetimesbutton_Callback(hObject,eventdata,handles);


% --------------------------------------------------------------------
function showlinetimesmenuitem_Callback(hObject, eventdata, handles)
% hObject    handle to showlinetimesmenuitem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
showlinetimesbutton_Callback(hObject,eventdata,handles);

% --------------------------------------------------------------------
function exportformatxls_menuitem_Callback(hObject, eventdata, handles)
% hObject    handle to showlinetimesmenuitem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
'xls'
global data
data.exportformat='.xls';
set(handles.exportformatxls,'checked','on');
set(handles.exportformattxt,'checked','off');

% --------------------------------------------------------------------
function exportformattxt_menuitem_Callback(hObject, eventdata, handles)
% hObject    handle to showlinetimesmenuitem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
'txt'
global data
data.exportformat='.txt';
set(handles.exportformattxt,'checked','on');
set(handles.exportformatxls,'checked','off');


% --------------------------------------------------------------------
function openinnewfig_Callback(hObject, eventdata, handles)
% hObject    handle to showlinetimes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global data
fig=figure;
data.newfig=fig;
hnew=copyobj(handles.analysisaxes,fig);
data.newaxes=hnew;
% outpos=get(hnew,'OuterPosition');
% set(fig,'position',outpos);
% set(hnew,'OuterPosition',[0,0,outpos(3:4)]);
set(hnew,'units','normalized','outerposition',[0,0,1,1]);

% --------------------------------------------------------------------
function addplotstofig_Callback(hObject, eventdata, handles)
% hObject    handle to showlinetimes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global data
if isfield(data,'newaxes'), if ishandle(data.newaxes)
hnew=copyobj(findobj(handles.analysisaxes,'type','line'),...
    data.newaxes);
axes(data.newaxes), axis tight
end, end

% --------------------------------------------------------------------
function saveplots_Callback(hObject, eventdata, handles)
% hObject    handle to showlinetimes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global data
lines=findobj(handles.analysisaxes,'type','line');
if length(lines)==1
    Xdat=get(lines,'xdata');
    Ydat=get(lines,'ydata');
    T=table(Xdat',Ydat','VariableNames',{'Xdata','Ydata'});
   no=0;
    file=[get(handles.curfile,'string'),'_',num2str(no,'%0.3i')];
    expath=data.expdir;
    savefile=fullfile(expath,file);
    savef=[savefile,data.exportformat];            % Ineke, use '.txt' for delimited, use '.xls' for excel
    incr=exist(savef,'file');
    while incr==2
        no=no+1;
        file=[get(handles.curfile,'string'),'_',num2str(no,'%0.3i')];
        savefile=fullfile(expath,file);
        savef=[savefile,data.exportformat];            % Ineke, use '.txt' for delimited, use '.xls' for excel
        incr=exist(savef,'file');
    end
    writetable(T,savef);
    elseif length(lines)==4
    Xdat=get(lines(4),'xdata'); Ydat=get(lines(4),'ydata');
    Xfit=get(lines(3),'xdata'); Yfit=get(lines(3),'ydata');
    Xfitint=Xdat; Yfitint=interp1(Xfit,Yfit,Xfitint);
    Xpred1=get(lines(2),'xdata'); Ypred1=get(lines(2),'ydata');
    Xpred2=get(lines(1),'xdata'); Ypred2=get(lines(1),'ydata');
    T=table(Xdat',Ydat',Xfitint',Yfitint',Xpred1',Ypred1',Xpred2',Ypred2','VariableNames',{...
        'Xdata','Ydata','Xfit','Yfit','Xpredict1','Ypredict1','Xpredict2','Ypredict2'});
    no=0;
    file=[get(handles.curfile,'string'),'_',num2str(no,'%0.3i')];
    expath=data.expdir;
    savefile=fullfile(expath,file);
    savef=[savefile,data.exportformat];            % Ineke, use '.txt' for delimited, use '.xls' for excel
    incr=exist(savef,'file');
    while incr==2
        no=no+1;
        file=[get(handles.curfile,'string'),'_',num2str(no,'%0.3i')];
        savefile=fullfile(expath,file);
        savef=[savefile,data.exportformat];            % Ineke, use '.txt' for delimited, use '.xls' for excel
        incr=exist(savef,'file');
    end
    writetable(T,savef);
    % Now write raw fit as well (not interpolated)
    T=table(Xfit',Yfit','VariableNames',{'Xfit','Yfit'});
    savefile=fullfile(expath,[file,'_N1000fit']);
    savef=[savefile,data.exportformat];            % Ineke, use '.txt' for delimited, use '.xls' for excel
    writetable(T,savef);
end
