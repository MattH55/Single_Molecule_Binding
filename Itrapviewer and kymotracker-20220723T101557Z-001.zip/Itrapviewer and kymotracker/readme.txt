Itrapviewer and Kymotracker - version 04 november 2014, by Iddo Heller
i.heller@vu.nl, version under construction!

Requires Matlab R2014b or later (not R2014a), including image processing
toolbox, as well as the FDFIT package for opening TDMS files.

The software is intended to read, browse, analyze, process, and export
images and kymographs stored in tdms format such as from the itrap. 
Kymotracker allows you to automatically track trajectories based on
the utrack software package. In addition, you can manually edit the
trajectories. Export includes specs such as track duration, distance,
intensities, and diffusion constants.

Installation:
- Copy the three folders Itrapviewer, utrack_120625, and TDMSReader to
  your hard drive (TDMSReader not needed if FDFIT package is installed)
- Add these folders to the matlab path: in the 'Home'-tab of Matlab, 
  press 'Set Path' (in the 'environment' section). Then press 'Add with
  subfolders' and add the three folders. Press 'Save' to store the paths.

Run Itrapviewer:
- Open the ItrapviewerTrack.m code and run it. 

Run Kymotracker:
- Use ItrapviewerTrack to open a file. Select only one of the RGB channels
- Press the 'Track' button after it becomes visible upon selecting one channel
- Kymotracker now opens itself and the selected file.
- use select tracking roi to select a tracking roi (left-click and drag) and 
  a representative background roi (right click and drag).
- Press Go in the find minima box
- Press Go in the tracking box
- All linked tracks are now displayed. you can edit the tracks graphically:
  Mark the box 'edit tracks'. Left clicking removes tracks or track points.
  Right clicking adds points or connects 2 tracks.
- Gaps (red crosses) can be fitted using 'Fit gaps'
- images of trajectories can be exported by pressing save
- trajectory data can be exported by pressing export.
- To track another kymograph, close the kymotracker window, and restart in
  the itrapviewer window
